<h1 align="center"> VPS AutoScriptVPN <img src="https://img.shields.io/badge/Version-3.0-blue.svg"></h1>

<p align="center">VPS AutoScriptVPN is made by FordSenpai Remodified by PR Aiman for Virtual Private Network</p>
<h3 align="center">Supported Linux Distribution</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Support-Debian-red.svg"></a>
  
</p>
<h3 align="center">Services</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Service-OpenSSH-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Dropbear-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Stunnel-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-OpenVPN TCP-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-OpenVPN UDP-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Squid-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Privoxy-success.svg"></a>
  <a><img src="https://img.shields.io/badge/Service-Anti--Torrent-success.svg"></a>
 </p>
<h3 align="center">Commands</h3>
<p align="center">
  <a><img src="https://img.shields.io/badge/Commands-menu-blueviolet.svg"></a>
  </p>
    
 <h3 align="center">Screenshorts</h3>
 
 <img src="https://raw.githubusercontent.com/praiman99/AutoScriptVPN/master/Screenshort/01.PNG" width="100%">
 <img src="https://raw.githubusercontent.com/praiman99/AutoScriptVPN/master/Screenshort/04.PNG" width="100%">
 <img src="https://raw.githubusercontent.com/praiman99/AutoScriptVPN/master/Screenshort/03.PNG" width="100%">
  
  </h3>
  
<h3 align="center">Installation</h3>

<p align="center">
<pre align="center">wget https://raw.githubusercontent.com/praiman99/AutoScriptVPN/master/setup && chmod +x setup && ./setup
</pre></p>

<h3 align="center">Download Link Configs OpenVPN</h3>

<pre align="center">http://ipvps:85
</pre></p>

<h3 align="center">Additional Info</h3>
<p align="center">
Recommended OS: Debian 9 & 10 x64 bit

Credit To : https://github.com/rvpn/AutoScriptDB-1 (Orignal Base Script)

Credit To : https://github.com/johndesu090/AutoScriptDeb8 (Orignal Menu Script)

Report Bugs Contact : https://t.me/PR_Aiman

<h3 align="center">Thanks to ALLAH S.W.T alhamdulillah syukur kehadrat illahi atas kepandaian dan kebijaksanaan yang telah di berikan daripada maha pencipta. semoga segala urusan di masa akan datang dipermudahkan</h3>

<p align="center">
  <a><img src="https://img.shields.io/badge/Copyright%20©-PR%20Aiman%20AutoScriptVPN%202021.%20All%20rights%20reserved...-blueviolet.svg" style="max-width:200%;">
    </p>
   </p>
