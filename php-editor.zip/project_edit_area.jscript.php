<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
var wmtt = null;
var tip = null ;
var oCellTips = null ;

var nOld = -1 ;
var nSelStart = 0 ;
var nSelEnd = 0 ;
var nCheckRow = 0 ;
var vaLine ;
var __nCurrentRow = 0 ;
var __nCurrentCol = 0 ;
var __nMaxRow = 0 ;
var lShowTips = false ;
var _osc ;
var od ;

function ScrollBody(){
var nm = __nMaxRow - 1 ;
var ot ;

  if(_osc == null){
    _osc = self.parent.document.getElementById("ifmRows") ;
  }
  if(_osc !== null){
    try{
      _osc.contentDocument.body.scrollTop = document.body.scrollTop ;
      ot = _osc.contentDocument.getElementById("tbTest") ;
      ot.rows[0].cells[0].innerHTML = nm ;
      cw = Math.max(ot.rows[0].cells[0].offsetWidth+2,25) ;
      if(_osc.width !== cw){
        _osc.width = cw ;
    
        ot1 = _osc.contentDocument.getElementById("tbRows") ;
        _osc.contentDocument.body.scrollLeft=ot1.rows[0].cells[0].offsetWidth-_osc.width ;
      }
    }catch (e){}
    
    // Geser Tutup Ke Posisi Row Terakhir
    od = _osc.contentDocument.getElementById("rowHide") ;
    if(od !== null){
      od.style.top = (nm*20)+"px" ;
    }
  }
}

function hideTips(){
  if(tip !== null){
    tip.style.display = "none";    
    lShowTips = false ;
  }
}

function showTips() {  
  tip = document.getElementById("showToolTips");
  tip.style.display = "block" ;
  oCellTips = document.getElementById("tipContainner") ;
  lShowTips = true ;
  updateTips() ;  
  oCellTips.noWrap = true ;
  document.form1.cSource.focus() ;  
}

function updateTips() {
var  nEditorWidth = window.innerWidth ;
var  nEditorHeight = window.innerHeight ;
var  nScrollLeft = document.body.scrollLeft ;
var nScrollTop = document.body.scrollTop ;

var nTipsHeight = oCellTips.offsetHeight ; 
var nTipsWidth = oCellTips.offsetWidth ;
var nTipsLeft = 0 ;
var nTipsTop = 0 ;
  
  if (tip != null) {
    if(nTipsWidth > nEditorWidth){
      oCellTips.noWrap = false ;
      oCellTips.width = nEditorWidth - 50 ;
    }
    
    nTipsLeft = (__nCurrentCol * 8) - 25 ;
    nTipsTop = (__nCurrentRow * 20) ;
    if(nTipsLeft + nTipsWidth > nScrollLeft + nEditorWidth){
      nTipsLeft = nScrollLeft + nEditorWidth - nTipsWidth - 20 ;
    }
    if(nTipsTop + nTipsHeight > nScrollTop + nEditorHeight){
      nTipsTop = nScrollTop + nEditorHeight - nTipsHeight - 50 ;
    }
    
    tip.style.left = nTipsLeft + "px" ; 
    tip.style.top  = nTipsTop + "px" ; 
  }  
}

function updateWMTT() {
  if (wmtt != null) {
    wmtt.style.left = (__nCurrentCol * 8) + "px" ; 
    wmtt.style.top   = (__nCurrentRow * 20) + "px" ;
  }
}

function showWMTT(id,nWidth) {  
  if(!nWidth){
    nWidth = 80 ;
  }
  
  wmtt = document.getElementById(id);
  wmtt.style.display = "block" ;
  wmtt.style.width = nWidth + "px" ;
  updateWMTT() ;
  document.form1.cCom.focus() ;
}

function hideWMTT() {
  if (wmtt != null) {
    wmtt.style.display = "none";
  }
}

var lPick = true ;
function pickCommand(field){
  if(lPick){    
    hideWMTT() ;
    with(document.form1){
      cTMPInsert.value = replaceAll(replaceAll(field.value,'&lt;','<'),'&gt;','>') ;      
    }    
  }
  lPick = true ;
}

function cancelPick(){
  hideWMTT() ;
  document.form1.cSource.focus() ;
  SelStart(document.form1.cSource,nSelStart) ;
}

function cCom_onKeyDown(field,e){
var keynum = 0 ;
  if(window.event) // IE
  {
    keynum = e.keyCode
  }
  else if(e.which) // Netscape/Firefox/Opera
  {
    keynum = e.which
  }

  lPick = false ;
  if(keynum == 13 || keynum == 9){
    lPick = true ;
    pickCommand(field) ;
  }else if(keynum == 38 || keynum == 40){
    lPick = false ;
  }else if(keynum == 37 || keynum == 39 || keynum == 27){
    cancelPick() ;
  }else if(keynum == 62){
    lPick = true ;
    pickCommand(field) ;
    with(document.form1){
      if(cTMPInsert.value.substring(cTMPInsert.value.length-1) !== ">"){
        cTMPInsert.value += ">" ;
      }
    }
  }else if(keynum == 8){
    cancelPick() ;
  }else if(keynum == 61){
    cancelPick() ;
    cTMPInsert.value = "=" ;
  }
}

// Untuk Mengambil Kata-kata terakhir yang di ketikkan.
var __nStartCommand = -1 ;    // Untuk Mengetahui Berapa Start Untuk Function 
function lastCommand(lPar){
  nStart = nSelStart - 100 ;
  if(nStart < 0){
    nStart = 0 ;
  }
  var cPar = document.form1.cSource.value.substring(nStart,nSelStart) ;
  vaPar = cPar.split("\n") ;
  cPar = vaPar [vaPar.length-1] ;
  
  // Buang Tanda Operator Matematic
  cPar = replaceAll(cPar,"="," ") ;
  cPar = replaceAll(cPar,"<"," ") ;
  cPar = replaceAll(cPar,"->","```") ;
  cPar = replaceAll(cPar,">"," ") ;
//  cPar = replaceAll(cPar,"."," ") ;
  cPar = replaceAll(cPar,"-"," ") ;
  cPar = replaceAll(cPar,"*"," ") ;
  cPar = replaceAll(cPar,"+"," ") ;
  cPar = replaceAll(cPar,"```","->") ;
  
  vaPar  = cPar.split(' ') ;
  cPar = vaPar [vaPar.length-1] ;
  if(cPar.substring(0,3) == "if("){
    cPar = cPar.substring(3) ;
  }
  cPar = replaceAll(cPar,"!","") ;
  __nStartCommand = nSelStart - cPar.length ;
  return cPar ;
}

// Untuk Deteksi Tombol
function checkCommand(keynum){
var o = document.getElementById("commandList") ;
var va = new Array() ;  
var nStart = 0 ;
  if(keynum == 60){
    va = getHTMLCommand() ;
  }else if(keynum == 32 || keynum == 40 || keynum == 44){   // Spasi / (
    __cLastCommand = lastCommand() ;
    if(keynum == 32){
      ajax('./getphpcommand.php','','cCom=' + __cLastCommand) ;
    }else{
      ajax('./getfunctioncommand.php','','cCom=' + __cLastCommand) ;
    }
  }else if(keynum == 41){ // )
    hideTips() ;
  }
  
  if(va.length > 0){
    o.options.length = 0 ;
    lSelected = true ;
    for(x=0;x<va.length;x++){
      o.options[x] = new Option(va [x][0],va [x][1],lSelected,lSelected);
      o.options[x].style.fontSize="9px" ;
      lSelected = false ;
    }
    
    nCheckRow = 100 ;
    checkCookies() ;
    showWMTT("showCommand") ;  
  }
}

function getHTMLCommand(){
  va = [">","?php","a","abbr","acronym","address","applet","area","b","base","basefont","bdo","bgsound","big","blockquote","body","br",
      "button","button-live","caption","center","cite","code","col","colgroup","dd","del","dfn","div","dl","dt","em","embed",
      "fieldset","font","form","frame","frameset","h1","h2","h3","h4","h5","h6","head","hr","html","i","iframe","ilayer",
      "img","input","ins","kbd","label","layer","legend","li","link","map","marquee","meta","multicol","noframes","noscript",
      "object","ol","optgroup","option","p","param","pre","q","samp","script","select","small","sound","spacer","span","strong",
      "style","sub","sup","table","tbody","td","textarea","tfoot","th","thead","title","tr","tt","ul","var"] ;
    
  var va1=new Array();
  for(x=0;x<va.length;x++){
    va1 [x] = Array(va [x],va [x]) ;
  }  
  for(x=0;x<va.length;x++){
    va1 [va1.length] = Array("/"+va [x],"/"+va [x]+">") ;
  }      
  return va1 ;      
}

function insertChar(field,cChar){
  field.value = field.value.substring(0,nSelStart) + cChar + field.value.substring(nSelStart) ;
}

function deleteNextEmptyChar(field){
  var n = nSelStart ;
  while(field.value.substring(n,n+1) == " " && n < field.value.length){
    n ++ ;
  }

  if(n > nSelStart){
    field.value = field.value.substring(0,nSelStart) + field.value.substring(n) ;
  }
}

function shiftTab(field){
  var nPos = 0 ;
  var cDelete = field.value.substring(nSelStart-2,nSelStart)
  if(cDelete == "  "){
    field.value = field.value.substring(0,nSelStart-2) + field.value.substring(nSelStart) ;
    nPos = -2 ;
  }
  return nPos ;
}

function SelStart(field,nSel,nSelEnd){
  nSelStart = nSel ;
  if(!nSelEnd) nSelEnd = nSel ;
  field.selectionStart = nSelStart ;
  field.selectionEnd = nSelEnd ;  
}

function cSource_onKeyPress(field,e,cType){
var keynum = 0 ;
var n = 0 ;
var lFirst = true ;
var cTab = "" ;
var cTab_Char = "\t" ;
var nTab = 0 ;

  nSelStart = field.selectionStart ;
  nSelEnd = field.selectionEnd ;  
  if(window.event) // IE
  {
    keynum = e.keyCode
  }
  else if(e.which) // Netscape/Firefox/Opera
  {
    keynum = e.which
  }      

  if(cType == "down"){
    if(keynum == 9){      // Tab
      nCheckRow = 100 ;
      checkCookies() ;
      var nModulus = __nCurrentCol%2 ;
      var cInsertChar = " " ;
      if(nModulus == 1){
        cInsertChar = "  " ;                
      }
      var nPos = cInsertChar.length ;
      
      // Shift Tab Mundur 2 Karakter
      if(e.shiftKey){
        nPos = shiftTab(field) ;
      }else{
        insertChar(field,cInsertChar) ;
      }
      SelStart(field,nSelStart + nPos) ;
      self.parent.UpdEditStatus(true) ;
      return false ;
    }else if(e.ctrlKey && keynum == 69){
      // Ctrl+Delete Hapus Karakter Kosong di Depan
      deleteNextEmptyChar(field) ;
      SelStart(field,nSelStart) ;
      self.parent.UpdEditStatus(true) ;
      return false ;
    }else if(e.ctrlKey && keynum == 83){
      self.parent.savePHP(true) ;
      return false ;
    }else if(e.ctrlKey && keynum == 70){
      self.parent.FindText() ;
      return false ;
    }else if(e.ctrlKey && keynum == 32){
      checkCommand(keynum)
    }else if(keynum == 27){
      hideTips() ;
    }else if(keynum == 46 || (e.ctrlKey && keynum == 86)){      
      self.parent.UpdEditStatus(true) ;
    }else if(e.altKey && keynum == 54){
      self.parent.ToggleBookmark() ;
      return false ;
    }else if(e.altKey && keynum == 55){
      self.parent.NextBookmark('Next') ;
      return false ;
    }else if(e.altKey && keynum == 56){
      self.parent.NextBookmark('Prev') ;
      return false ;
    }else if(e.ctrlKey){
      // O,R,I,U,P,K,J,D,B,Y,H,L,W
      // Ctrl + Tombol di atas di matikan.
      var va = new Array(79,82,73,85,80,75,74,66,68,89,72,76,87) ;
      for(i=0;i<va.length;i++){
        if(keynum == va[i]){
          return false ;
        }
      }
    }
  }else if(cType == "press"){    
    if(keynum !== 0 && !e.ctrlKey && !e.altKey){ 
      self.parent.UpdEditStatus(true) ;
    }
    
    if(keynum == 13){    // Enter
      var va = field.value.substring(0,field.selectionStart).split("\n") ;
      var nCurLine = va.length - 1 ;
      lFirst = true ;
      cTab = "" ;
      // Hitung Sepasi Depan
      nTab = va [nCurLine].indexOf(" ") ;
      while ( nTab == 0 ) {
        va [nCurLine] = va [nCurLine].replace( " ", "" );
        nTab = va [nCurLine].indexOf(" ") ;
        cTab += " " ;
      }
      if(cTab !== ""){
        SelStart(field,nSelStart) ;
        document.form1.cTMPInsert.value = "\n" + cTab ;
        checkCookies() ;
        return false ;
      }else{
        return true ;
      }
    }else if(keynum == 60 || keynum == 40 ){  // Sementara tidak dulu || keynum == 44
      // 40 = (
      // 44 = ,
      checkCommand(keynum) ;    
    }else if(keynum == 41){
      // 41 = )
      hideTips() ;
    }
    updFuncPar() ;
  }
}

function updFuncPar(){
  // Jika Posisi ToolTips Membuka
  // Hitung Berapa Jumlah Koma untuk parameternya
  // Masih Dalam Tahap Pengerjaan
  // Khususnya Untuk Function yang Bertumpuk.
  // Contoh number_format(str_len(
  // pada contoh di atas parameter akan kacau
  if(lShowTips){
    var nCommandLength = nSelStart - __nStartCommand ;
    var cLastCommand = document.form1.cSource.value.substring(__nStartCommand,nCommandLength+__nStartCommand) ;
    var cTips = document.getElementById("tipContainner") ;
    
    // Check apakah Posisi Function masih sesuai kalau tidak 
    // Tutup Tooltips
    if(__nStartCommand > nSelStart) hideTips() ;    
    if(lShowTips){  
      // Ambil Parameter Function dengan cara
      // Mengambil Carakter setelah Kurung Buka
      vaKurung = cLastCommand.split("(") ;
      vaTipsKurung = document.form1.cDefaultTips.value.split("(") ;
      cResult = document.form1.cDefaultTips.value ;
      if(vaKurung.length == 2 && vaTipsKurung.length == 2){
        var cSeparator = ";" ;
        if(vaTipsKurung [1].indexOf(",") >= 0) cSeparator = "," ;
        var vaCommand1 = vaKurung [1].split(cSeparator) ;
        
        // Kita Cek Kalau parameter di apit dengan "" maka koma di dalamnya tetap dianggap sebagai 1 parameter
        var vaCommand = new Array() ;
        var lNextPar = true ;
        var i = 0 ;
        for(x=0;x<vaCommand1.length;x++){
          var vaPar = vaCommand1 [x].split('"') ;
          if(vaPar.length%2 == 0) lNextPar = !lNextPar ;

          vaCommand [i] = vaCommand1 [x] ;
          if(lNextPar) i ++ ;
        }

        vaTipsKurung [1] = replaceAll(vaTipsKurung [1],")","") ;
        var vaTipsCommand = vaTipsKurung [1].split(cSeparator) ;

        if(vaCommand.length <= vaTipsCommand.length){
          vaTipsCommand [vaCommand.length-1] = "<span class='tipsPar-Select'>" + vaTipsCommand [vaCommand.length-1] + "</span>" ;
          cResult = vaTipsKurung [0] + "(" + vaTipsCommand.join(cSeparator) + ")" ;
        }
      }
      cTips.innerHTML = cResult ;
      updateTips() ;
    }
  }
}

var nUpdFileOpen = 0 ;
function checkCookies(lCheckRow){
var cValue = "" ;
var nStart = 0 ;
var oRow ;
var nTotLength = 0 ;
var ot ;
var nOldMaxRow = __nMaxRow ;

  nUpdFileOpen ++ ;
  if(nUpdFileOpen > 25){
    nUpdFileOpen = 0 ;
    ajax('project_edit_area.ajax.php','UpdFileOpen()','') ;
  }

  nCheckRow ++ ;
  if(nCheckRow >= 5 || lCheckRow){
    if(typeof self.parent.UpdateFindIcons == 'function') self.parent.UpdateFindIcons() ;
    nCheckRow = 0 ;
    nSelStart = document.form1.cSource.selectionStart ;    
    vaLine = document.form1.cSource.value.substring(0,nSelStart).split("\n") ;
    __nMaxRow = (document.form1.cSource.value.split("\n")).length + 1 ;
    document.form1.cSource.rows = __nMaxRow + 1 ;
    __nCurrentRow = vaLine.length ;
    nTotLength = vaLine.join("\n").length - vaLine[__nCurrentRow-1].length ;
    __nCurrentCol = nSelStart - nTotLength + 1 ;
    
    if(nOldMaxRow !== __nMaxRow){
      oRow = self.parent.document.getElementById("ifmRows") ;
      if(oRow !== null){
        ot = oRow.contentDocument.getElementById("tbRows") ;
        nr = ot.rows.length ;
        nm = __nMaxRow - 2 ;
        if(nr < nm){
          oRow.contentDocument.location.reload() ;
        }        
      }
    }
    ScrollBody();
    updFuncPar() ;
  }

  with(document.form1){
    cValue = cTMPInsert.value ;
    if(cValue !== ""){
      cValue = replaceAll(cValue,"\t","  ") ;
      nStart = nSelStart + cValue.length ;
      insertChar(document.form1.cSource,cValue) ;
      cTMPInsert.value = "" ;
      cSource.focus() ;
      SelStart(cSource,nStart) ;
      self.parent.UpdEditStatus(true) ;
    }
  }
  setTimeout(checkCookies,200) ;  
}
</script>