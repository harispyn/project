function ucase(field){
  field.value = field.value.toUpperCase() ;
}  

function saving(form){
  if (confirm("Data Disimpan ?")){    
    ValidSaving() ;
  }
}

function padl(cValue,nLen,cChar){
  var cRetval = "" ;
  var cLen = "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" ;  

  cLen = cLen.substring(0,nLen)  ;
  cRetval = cLen.substring(0,nLen - cValue.length) + cValue ;
  return cRetval ;
}

function replaceAll( str, from, to ) {
var idx = str.indexOf( from );

  while ( idx > -1 ) {
    str = str.replace( from, to );
    idx = str.indexOf( from );
  }

  return str;
}

function setupComponent(frm,lPar){
  for(n=0;n<frm.length;n++){
    if(frm.elements[n].type == "text" || frm.elements[n].type == "radio" || frm.elements[n].type == "password" || frm.elements[n].type == "file"){
      frm.elements[n].disabled = !lPar ;      
    }
    if(frm.elements[n].name == "cmdSave"){
      frm.elements[n].disabled = !lPar ;
    }

    if(frm.elements[n].name == "cmdAdd" || frm.elements[n].name == "cmdEdit" || frm.elements[n].name == "cmdDelete"){
      frm.elements[n].disabled = lPar ;
    }

  }
}