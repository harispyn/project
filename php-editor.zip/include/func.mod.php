<?php
include 'df.php' ;
  
function GetSetting($cKey,$cDefault = ''){  
  $cKey = md5(session_id() . __FILE__ . strtolower($cKey)) ;
  if(!session_is_registered($cKey)){
    session_register($cKey) ;
    $_SESSION[$cKey] = $cDefault ;
  }
  return $_SESSION[$cKey] ;
}

/**************************************************************************************************************************************************************************************************/
function SaveSetting($cKey,$cValue){
  $cKey = md5(session_id() . __FILE__ . strtolower($cKey)) ;
  if(!session_is_registered($cKey)){
    session_register($cKey) ;    
  }
  $_SESSION[$cKey] = $cValue ;
}

/**************************************************************************************************************************************************************************************************/  
function getlink($cChar,$lEcho=true){
  $c = md5($cChar) ;  
  SaveSetting($c,$cChar) ;
  
  if($lEcho){
    echo($c) ;
  }else{
    return $c ;
  }
}  

/**************************************************************************************************************************************************************************************************/
function direc($cURL){
  echo '<html><meta http-equiv="refresh" content="0;
    URL=main.php?__par=' . getlink($cURL,false) . '">'
    .'</html>' ;
  exit ;
}

/**************************************************************************************************************************************************************************************************/
function GetIcon($cFile){
  $nDot = strrpos($cFile,".") + 1 ;
  $cExt = strtolower(substr($cFile,$nDot)) ;
  if(!is_file("./images/" . $cExt . ".gif")){
    $cFile = "unknow.gif" ;
  }else{
    $cFile = $cExt . ".gif" ;
  }
  return '<img src="./images/' . $cFile . '" border = "0">' ;
}

/**************************************************************************************************************************************************************************************************/
function GetSize($nSize){
  $cRetval = number_format($nSize,2) . " B" ;
  
  $vaSize = array("KB", "MB", "GB", "TB") ;
  $n = 1024 ;
  foreach($vaSize as $key=>$value){
    if ($nSize > $n){
      $nSize = $nSize / $n ;
      $cRetval = number_format($nSize,2) . " " . $value ;
    }
    $n = 1000 ;
  }
  return $cRetval ;
}

/**************************************************************************************************************************************************************************************************/
function GetFileSize($cFile,$lTmpFileSize = false){  
  $cRetval = "0 B" ;
  $lCheck = false ;
  if(is_file($cFile)){
    $nSize = filesize($cFile) ;
    $cRetval = GetSize($nSize) ;
  }    
  return $cRetval ;
}

/**************************************************************************************************************************************************************************************************/
function GetVersion(){
  return "1.0.18c" ;
}

/**************************************************************************************************************************************************************************************************/
function ProjectList(){
  $cDir = GetSetting("cProject_Dir") ;
  if(is_dir($cDir)){
    $d = dir($cDir) ;            
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry)){
        if($entry !== "." && $entry !== ".."){
          $vaDir[$entry] = array("Name"=>$entry,"TimeChange"=> filectime($cDir . '/' . $entry),"Size"=>0) ; ;
        }
      }
    }

    if(!empty($vaDir)){
      asort($vaDir) ;
      return $vaDir ;
    }
  }
}

/**************************************************************************************************************************************************************************************************/
function IncludeFile($cFile="User-List"){
  $cFileName = GetFileName($cFile) ;
  $vaUserName = "" ;
  if(is_file($cFileName)){
    include $cFileName ;
  }
  return $vaUserName ;
}

/**************************************************************************************************************************************************************************************************/
function GetFileName($cFile="User-List"){
  $cDir = "./include/.user" ;
  if(!is_dir($cDir)){
    mkdir($cDir,0777) ;
  }
  $cIndex = $cDir . "/index.php" ;
  if(!is_file($cIndex)){
    $nhd = fopen($cIndex,"w") ;
    fwrite($nhd,'Restricted access') ;
    fclose($nhd) ;
  }
  
  return $cDir . "/" . md5($cFile) . ".inc.php" ;
}

/**************************************************************************************************************************************************************************************************/
function IsDatabase(){
  if(GetSetting("optMYSQL","N") == "Y"){
    $cIP = GetSetting("cMYSQL_IP") ;
    $cUser = GetSetting("cMYSQL_User") ;
    $cPassword = GetSetting("cMYSQL_Password") ;
    $cDatabase = GetSetting("cMYSQL_Database") ;
    
    mysql_connect($cIP, $cUser,$cPassword) ;
    mysql_select_db($cDatabase);
    return true ;
  }
  return false ;
}

/**************************************************************************************************************************************************************************************************/
function SaveHistory($cStatus='S'){
  // S = Save
  // C = Close
  // O = Open
  if(IsDatabase() && !IsReadOnly()){    
    $dTgl = date("Y-m-d") ;
    $cUserName = GetSetting("cUserName") ;
    $cProject = GetSetting("cSession_DevProject") ;
    $cFileName = GetSetting("CurrFile_FullName") . GetSetting("CurrFile_Ext") ;
    $cOldFileName = "" ;
    $lSave = true ;
    if($cStatus == "S" && is_file($cFileName)){
      // Copy File ke Directory History
      $cOldDir = "./.history" ;
      if(!is_dir($cOldDir)){
        mkdir($cOldDir,0777) ;
      }
      $cOldFileName = $cOldDir . '/f' . md5($cFileName . time() . $cUserName . rand(0,10000)) ;      
      copy($cFileName,$cOldFileName) ;
      
      $nDateTime = time() - (60*60*24*30) ;
      $dHapus = date("Y-m-d",$nDateTime) ;
      $dbData = mysql_query("select ID,OldFileName from php_editor_history where tgl <= '$dHapus' limit 0,100") ;
      while($dbRow = mysql_fetch_array($dbData)){
        if(is_file($dbRow ['OldFileName'])){
          unlink($dbRow ['OldFileName']) ;          
        }
        $nID = $dbRow ['ID'] ;
        mysql_query("delete from php_editor_history where id = '$nID'") ;
      }      

      // Simpan Untuk mengetahui update terakhir dari Directory ini
      $cDirName = dirname($cFileName) . "/" ;
      UpdateDirMTime($cDirName) ;
    }else if($cStatus == "O"){
      mysql_query("delete from php_editor_history where Status = '$cStatus' and FileName = '$cFileName'") ;
    }else if($cStatus == "C"){
      $lSave = false ;
      mysql_query("delete from php_editor_history where Status = 'O' and FileName = '$cFileName' and UserName = '$cUserName'") ;
      $nTime = time() - 60 ;
      mysql_query("delete from php_editor_history where Status = 'O' and DateTime < $nTime") ;
    }

    $nDateTime = time() ;
    if($lSave){
      mysql_query("Insert Into php_editor_history (Status,Tgl,UserName,Project,FileName,OldFileName,DateTime)
                                           Values ('$cStatus','$dTgl','$cUserName','$cProject','$cFileName','$cOldFileName','$nDateTime')") ;
    }
  }
}

/**************************************************************************************************************************************************************************************************/
function UpdateDirMTime($cDirName){
  if(IsDatabase() && !IsReadOnly()){
    $cDirName = str_replace(GetSetting("project_dir")."/","",$cDirName) ;
    $cDirName = str_replace("//","/",$cDirName."/") ;
    $nTime = time() ;
    mysql_query("delete from php_editor_diredit where DirName = '$cDirName'") ;
    mysql_query("insert into php_editor_diredit (DirName,DateTime) values('$cDirName','$nTime')") ;
  }
}

/**************************************************************************************************************************************************************************************************/
function DirMTime($cDir){
  $nRetval = 0 ;
  if(IsDatabase() && !IsReadOnly()){
    $cDir = str_replace(GetSetting("project_dir")."/","",$cDir) ;
    $cDir = str_replace("//","/",$cDir . "/") ;
    $dbData = mysql_query("select ifnull(Max(DateTime),0) as DateTime from php_editor_diredit Where DirName like '$cDir%'") ;
    if($dbRow = mysql_fetch_array($dbData)){
      $nRetval = $dbRow ['DateTime'] ;
    }
  }else{
    $nRetval = time() ;
  }
  if(empty($nRetval)){
    $nRetval = mktime(0,0,0,1,1,2006) ;
  }
  return $nRetval ;
}

/**************************************************************************************************************************************************************************************************/
function CreateDir($cDirName,$cDirMode = 0777){
  if(mkdir($cDirName,$cDirMode)){
    UpdateDirMTime($cDirName) ;
  }
}

/**************************************************************************************************************************************************************************************************/
function RemoveDirectory($cDir){
  $d = dir($cDir) ;            
  while (false !== ($entry = $d->read())) {
    if(is_dir($cDir . '/' . $entry)){
      if($entry !== "." && $entry !== ".."){
        RemoveDirectory($cDir . '/' . $entry) ;
      }
    }else{
      if(is_file($cDir . '/' . $entry)){
        unlink($cDir . '/' . $entry) ;
      }
    }
  }
  $d->close();
  rmdir($cDir) ;
}

/**************************************************************************************************************************************************************************************************/
function CreateTmpDir(){
  $cRoot = GetSetting("project_dir") . "/.downloads" ;
  CheckDir($cRoot) ;
  
  // Hapus Directory Lama
  $vaDir = array("0"=>"1","1"=>"2","2"=>"0") ;
  $nDir = date("H")%3 ;
  if(isset($vaDir[$nDir])){
    $cOldDir = $cRoot . "/d" . $vaDir [$nDir] ;
    if(is_dir($cOldDir)){
      RemoveDirectory($cOldDir) ;
    }
  }  
  
  $cRoot .= "/d" . $nDir ;
  CheckDir($cRoot) ;
  
  $cRoot .= "/h" . md5(time() . session_id() . rand(0,10000)) ;
  CheckDir($cRoot) ;
  
  return $cRoot ;
}

/**************************************************************************************************************************************************************************************************/
function CheckDir($cDir){
  if(!is_dir($cDir)){
    mkdir($cDir) ;
    chmod($cDir,0777) ;
  }
}

/**************************************************************************************************************************************************************************************************/
function IsReadOnly(){
  $lRetval = false ;
  if(IsDatabase()){
    $dTgl = date("Y-m-d") ;
    $cUserName = GetSetting("cUserName") ;
    $cProject = GetSetting("cSession_DevProject") ;
    $cFileName = GetSetting("CurrFile_FullName") . GetSetting("CurrFile_Ext") ;
    $nTime = time() ;
    $dbData = mysql_query("select UserName,DateTime From php_editor_history where Status = 'O' and FileName = '$cFileName'") ;
    if($dbRow = mysql_fetch_array($dbData)){      
      if($dbRow ['UserName'] !== $cUserName && ($nTime - $dbRow['DateTime']) <= 10){
        $lRetval = true ;
        SaveSetting("cUser_Locking",$dbRow ['UserName']) ;
      }
    }
  }
  return $lRetval ;
}

/**************************************************************************************************************************************************************************************************/
function SaveArray($vaUserName,$cFileName){
  ksort($vaUserName) ;
  $nhd = fopen($cFileName,"w") ;
  fwrite($nhd,'<?php ') ;
  foreach($vaUserName as $key=>$value){
    $c = '$' . 'vaUserName["' . $key . '"] = ' . var_export($value,true) . '; ';
    fwrite($nhd,$c) ;
  }
  fwrite($nhd,' ?>') ;
  fclose($nhd) ;
}

function UpdateBookmarkAll($lPar,$cBookmarkFile=''){
  $cFileName = $cBookmarkFile ;
  if(empty($cFileName)){
    $cFileName = "Bookmark-" . GetSetting("CurrFile_FullName") . GetSetting("CurrFile_Ext") ;
  }

  $cBookmark = GetSetting($cFileName) ;
  $vaBookmark = split(";",$cBookmark) ;
  $cPar = "false" ;
  if($lPar) $cPar = "true" ;
  $cFoundBookmark = "true" ;
  foreach($vaBookmark as $key=>$value){
    if(!empty($value)){
      $cFoundBookmark = "false" ;
      echo('UpdateBookmark(' . $value . ',' . $cPar . ');') ;
    }
  }
  echo("DisableIcons('bookmark-next',$cFoundBookmark);DisableIcons('bookmark-prev',$cFoundBookmark);") ;
}

function Tgl2Time($dTgl){
  if(empty($dTgl)){
    return 0 ;
  }
  $dTgl = String2Date($dTgl) ;  
  $va = split("-",$dTgl) ;
  return mktime(0,0,0,$va [1],$va[0],$va[2]) ;
}

/**************************************************************************************************************************************************************************************************/
if(empty($lNoJS) || !$lNoJS){
  echo('
      <script language="javascript" src="./include/func.js"></script>
      <script language="javascript" src="../component/ajax.js"></script>
      <script language="javascript" src="../component/cal.js"></script>
    ') ;
}
?>