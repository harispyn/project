<?php
  if(!defined('sessionstart')){    
    define('sessionstart',1) ;
    
    session_start() ;        
    include './include/func.mod.php' ;
    include '../component/func.mod.php' ;
    include '../component/textbox.php' ;
    if(empty($lFuncOnly) || !$lFuncOnly){
      include '../component/dbgrid/dbgrid.php' ;
      include '../component/themes/css.php' ;
    }    
  }
  
  $cProjectDir = "" ;
  if(is_file("./include/assist.ini.php")){
    $data = file("./include/assist.ini.php") ;
    foreach($data as $key=>$value){
      $value = trim($value) ;
      $cTag = "" ;
      $cValue = "" ;
      if(substr($value,0,1) <> "#"){
        $va = split("=",$value) ;
        if(count($va) >= 2){
          $cTag = trim((string)$va [0]) ;
          $cValue = trim(str_replace(chr(10),'',str_replace(chr(13),'',(string)$va [1]))) ;

          $cTag = strtolower($cTag) ;
          SaveSetting($cTag,$cValue) ;
          GetSetting($cTag) ;
        }
      }
    }
  }
?>
