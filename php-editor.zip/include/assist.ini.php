<?php
  exit ;
?>
project_dir = ..
optUserList = N
optUserLock = N
optMYSQL = N
cMYSQL_User = Assist
cMYSQL_Password = Irac
cMYSQL_Database = 
cMYSQL_IP = localhost
