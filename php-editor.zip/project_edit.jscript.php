<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
var lCheckUnloads = true ;  
var lEditedStatus = false ;
var oEditor = null ;

function checkParent(cUserLock){
  if(cUserLock == "Y" && self.parent.name !== "mainFrame"){
    with(document.form1){
      action = "main.php?__par=logout.php" ;
      submit() ;
    }
  }
}

function Form_onClose(){
  return confirm("Program Ditutup ?") ;
}

function checkWindow(){  
  return true ;
}

function Preview(){ajax('','Preview()')}
function SetScroll(){if(document.body.scrollTop !== 0){document.body.scrollTop = 0}}
function HideProgress(cID){
  if(!cID) cID = "ShowProsess" ;
  var _op = document.getElementById(cID) ;
  if(_op!==null){_op.style.display = "none"}
}

var cExt1 = "" ;
var cFile1 = "" ;
function LoadFile(cExt,cFile){
  if(lEditedStatus){
    if(!confirm("File Belum Disimpan, Click Ok Untuk Menutup form Click Cancel Untuk Kembali Ke Form Semula ....!")){
      return false ;
    }
  }
  if(!cExt){
    cExt = '' ;
  }
  if(!cFile){
    cFile = '' ;
  }
  cExt1 = cExt ;
  cFile1 = cFile ;
  
  SavePos('LoadFile_Prosess()') ;
  return false ;
}

function LoadFile_Prosess(){
  cExt = cExt1 ;
  cFile = cFile1 ;

  ShowProgress("Loading...") ;
  if(cExt !== ""){
    cExt = "cExt="+cExt ;
  }
  if(cFile !== ''){
    cFile = '&cFile='+cFile ;
  }
  ajax('','ShowTabExtention()',cExt+cFile) ;
  lEditedStatus = false ;
  return false ;
}

function CloseExt(cFile){
  ShowProgress("Loading...") ;
  ajax('','CloseExt()','cCloseFile='+cFile) ;
  return false ;
}

function ShowProgress(cTitle,cID){
var nw = window.innerWidth ;
var nwt = 100 ;
  if(!cID) cID = "ShowProsess" ;
  SetScroll() ;
  var _op = document.getElementById(cID) ;
  if(_op!==null){    
    _op.noWrap = true ;    
    _op.innerHTML = cTitle ;
    _op.style.top = "2px" ;
    _op.style.left = nw + "px" ;
    _op.style.display = "block" ;
    nwt = _op.offsetWidth ;    
    _op.style.left = (nw-nwt-10) + "px" ;     
  }
}

function savePHP(lAutoSave){
var cDan = "{DAN}".toLowerCase() ;
var cPlus = "{PLUS}".toLowerCase() ;
var of = document.getElementById("Editor") ;

  if(!lEditedStatus){
    if(lAutoSave){
      return false ;
    }
    alert("Source Code tidak berubah, File Tidak bisa di Simpan .....!") ;
  }else{
    lCheckUnloads = false ;
    with(document.form1){
      if(lAutoSave || confirm("Data Disimpan ?")){
        ShowProgress("Saving....") ;
        cSource.value = of.contentDocument.form1.cSource.value ;
        cSource.value = replaceAll(cSource.value,"&",cDan) ;
        cSource.value = replaceAll(cSource.value,"+",cPlus) ;
        ajax('','SavePHP()',GetFormContent(document.form1)) ;
      }
    }
  }
}
  
function loadSource(nMaxRows){
var oe = document.getElementById("Editor") ;
var cDan = "{DAN}".toLowerCase() ;
  if(oe !== null){
    with(document.form1){
      cSource.value = replaceAll(cSource.value,cDan,"&") ;
      cSource.value = replaceAll(cSource.value,"\t","  ") ;
      
      oe.contentDocument.form1.cSource.value = cSource.value ;
      oe.contentDocument.form1.cSource.focus() ;
      oe.contentDocument.form1.cSource.rows = nMaxRows ;      
    }
  }
}

function UpdEditStatus(lPar){
  // Memberi Tanda Bintang pada Tab  
  if(!lEditedStatus || !lPar){
    var o = document.getElementById("TabEdit") ;
    lEditedStatus = lPar ;
    if(lPar){
      o.innerHTML = replaceAll(o.innerHTML,"</font>","") + "*</font>" ;
    }else{
      o.innerHTML = replaceAll(o.innerHTML,"*","") ;
    }
  }
  return lPar ;
}

function DisableIcons(cKey,lPar){    
  var o = document.getElementById("icons_" + cKey) ;

  if(o !== null){
    cName = "styleIcons" ;
    if(lPar){
      cName = "styleIcons-Disable" ;
    }
    o.className = cName ;
  }
}

function CheckIcons(cName){
  var o = document.getElementById("icons_" + cName) ;
  var oe = document.getElementById("Editor") ;
  var lDisabled = false ;
  if(oe !== null){
    lDisabled = oe.contentDocument.form1.cSource.disabled ;
  }
  if(o !== null && cName !== "open"){
    if (o.className == "styleIcons-Disable" || lDisabled){
      return false ;
    }
  }
  return true ;
}
  
function SavePos(cFuncNext){
var oe = document.getElementById("Editor") ;
  if(!cFuncNext){
    cFuncNext = '' ;
  }
  if(oe !== null){
     cValue = oe.contentDocument.form1.cSource.selectionStart + "::" + oe.contentDocument.form1.cSource.selectionEnd + "::" +
              oe.contentDocument.body.scrollLeft + "::" + oe.contentDocument.body.scrollTop ;
     ajax('','SavePos()','cPosValue='+cValue+'&cFuncNext='+cFuncNext+"&cFindText="+document.form1.cFindText.value) ;
  }
}

function validclose(e){
  oEditor = document.getElementById("Editor") ;
  with (document.form1){      
    SavePos() ;    
    if(oEditor !== null){
      if(lEditedStatus && lCheckUnloads){
        e.returnValue =  "File Belum Disimpan Click OK Untuk menutup Form Click Cancel Untuk kembali ke Form Semula" ;
        lCheckUnloads = true ;
        oEditor.contentDocument.form1.cSource.focus() ;
        return false ;
      }
    }
  }
}

function GetRowCol(){
var oe = document.getElementById("Editor").contentWindow ;
  oe.checkCookies(true) ;
  return Array(oe.__nCurrentRow,oe.__nCurrentCol) ;
}

var oFrmLeft = null ;
function UpdateBookmark(nRow,lPar){
  if(oFrmLeft == null) oFrmLeft = document.getElementById("ifmRows") ;
  var cClassName = "cellBookmark" ;
  if(!lPar) cClassName = "cellRow" ;
  var oTable = oFrmLeft.contentDocument.getElementById("tbRows") ;
  if(oTable !== null){
    if(oTable.rows.length >= nRow-1){    
      oTable.rows[nRow-1].cells[0].className = cClassName ;
    }
  }
}

function EditFocus(){
  oEditor = document.getElementById("Editor") ;
  if(oEditor !== null){
    oEditor.contentDocument.form1.cSource.focus() ;
  }
}

function ToggleBookmark(nRow){
  if(!nRow){
    var vaPos = GetRowCol() ;
    nRow = vaPos [0] ;
  }
  ajax('./project_edit.ajax.php','TogleBookmark()','nRow='+nRow);
}

function NextBookmark(cStatus){
var vaPos = GetRowCol() ;
  ajax('./project_edit.ajax.php','NextBookmark()','nRow='+vaPos[0]+'&cStatus='+cStatus);
}

function GotoRow(nRow){
  if(oEditor == null){
    oEditor = document.getElementById("Editor") ;
  }
  vaLine = oEditor.contentDocument.form1.cSource.value.split("\n",nRow) ;
  
  var nTop = oEditor.contentDocument.body.scrollTop ;
  var nBottom = oEditor.contentWindow.innerHeight + nTop ;
  if(vaLine.length >= nRow -1){
    var nCar = 0 ;
    for(n=0;n<nRow-1;n++){
      nCar += vaLine [n].length + 1 ;
    }
    with(oEditor.contentDocument.form1){
      cSource.selectionStart = nCar ;
      cSource.selectionEnd = nCar ;      
    }
    
    nScroll = (nRow - 1) * 20 ;
    if(nScroll < nTop){    
      oEditor.contentDocument.body.scrollTop = nScroll ;
    }else if(nScroll > nBottom){
      nScroll = (nRow*20) - oEditor.contentWindow.innerHeight + 20 ;
      oEditor.contentDocument.body.scrollTop = nScroll ;
    }
    EditFocus()
  }  
}

function FindText(){
  fieldfocus(document.form1.cFindText) ;
  return false ;
}

function FindNext(){
  GoFind(true,document.form1.cFindText.value,false) ;
  return false ;
}

function FindPrev(){
  GoFind(false,document.form1.cFindText.value,false) ;
  return false ;
}

function UpdateFindIcons(){
  var lDisable = document.form1.cFindText.value == "" ;
  DisableIcons("find-next",lDisable)
  DisableIcons("find-prev",lDisable)  
}

function cFindText_onKeyDown(field,e){
  if(window.event) // IE
  {
    keynum = e.keyCode
  }
  else if(e.which) // Netscape/Firefox/Opera
  {
    keynum = e.which
  }
  if(keynum == 13){
    GoFind(true,document.form1.cFindText.value,false,0) ;
    return false ;
  }
  return true ;
}

var od = null ;
var ow = null ;
function GoFind(lDown,cTextFind,lMatch,nStart){
  if(cTextFind == "") return false ;
 
  if(oEditor == null){
    oEditor = document.getElementById("Editor") ;
  }
  od = oEditor.contentDocument ;
  ow = oEditor.contentWindow ;

  if(oEditor !== null){
    var cTextSource = od.form1.cSource.value ;
    if(!lDown) cTextSource = cTextSource.substring(0,od.form1.cSource.selectionStart) ;
    if(!lMatch){
      cTextFind = cTextFind.toLowerCase() ;
      cTextSource = cTextSource.toLowerCase() ;
    }
    if(typeof nStart == "undefined") nStart = od.form1.cSource.selectionEnd ;
    if(lDown){
      var c = cTextSource.indexOf(cTextFind,nStart) ;
    }else{
      var c = cTextSource.lastIndexOf(cTextFind,nStart) ;
    }
    if(c >= 0){
      ow.SelStart(od.form1.cSource,c,c+cTextFind.length) ;
      UpdateScrolling(od.form1.cSource) ;
    }else{
      alert("Parse Not Found ....") ;
    }
    od.form1.cSource.focus() ;
  }
}

function UpdateScrolling(oSource){
var  nEditorWidth = ow.innerWidth ;
var  nEditorHeight = ow.innerHeight ;
var  nScrollLeft = od.body.scrollLeft ;
var nScrollTop = od.body.scrollTop ;

  ow.checkCookies(true) ;
  var nTop = ow.__nCurrentRow * 20 ;
  var nScroll = -1 ;
  if(nEditorHeight + nScrollTop < nTop + 20){
    nScroll = nTop - nEditorHeight + 20 ;
    if(nScroll < 0) nScroll = 0 ;
  }else if(nTop - 20 < nScrollTop){
    nScroll = nTop - 20 ;
    if(nScroll < 0) nScroll = 0 ;
  }
  if(nScroll >= 0) od.body.scrollTop = nScroll ;

  var nS = oSource.value.lastIndexOf("\n",oSource.selectionEnd-1) ;  
  var obj = document.getElementById("objTextWidth") ;
  obj.style.display = 'inline';
  
  obj.innerHTML = oSource.value.substring(nS,oSource.selectionEnd-1) ;
  var nLeft = obj.offsetWidth ;
  obj.innerHTML = oSource.value.substring(nS,oSource.selectionStart-1) ;
  var nLeft2 = obj.offsetWidth ;
  
  obj.innerHTML = "" ;
  obj.style.dislay = "none" ;
  
  var nScroll = -1 ;
  if(nEditorWidth + nScrollLeft < nLeft + 20){
    nScroll = nLeft - nEditorWidth + 25 ;
    if(nScroll < 0) nScroll = 0 ;
  }else if(nLeft2 - 20 < nScrollLeft){
    nScroll = nLeft2 - 20 ;
    if(nScroll < 0) nScroll = 0 ;
  }
  if(nScroll >= 0) od.body.scrollLeft = nScroll ;
}
</script>
<script language="javascript" type="text/javascript">
  function getpopUp(cCommand,nHeight,nWidth,cScrollBar){
    cCommand = '/plugin/'+cCommand+'/'+cCommand+'.php' ;    
    window.open('main.php?__par=./'+cCommand,'InsertTable'+cCommand,'status=no,scrollBars=' + cScrollBar + ',height=' + nHeight + ',width=' + nWidth + ",screenx=" + (screen.availWidth - nWidth) / 2 + ",screeny=" + (screen.availHeight - nHeight)/2) ;
  }
</script>
<style type="text/css">
.styleIcons{ padding:1px 1px 1px 1px; border:0px }  
.styleIcons:hover{background-color:#ffd397;cursor:default;border: 1px solid #000080;padding: 0px 0px 0px 0px}
.styleIconsClose:hover{background-color:#ffd397}
.styleIcons-Disable{ padding:1px 1px 1px 1px; border:0px;opacity: 0.2; cursor:default}  
.styleTabExt {border: 1px solid black;padding:2px 2px 2px 2px;height:20px;margin:1px 1px 1px 0px;background-color:;cursor:default;vertical-align:bottom}
.styleTabExt-Selected {border: 1px solid blue;padding:2px 2px 2px 2px;background-color:#F4F4FF;height:20px;margin:1px 1px 1px 0px;cursor:default;vertical-align:bottom;font-weight:bold;color:#000099}
.styleTabLink {cursor:default;padding:2px 2px 2px 2px}
.styleTabLink:hover{color:#000000;text-decoration:underline}
.styleCloseExt{color:#333333}
.styleCloseExt:hover{color:#999999}
.styleTabFile {border: 1px solid black;padding:2px 2px 2px 2px;height:20px;margin:1px 1px 1px 0px;background-color:#b4cef1;cursor:default;vertical-align:bottom}
</style>