<?php
  include 'df.php' ;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title></title>
</head>
<style type="text/css">
  .tipsPar-Select {color:#0033FF; font-weight:bold}
</style>
<?php include 'project_edit_area.jscript.php' ?>
<style>
.tooltip {
  position: absolute;
  display: none;
  background-color: #E4E4E4;
  font-family:Arial, Helvetica, sans-serif;
  font-size:12px;
  max-width:90%
}
</style>
<body marginheight="0" marginwidth="0" onLoad="checkCookies()" onScroll="ScrollBody();">
<form name="form1" method="post" action="">
<table border="0" cellspacing="0" cellpadding="0" width="100%">
    <tr>
      <td valign="top"><textarea name="cSource" rows="1" cols="5000" id="cSource" onKeyPress="return cSource_onKeyPress(this,event,'press')" onKeyDown="return cSource_onKeyPress(this,event,'down')" style="font-family:Courier New; font-size:13px; min-height:100%; border-width:0px; line-height:20px" onMouseDown="hideWMTT()"></textarea> 
    <input name="cTMPInsert" type="hidden" value="">
    </tr>
  </table>  

  <div class="tooltip" id="showCommand" style="width: 80px; display: none; left: 0px; top: 0px">
    <div class="content">
      <select name="cCom" style="border:1px solid #999999;width:100%" size="15" onKeyPress="cCom_onKeyDown(this,event)" onKeyDown="cCom_onKeyDown(this,event)" onChange="pickCommand(this)" id="commandList">
      </select>
    </div>
  </div>
  <div class="tooltip" id="showToolTips" style="width: 10px; display: none; left: 0px; top: 0px; border-width:1px; max-width:90%">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
      <td bgcolor="#666666"><input name="cDefaultTips" type="hidden" value=""><table width="100%" border="0" cellspacing="1" cellpadding="2">
              <tr>
                <td bgcolor="#FFFFCC" nowrap id="tipContainner" style="font-size:11px "></td>
              </tr>
            </table></td>
      </tr>
    </table>
  </div>
</form>
</body>
</html>