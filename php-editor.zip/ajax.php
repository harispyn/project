<?php
  if(!defined("main")){
    define("main","1") ;
  }

  $lNoJS = true ;
  $lFuncOnly = true ;
  include './include/database.php' ;
  eval(getVar()) ;
  IsDatabase() ;

  if(!empty($__par)){
    SaveSetting('__OldPar',$__par) ;
    $__par = GetSetting($__par,"xx") ;
    if($__par == "xx"){
      $__par = GetSetting('__OldPar') ;
    }

    $nParam = strpos($__par,"?") ;
    if($nParam){      
      $cParam = substr($__par,$nParam+1) ;
      $vaParam = split("&",$cParam) ;
      foreach($vaParam as $key=>$value){
        $va = split("=",$value) ;

        $value = "$" .  $va[0] . " = '" . $va [1] .  "' ;" ;
        eval($value) ;
      }
      $__par = substr($__par,0,$nParam) ;
    }

    if(is_file($__par)){
      include $__par ;

      if(!empty($cKey)){
        $nFunc = strpos($cKey,"(") ;
        if($nFunc){
          $cEval = substr($cKey,0,$nFunc + 1) . "\$" . "_POST" ;
          $cEval1 = substr($cKey,$nFunc + 1) ;
          if(trim($cEval1) <> ")"){
            $cEval1 = "," . $cEval1 ;
          }
          $cEval = $cEval . $cEval1 . " ;" ;
          eval($cEval) ;
        }
      }
    }
  }
?>