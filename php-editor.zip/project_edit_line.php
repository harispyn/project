<html><head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
<style>
  .cellRow{font-size:10px;text-align:right;color:#FFFFFF;height:20px ;cursor:default;}
  .cellBookmark{font-size:10px;text-align:right;color:#FFFFFF;background-color:#f90000;height:20px ;cursor:default;}
</style>
<body marginheight="0px" marginwidth="0px">
<table width="100%"  border="0" cellspacing="0" cellpadding="0" id="tbRows">
  <?php 
    $nMax = GetSetting("MaxRow",1000) ;
    for($n=1;$n<=$nMax;$n++){
      echo('<tr><td title="Bookmark This Line" class="cellRow" onClick="self.parent.ToggleBookmark(' . $n . ');self.parent.GotoRow(' . $n . ');">' . $n . '</td></tr>') ;
    } 
  ?>
</table>
<table width="10px"  border="0" cellspacing="0" cellpadding="0" id="tbTest">
  <tr><td class="cellRow"></td></tr>
</table>
<div style="width:100px;height:2000px;background-color:#3168D5;position: absolute;top:0;left:0" id="rowHide"></div>
</body>
</html>