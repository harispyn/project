<?php
  include 'df.php' ;
  
  if(empty($cAction)){
    $cAction = "" ;
  }
  if(empty($cUserName)){
    $cUserName = "" ;
  }
  $cError = "" ;
  $nLevel = 0 ;
  if(!empty($cAction)){
    $vaUserName = IncludeFile() ;
    if(GetSetting("optUserList","N") == "N" || empty($vaUserName)){
      if(md5($cUserName) == "b70395798360bbb770035dbf6e68101f" && md5($cPassword) == "bdb743bf338a0dde38d48ba02890bcbd"){
        $cError = "" ;
      }else{
        $cError = "User / Password Salah" ;
      }
    }else{
      $cError = "User / Password Salah" ;      
      $cKey = strtolower($cUserName) ;
      if(isset($vaUserName [$cKey])){
        if(md5($cPassword) == $vaUserName[$cKey]['Password']){
          $cError = "" ;
          $nLevel =  $vaUserName[$cKey]['Level'] ;
        }
      }
    }
    if(empty($cError)){
      if(GetSetting("optUserLock","N") == "Y" && $cParent !== "mainFrame"){
        $cError = "Project Parent Not Found ....!" ;
      }else{
        SaveSetting('cLogin',1) ;
        SaveSetting("cUserName",$cUserName) ;
        SaveSetting("cPassword",md5($cPassword)) ;
        SaveSetting("nLevel",$nLevel) ;
        direc('index.php') ;
      }
    }
  }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Mars Tech Global</title>
</head>
<script langauge="javascript" type="text/javascript">
function checkParent(cLock){
  document.form1.cParent.value = self.parent.name ;
}
</script>
<body onLoad="fieldfocus(document.form1.cUserName);checkParent();">
<form name="form1" method="post" action="main.php?__par=<? getlink('login.php') ?>">
<br>
<br>
<br>
<br>
<br>
<br>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center">
    <table width="300"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
        <table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="window_title_left" width="6px">&nbsp;</td>
            <td class="window_title_center">Login to MARS-Editor</td>
            <td class="window_title_right" width="6px">&nbsp;</td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td>        
        <table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td class="window_frame_left" width="2px"></td>
            <td class="window_body">
            <table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
              <tr>
                <td style="border:1px solid #999999;padding:4px">
                  <table width="100%"  border="0" cellspacing="0" cellpadding="1">
                    <tr>
                      <td width="100px">&nbsp;UserName</td>
                      <td width="5px">:</td>
                      <td>
                      <?php
                        $lReadOnly = false ;
                        if(GetSetting("optUserLock","N") == "Y"){
                          $lReadOnly = true ;
                        }
                        $txt->Show("cUserName",$cUserName,20,20,$lReadOnly) ;
                      ?>
                      </td>
                    </tr>
                    <tr>
                      <td>&nbsp;Password</td>
                      <td>:</td>
                      <td>
                      <?php
                        $txt->Type = "Password" ;
                        $txt->Show("cPassword","",20,20) ;
                      ?>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td height="20px" style="border:1px solid #999999">
                  <table width="100%" style="padding:2px">
                    <tr>
                      <td align="center">
                      <?php
                        $txt->HiddenField("cAction",$cAction) ;
                        $txt->HiddenField("cParent","") ;

                        $txt->onClick="document.form1.cAction.value='Save';submit()" ;
                        $txt->ButtonField("cmdSave","Login") ;
                      ?>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
            </td>
            <td class="window_frame_right" width="2px"></td>
          </tr>
        </table>        
        </td>
      </tr>
      <tr>
        <td class="window_frame_bottom"></td>
      </tr>
      <tr><td><?= $cError ?></td></tr>
    </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>