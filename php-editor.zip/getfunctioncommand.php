<?php
include 'df.php' ;

if(!empty($cCom)){
  $cCom = trim($cCom) ;
  $cFile = "./command/phpcomand" . strtolower(substr($cCom,0,1)) . ".txt" ;
  $lTipsFound = false ;
  $cCom .= "(" ;
  $nLen = strlen($cCom) ;
  if(is_file($cFile)){
    $lines = file($cFile) ;
    $cFunctionType = "PHP" ;
    foreach ($lines as $key=>$value) {
      if(substr(trim($value),0,1) == "#"){
        $cFunctionType = trim($value) ;
      }
      $x = trim($value) ;
      $w = strtoupper(substr($x,0,$nLen)) ;
      if($w == trim(strtoupper($cCom))){
        $lTipsFound = true ;
        showTips($cFunctionType . " Function",$x) ;
        break ;
      }
    }
  }
  if(!$lTipsFound){
    if(!SeekUDF($cCom)){
      echo('hideTips() ;') ;
    }
  }
}

function SeekUDF($cCom){
  $vaFile = SeekPHPModul() ;
  foreach($vaFile as $key=>$vaFile){      
    $cFile = $vaFile ['File'] ;
    $cType = $vaFile ['Type'] ;
    if(is_file($cFile)){
      $lines = file($cFile) ;  
      $lFunction = false ;
      $cFunction = "" ;
      $nLen = strlen($cCom) ;
      foreach($lines as $key=>$value){
        $value = trim($value) ;
        if(substr($value,0,9) == "function "){
          $lFunction = true ;
        }
        if($lFunction){
          $value = str_replace("'","\'",str_replace('"','\"',str_replace("$","\$",str_replace(" ","",str_replace("\n","",str_replace("function ","",$value)))))) ;
          $cFunction .= $value ;
          $nPos = strpos($cFunction,"{") ;
          
          $cFunctionType = "UDF-" . $cType . " Function - on " . $vaFile ['name'] ;
          if($nPos !== false){
            $cFunction = substr($cFunction,0,$nPos) ;
            // Check Nama Function
            if(substr($cFunction,0,$nLen) == $cCom){
              $cFunction = str_replace(",",", ",$cFunction) ;
              $lTipsFound = true ;
              showTips($cFunctionType,$cFunction) ;
              return true ;
            }        

            $lFunction = false ;
            $cFunction = "" ;
          }
        }
      }
    }
  }
  return false ;
}

function showTips($cFunctionType,$cBody){
  echo('
        var o = document.getElementById("tipContainner") ;
        o.width = "" ;
        o.innerHTML = "' . "<font color=red><strong>" . str_replace(" ","&nbsp;",$cFunctionType) . "</strong></font><br>" . $cBody . '" ;
        document.form1.cDefaultTips.value = o.innerHTML ;
        showTips() ;
        ') ;
}

function SeekPHPModul(){
  $vaRetval = array() ;
  $_vaP = split("_sub_",GetSetting("cSession_DevProject")) ;
  $vaProject [0] = $_vaP [0] ;
  if($vaProject [0] !== GetSetting("cSession_DevProject")){
    $vaProject [1] = GetSetting("cSession_DevProject") ;
  }
  foreach($vaProject as $keyDir=>$valDir){
    $cDir = GetSetting("project_dir") . '/' . $valDir . '/include' ;
    if(is_dir($cDir)){
      $d = dir($cDir) ;
      $nRow = 0 ;
      $vaExt = array("mod~PHP","mod.php~PHP","js~JavaScript","js.php~JavaScript","jscript~JavaScript","jscript.php~JavaScript") ;
      while (false !== ($entry = $d->read())) {      
        if(is_file($cDir . '/' . $entry)){
          foreach($vaExt as $key=>$value){
            $_va = split("~",$value) ;
            if(strtolower(substr($entry,strlen($entry)-strlen($_va[0]))) == $_va[0]){
              $nRow ++ ;
              $vaRetval [$nRow]['File'] = $cDir . '/' . $entry ;
              $vaRetval [$nRow]['Type'] = $_va[1] ;
              $vaRetval [$nRow]['name'] = $valDir . '/' . $entry ;
            }
          }
        }
      }
    }
  }
  return $vaRetval ;
}  
?>