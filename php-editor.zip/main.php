<?php
  if(!defined("main")){
    define("main","1") ;
  }
  include './include/database.php' ;
  eval(getVar()) ;
  IsDatabase() ;
  
  if(empty($__par) && GetSetting('__OldPar','') !== ''){
    $__par = GetSetting('__OldPar','') ;
  }  
  
  if(!empty($__par)){
    SaveSetting('__OldPar',$__par) ;
    $__par = GetSetting($__par,"xx") ;
    if($__par == "xx"){
      $__par = GetSetting('__OldPar') ;
    }

    $nParam = strpos($__par,"?") ;
    if($nParam){
      $cParam = substr($__par,$nParam+1) ;
      $vaParam = split("&",$cParam) ;
      foreach($vaParam as $key=>$value){
        $va = split("=",$value) ;
        
        $value = "$" .  $va[0] . " = '" . $va [1] .  "' ;" ;
        eval($value) ;
      }
      $__par = substr($__par,0,$nParam) ;
    }    
    
    if(is_file($__par)){
      include $__par ;
      echo('<div id="__currentFile" style="width:1px;height:1px;visibility:hidden;">' . $__par . '</div>') ;
    }else{
      echo("File Tidak Ditemukan ....") ;
    }
  }
?>