<?php
  $cPlugAction = "Close" ;
  $cOnClick = 'javascript:if(confirm(&quot;Program Akan Ditutup ?&quot;)) ajax(&quot;./plugin/close/init.ajax.php&quot;,&quot;Logout()&quot;); return false ;' ;
?>