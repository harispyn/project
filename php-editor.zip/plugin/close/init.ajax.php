<?php
  include 'df.php' ;
  
function Logout($va){
  SaveSetting("cLogin",0) ;
  echo('window.open("./","_self");') ;
}
?>