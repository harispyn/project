<?php
  $cPlugAction = "Create User";
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/user/user.php',false) . "','FrmUser','Create User',500,400,'',true);return false" ;
?>
