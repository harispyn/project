<?php
  include 'df.php' ;
  include 'user.func.php' ;
  
function SeekUserName($va){
  $cFileName = GetFileName() ;
  IncludeFile() ;
  $cKey = strtolower(trim($va['cUserName'])) ;
  if(isset($vaUserName[$cKey])){
    echo('alert("User Sudah Ada ....!");
          with(document.form1){
            cUserName.value = "" ;
            fieldfocus(cUserName) ;
          }
         ') ;
  }
}

function DeleteUser($va){
  $cFileName = GetFileName() ;
  $vaUserName = IncludeFile() ;
  $cKey = strtolower(trim($va['cUserName'])) ;
  if(isset($vaUserName[$cKey])){
    unset($vaUserName [$cKey]) ;
    SaveArray($vaUserName,$cFileName) ;
  }
  echo('document.form1.submit();') ;
}
?>