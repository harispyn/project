<?php
  include 'df.php' ;
  include 'user.db' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Create User</title>
</head>
<?php include 'user.jscript' ?>
<body onLoad="fieldfocus(document.form1.cUserName);">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:4px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="100px">&nbsp;User</td>
        <td width="5px">:</td>
        <td><?php $txt->Show("cUserName","",20,20) ?></td>
      </tr>
      <tr>
        <td>&nbsp;Password</td>
        <td width="5px">:</td>
        <td>
        <?php 
          $txt->Type = "Password" ;
          $txt->Show("cPassword","",20,20) ;
        ?>
        </td>
      </tr>
      <tr>
        <td>&nbsp;User Level</td>
        <td width="5px">:</td>
        <td>
        <?php 
          $txt->NumberField("nLevel","0",4,4) ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #999999;padding:4px" align="center">
    <?php
      if(!empty($vaUserName)){
        foreach($vaUserName as $key=>$value){
          $vaArray [$key] = array("Action"=>"<a href='#' onClick='return self.parent.DeleteUser(\"" . $key . "\")'>[Del]</a> <a href='#' onClick='return self.parent.EditUser(\"" . $key . "\",\"" . $value['Level'] . "\");'>[Edit]</a>","UserName"=>$value ['UserName'],"Level"=>$value['Level']) ;
        }

        $dbg->Array = $vaArray ;
        $dbg->Height="100%" ;
        $dbg->Width="450px" ;
        $dbg->Col['Action']['Width'] = 80 ;
        $dbg->Col['Action']['Align'] = "Center" ;

        $dbg->Col['UserName']['Width'] = 290 ;

        $dbg->Col['Level']['Align'] = "Center" ;
        $dbg->Col['Level']['Width'] = 60 ;
        $dbg->Scrolling = "Vertical" ;
        $dbg->dataBind() ;
      }
    ?>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:5px" align="right">
    <?php
      $txt->HiddenField("cAction") ;
      $txt->ButtonField("cmdSave","Save") ;
          
      $txt->onClick = "CloseForm()" ;
      $txt->ButtonField("cmdCancel","Cancel") ;
    ?>
    </td>
  </tr>
</table>
</form>
</body>
</html>