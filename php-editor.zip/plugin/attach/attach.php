<?  
echo('
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Frameset//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>File New</title>
</head>
<frameset rows="90,22,*" frameborder="no" border="0" framespacing="0">
  <frame src="main.php?__par=' . getlink('./plugin/attach/top.php',false) . '" name="topFrame" marginwidth="1" marginheight="1" scrolling="no" id="topFrame" />
  <frame src="main.php?__par=' . getlink('./plugin/attach/middle.php',false) . '" name="middleFrame" marginwidth="1" marginheight="1" scrolling="no"/>
  <frame src="main.php?__par=' . getlink('./plugin/attach/bottom.php',false) . '" name="bottomFrame" marginwidth="1" marginheight="1" scrolling="yes" />
</frameset>
<noframes>
<body>
</body></noframes>
</html>
')
?>
