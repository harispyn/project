<?php
  include 'df.php' ;
  include 'top.db' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<?php include 'top.jscript' ?>
<body>
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>" enctype="multipart/form-data">
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="cell_blue"><table width="100%"  border="0" cellspacing="1" cellpadding="0">
      <tr>
        <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="1">
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
          <tr>
            <td width="12%">&nbsp;Directory</td>
            <td width="1%">:</td>
            <td>
            <?php
              $txt->Show("cDirectory",$cDirectory,255,50,true) ;
            ?>
            </td>
          </tr>
          <tr>
            <td>&nbsp;File</td>
            <td>:</td>
            <td><input name="cFile" type="file" size="40" onKeyUp="validate(this,event)"></td>
          </tr>
          <tr>
            <td colspan="3" height="5"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="27" align="right" class="cell_white">
        <?php
          $txt->onClick = "pickFile()" ;
          $txt->ButtonField("cmdSave","Save") ;
          
          $txt->onClick="self.parent.CloseForm()" ;
          $txt->ButtonField("cmdCancel","Cancel") ;
          $txt->HiddenField("cAction","") ;
        ?>
        &nbsp;</td>
      </tr>
    </table></td>
  </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</body>
</html>
