<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<script langauge="javascript">
  function SetDir(){
    with(self.parent.document.getElementById("topFrame").contentDocument.form1){
      cDirectory.value = "<?= GetSetting("project_dir") ?>" ;
      optRadioButton[1].checked = true ;
      cFileType.disabled = true ;
      fieldfocus(cFileName) ;
    }
    return false ;
  }
</script>
<body class="cell_blue">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%"  border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td class="cell_oddrow"><strong>&nbsp;<a href=";;" onClick="javascript:return SetDir()">:: Project</a></strong></td>
  </tr>
</table>
</form>
</body>
</html>
