<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/attach/attach.php',false) . "','FrmAttachFile','Attach File',500,500,'',true); return false" ;
?>