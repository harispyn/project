<?
  $cPlugAction = "javascript:Preview();" ;
?>