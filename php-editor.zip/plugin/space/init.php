<?
	$nWindowHeight = 250 ;
	$nWindowWidth = 500 ;
	$cPlugAction = "Insert Character" ;
	$cOnClick = 'javascript:var o = document.getElementById(&quot;Editor&quot;); o.contentDocument.form1.cTMPInsert.value= &quot;&&quot;+&quot;nbsp&quot;+&quot;;&quot;; return false ;' ;
?>