<?php
  $cPlugAction = "Find Previous" ;
  $cOnClick = 'javascript:FindPrev(); return false ;' ;
?>