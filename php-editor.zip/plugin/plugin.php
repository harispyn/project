<?php
  $cPluginDir = './plugin' ;
  $nIcons = 0 ;
  $vaPlug = array(array("Name"=>"close","Title"=>"Close"),'',
          array("Name"=>"new","Title"=>"New File"),
          array("Name"=>"open","Title"=>"Open File"),
          array("Name"=>"save","Title"=>"Save CTRL-S"),
          array("Name"=>"preview","Title"=>"Project Preview"),'',
          array("Name"=>"form","Title"=>"Form"),
          array("Name"=>"textbox","Title"=>"Text/Number/Date Box"),
          array("Name"=>"hiddenfield","Title"=>"Hidden Field"),
          array("Name"=>"checkbox","Title"=>"Checkbox / Radio Button"),
          array("Name"=>"listbox","Title"=>"List/Menu Box"),'',          
          array("Name"=>"button","Title"=>"Button"),
          array("Name"=>"textarea","Title"=>"Text Area"),
          array("Name"=>"filefield","Title"=>"File Field"),'',          
          array("Name"=>"table","Title"=>"Insert Table"),          
          array("Name"=>"image","Title"=>"Images : Image"),'',
          array("Name"=>"indent","Title"=>"Indent"),
          array("Name"=>"space","Title"=>"Caracter Space"),
          array("Name"=>"break","Title"=>"Line Break"),
          array("Name"=>"charmap","Title"=>"Special Characters"),'',
          array("Name"=>"html-comment","Title"=>"HTML Comment"),
          array("Name"=>"horizontalrule","Title"=>"Horizontal Rule"),
          array("Name"=>"script","Title"=>"Insert Java Script"),'',
          array("Name"=>"php-comment","Title"=>"PHP Comment"),
          array("Name"=>"php","Title"=>"PHP Code Block"),
          array("Name"=>"echo","Title"=>"Echo"),          
          array("Name"=>"line-break","Title"=>"Line Break"),
          array("Name"=>"moretag","Title"=>"More Tag"),'',
          array("Name"=>"setup","Title"=>"Setup System"),
          array("Name"=>"update","Title"=>"Update PHP-Editor"),
          array("Name"=>"help","Title"=>"Help"),'',          
          array("Name"=>"user","Title"=>"Setup User"),
          array("Name"=>"change-password","Title"=>"Change Password"),
          array("Name"=>"menu-setup","Title"=>"Menu Setup"),
          array("Name"=>"project-list","Title"=>"Project List Setup"),'break',
          array("Name"=>"tableformated","Title"=>"Table Formated"),
          array("Name"=>"fw","Title"=>"Form Wizart"),
          array("Name"=>"pdf","Title"=>"Report PDF"),'',
          array("Name"=>"datasource","Title"=>"Mysql Datasource"),
          array("Name"=>"dbgrid","Title"=>"DBGrid"),
          array("Name"=>"menu","Title"=>"Menu Editor"),'',
          array("Name"=>"test-compile","Title"=>"Test Project"),
          array("Name"=>"compile","Title"=>"Compile Project"),'',
          array("Name"=>"zip","Title"=>"Downloads Project"),
          array("Name"=>"unzip","Title"=>"Uploads Project"),'',
          array("Name"=>"attach","Title"=>"Attach File"),'',
          array("Name"=>"find","Title"=>"Find"),
          array("Name"=>"find-next","Title"=>"Find Next"),
          array("Name"=>"find-prev","Title"=>"Find Previous"),'',
          array("Name"=>"link","Title"=>"Link"),
          array("Name"=>"unlink","Title"=>"Unlink"),'',
          array("Name"=>"project-report","Title"=>"Project Report"),
          array("Name"=>"project-backup","Title"=>"Project Backup"),'',
          array("Name"=>"bookmark","Title"=>"Bookmark Alt+6"),
          array("Name"=>"bookmark-next","Title"=>"Next Bookmark Alt+7"),
          array("Name"=>"bookmark-prev","Title"=>"Previous Bookmark Alt+8")) ;
  foreach($vaPlug as $key=>$value){
    if(empty($value)){
      $vaIcon [++$nIcons] = "" ;
    }elseif($value == "break"){
      $vaIcon [++$nIcons] = "break" ;
    }else{
      $c = $cPluginDir . '/' . $value['Name'] . '/images' ;        
      if(is_dir($c)){
        $cFileInit = $cPluginDir . '/' . $value['Name'] . '/init.php' ;
        $cOnClick = "" ;
        $cPlugAction = "" ;
        $cScrollBar = "no" ;
        $cURLTarget = "_self" ;
        $nWindowHeight = 0 ;
        $nWindowWidth = 0 ;
        if(is_file($cFileInit)){
          include $cFileInit ;
        }
        if($cPlugAction == ""){
          $cPlugAction = "javascript:getpopUp('" . $value ['Name'] . "'," . $nWindowHeight . "," . $nWindowWidth . ",&quot;" . $cScrollBar . "&quot;) ;" ;
        }
        $vaIcon [++$nIcons] = array("src"=>$c . '/' . $value['Name'] . '.gif',"Title"=>$value['Title'],"Action"=>$cPlugAction,"OnClick"=>$cOnClick,
                                    "Target"=>$cURLTarget,"Name"=>$value ['Name']) ;
      }
    }
  }
?>