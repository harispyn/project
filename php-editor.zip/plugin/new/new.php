<?php
  include 'df.php' ;
  include 'new.db.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include 'new.jscript.php' ?>
<body onLoad="dirLoad();">
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:4px" height="10px">
      <table width="100%"  border="0" cellspacing="0" cellpadding="1">
        <tr>
          <td width="12%">&nbsp;Directory</td>
          <td width="1%">:</td>
          <td width="90%">
          <?php
            $txt->Style = "width:100%" ;
            $txt->Show("cDirectory",$cDirectory,255,0,true) ;
          ?>
          </td>
        </tr>
        <tr>
          <td>&nbsp;Name</td>
          <td>:</td>
          <td>
          <?php
            $txt->Style = "width:100%" ;
            $txt->Show("cFileName",$cFileName,255,0) ;
          ?>
          </td>
        </tr>
        <tr>
          <td>&nbsp;Type</td>
          <td>:</td>
          <td>
          <?php
            $txt->Caption = "File" ;
            $txt->Checked = true ;
            $txt->RadioButton("optRadioButton","F") ;
            
            $txt->Caption = "Directory" ;
            $txt->RadioButton("optRadioButton","D") ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #999999;padding:4px">
      <table width="100%" height="100%" border="0" cellspacing="0" cellpadding="1">
        <tr>
          <td><strong><a href="#" onClick="return setProject();">PROJECT / DIRECTORY</a></strong></td>
          <td width="3px"></td>
          <td height="20px" width="300px" align="center"><strong>FILE TYPE</strong></td>
        </tr>
        <tr>
          <td><iframe id="frm-body" style="width:100%;height:100%;border:1px solid #666666"></iframe></td>
          <td width="3px"></td>
          <td width="300px">
          <?php
            $va [0] = array(" "=>"0","Ext"=>".php"         ,"Description"=>"PHP Form (*.php)");
            $va [1] = array(" "=>"0","Ext"=>".db.php"      ,"Description"=>"PHP Database Function (*.db)");
            $va [2] = array(" "=>"0","Ext"=>".ajax.php"    ,"Description"=>"AJAX Function (*.ajax)");
            $va [3] = array(" "=>"0","Ext"=>".jscript.php" ,"Description"=>"Java Script Function (*.jscript)");
            $va [4] = array(" "=>"0","Ext"=>".mod.php"     ,"Description"=>"PHP Modul (*.mod)");
            $va [5] = array(" "=>"0","Ext"=>".report.php"  ,"Description"=>"PHP Report (*.report)");
            $va [6] = array(" "=>"0","Ext"=>".html"        ,"Description"=>"HTML Document (*.html)");
            $va [7] = array(" "=>"0","Ext"=>".js"          ,"Description"=>"Javascript Document (*.js)");
            $va [8] = array(" "=>"0","Ext"=>".css"         ,"Description"=>"Style Sheets (*.css)");
            $va [9] = array(" "=>"0","Ext"=>".txt"         ,"Description"=>"Text Document (*.txt)");
            $va [10] = array(" "=>"0","Ext"=>".menu.php"    ,"Description"=>"Menu Document (*.menu)");
            $va [11] = array(" "=>"0","Ext"=>".ini.php"     ,"Description"=>"Configuration Setting (*.ini)") ;
         
            $dbg->Array = $va ;
            $dbg->Height = "100%" ;
            $dbg->Col[' ']['Type'] = "Checkbox" ;
            $dbg->Col[' ']['Width'] = 20 ;
            $dbg->Col[' ']['Align'] = 'center' ;
            $dbg->Col['Ext']['Width'] = 75 ;
            $dbg->Col['Description']['Width'] = 180 ;
            $dbg->Scrolling = "vertical" ;
            $dbg->Name = "dbg" ;
            $dbg->dataBind() ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999">
      <table width="100%" style="padding:2px">
        <tr>
          <td align="right">
          <?php
            $txt->ButtonField("cmdSave","Save") ;

            $txt->ButtonField("cmdCancel","Cancel") ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>