<?php
  include 'df.php' ;
  
  if(empty($cAction)){
    $cProject = GetSetting("cSession_DevProject") ;
    $cDirectory = GetSetting("project_dir") . "/" . $cProject ;
    $cFileName = GetSetting("cSession_NewFile") ;
  }
?>