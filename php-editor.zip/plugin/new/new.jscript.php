<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function cmdSave_onClick(field){
var o = document.form1 ;  
  if(o.optRadioButton[0].checked){
    ajax('','SaveNewFile()',GetFormContent()) ;
  }else{
    if(confirm("Anda Akan Membuat Directory Baru ?")){
      ajax('','CreateNewDirectory()',GetFormContent()) ;
    }
  }
}

function cmdCancel_onClick(field){
  ajax('','SaveDevProject()',GetFormContent()) ;
}

function CreateNewFile(){
var cDir = document.form1.cDirectory.value ;
var cFile = document.form1.cFileName.value ;
var cFileName = "" ;

  if(replaceAll(cDir," ","") !== "" && replaceAll(cFile," ","") !== ""){
    cFile = cFile.toLowerCase() ;    
    for(n=0;n<=dbg.Rows()-1;n++){
      if(dbg.cellValue(n,0)){
        if(cFileName !== ""){
          cFileName += '`' ;
        }
      
        cFileName += cFile + dbg.cellValue(n,1) ;
      }
    }
  
    if(cFileName !== ""){
      with(self.parent.document.form1){
        action = "main.php?__par=<? getlink('./project_edit.php') ?>&cOpenDir=" + cDir + "&cOpenFile=" + cFileName ;
        submit() ; 
      }
    }else{
      alert("Type File Belum anda Pilih") ;
    }
  }else{
    alert("Nama Directory / File Tidak Boleh Kosong ....!") ;
  }
  return false ;
}

function dirLoad(){
var o = document.getElementById("frm-body") ;
  if(o !== null){
    o.src = "main.php?__par=./plugin/new/bottom.php" ;
  }
}

function setProject(){
  ajax('','SetProject()') ;
  return false ;
}
</script>