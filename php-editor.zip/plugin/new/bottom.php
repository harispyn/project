<?php
  include 'df.php' ; 
  include 'bottom.db' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<?php include 'bottom.jscript' ?>
<style type="text/css">
  .DirOpen {padding:2px 0px 2px 0px; cursor:default}
  
  .DirOpen-Select {background-color:#0033CC; color:#FFFFFF; padding:2px 0px 2px 0px; cursor:default}
</style>
<body onUnload="savePos()" onLoad="getPos()">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%"  border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td class="cell_eventrow">        
    <?php
      getPHPFile(GetSetting("project_dir"),0) ;
    ?>
    </td>
  </tr>
</table>
<?php
  $txt->HiddenField("cDirOpen",$cDirOpen) ;
?>
</form>
</body>
</html>
