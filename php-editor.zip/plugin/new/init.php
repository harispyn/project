<?php
  $cPlugAction = "New" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/new/new.php',false) . "','FrmNewFile','New File / Directory',800,500,'',true); return false;" ;
?>