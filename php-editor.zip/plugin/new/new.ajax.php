<?php
  include 'df.php' ;

function SaveNewFile($va){
  SaveSetting("cSession_NewFile",$va['cFileName']) ;
  SaveSetting("cSession_DevProject",$va['cDirectory']) ;
  echo('CreateNewFile() ;') ;
}
  
function CreateNewDirectory($va){
  $cNew = $va['cDirectory'] . '/' . $va['cFileName'] ;
  if(!is_dir($cNew)){
    CreateDir($cNew) ;

    $cFile = $cNew . '/df.php' ;
    $handle = fopen($cFile, "w");
    fwrite($handle,"<?php defined( 'main' ) or die( 'Restricted access' ) ?>") ;
    fclose($handle) ;      
    chmod($cFile,0777) ;

    $cFile = $cNew . '/index.php' ;
    $handle = fopen($cFile, "w");
    fwrite($handle,"Restricted access") ;
    fclose($handle) ;
    chmod($cFile,0777) ;
    
    echo('dirLoad();') ;
  }
}

function SaveDevProject($va){
  SaveSetting("cSession_NewFile",$va['cFileName']) ;
  SaveSetting("cSession_DevProject",$va['cDirectory']) ;
  echo('CloseForm();') ;
}

function SetProject($va){
  echo('
  with(document.form1){
    optRadioButton[0].disabled = true ;
    optRadioButton[1].disabled = true ;
    optRadioButton[1].checked = true ;
    cDirectory.value = "' . GetSetting("project_dir") . '" ;
  }
  ') ;
}
?>