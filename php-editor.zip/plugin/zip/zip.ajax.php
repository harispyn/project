<?php
  include 'df.php' ;
  
function ProsessZip($va){
  include 'zip.lib.php' ;

  $cProject = GetSetting("cSession_DevProject","") ;
  $cFileName = $cProject . '_' . date("Ymd_His") . ".zip" ;
  
  $cDir = GetSetting("project_dir") . '/' . $cProject ;
  $cDirDownloads = CreateTmpDir() ;
  $cZipFile = $cDirDownloads . "/" . $cFileName ;
    
  getPHPFile($cDir,$vaFile) ;
  $ziper = new zipfile();
  $ziper->zipName=$cZipFile ;
  $ziper->addFiles($vaFile,$cDir);
  $ziper->output();
  
  echo('
    o = document.getElementById("idFileDownloads") ;
    if(o !== null){
      o.innerHTML = "<a href=\"' . $cZipFile . '\">' . $cFileName . '</a>" ;
    }
  ') ;
}

function getPHPFile($cDir,&$vaFile){
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry)){
        if(substr($entry,0,1) !== "."){
          getPHPFile($cDir . '/' . $entry,$vaFile) ;
        }
      }else if(is_file($cDir . '/' . $entry)){
        $vaFile [$cDir . '/' . $entry] = $cDir . '/' . $entry ;
      }
    }
  }
}
?>