<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function cmdProsess_onClick(field){
  ajax('','ProsessZip()',GetFormContent()) ;
}
</script>