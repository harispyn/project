<?php
  include 'df.php' ;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Downloads Project</title>
</head>
<?php include 'zip.jscript.php' ?>
<body marginheight="0" marginwidth="0">
<form name="form1" method="post" action="main.php?__par=<?= getlink($__par,false) ?>">
<?php
  $cProject = GetSetting("cSession_DevProject","") ;
  $cDir = GetSetting("project_dir") . '/' . $cProject ;
  ShowPHPFile($cDir,0,$txt) ;
?>
</form>
</body>
</html>
<?php
function ShowPHPFile($cDir,$nLevel,$txt){
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry)){
        if(substr($entry,0,1) !== "."){
          $vaDir [$entry] = $entry ;
        }
      }else if(is_file($cDir . '/' . $entry)){
        $vaFile [$entry] = $entry ;
      }
    }
    
    if(!empty($vaDir)){
      asort($vaDir) ;
      foreach($vaDir as $key=>$value){
        $nWidth = 22 * $nLevel ;
        $cImage = '<img height="16px" width="' . $nWidth . '" src="./images/empty.gif">' ;        
        echo($cImage) ;
        $txt->CheckBox("a","") ;
        echo('<img src="./images/folder.gif">') ;
        echo("&nbsp;" . $value . "<br>") ;
        ShowPHPFile($cDir . '/' . $value,$nLevel+1,$txt) ;
      }

    }
    if(!empty($vaFile)){
      asort($vaFile) ;
      foreach($vaFile as $key=>$value){
        $nWidth = 22 * $nLevel ;
        $cImage = '<img height="16px" width="' . $nWidth . '" src="./images/empty.gif">' ;
        echo($cImage) ;
        $txt->CheckBox("a","") ;
        echo(GetIcon($value) . "&nbsp;" . $value . "<br>") ;
      }
    }
  }
}
?>