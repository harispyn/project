<?php
  include 'df.php' ;
  include 'zip.db.php' ;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Downloads Project</title>
</head>
<?php include 'zip.jscript.php' ?>
<body marginheight="0" marginwidth="0">
<form name="form1" method="post" action="main.php?__par=<?= getlink($__par,false) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:4px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="100px" height="20px"> Project Name</td>
        <td width="5px">:</td>
        <td><?php echo($cProject) ?></td>
      </tr>
      <tr>
        <td> Downloads File</td>
        <td>:</td>
        <td id="idFileDownloads">&nbsp;</td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:5px" align="right">
    <?php
      $txt->HiddenField("cAction","") ;
      $txt->ButtonField("cmdProsess","Prosess") ;
      
      $txt->onClick = "CloseForm()" ;
      $txt->ButtonField("cmdClose","Close") ;
    ?>
    </td>
  </tr>
</table>
</form>
</body>
</html>