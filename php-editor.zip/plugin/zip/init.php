<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/zip/zip.php',false) . "','FrmDownloads','Downloads Project',500,150,'',true);return false" ;
?>