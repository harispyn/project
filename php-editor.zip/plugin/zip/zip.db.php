<?php
  include 'df.php' ;

  $cProject = GetSetting("cSession_DevProject","") ;
?>