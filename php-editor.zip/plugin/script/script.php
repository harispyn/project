<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Text Box</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
	function saveTextbox(){
	var html = "" ;
		with(document.form1){
			html = '&lt;script language=&quot;javascript&quot; type=&quot;text/javascript&quot;&lt;' + chr(13) + cScript.value + chr(13) + '&lt;/script&lt;' ;
		}
		var o = window.opener.document.getElementById("Editor") ;
		o.contentDocument.form1.cTMPInsert.value = html ;
		window.close() ;
	}
	
	function keydown(field,e){
	var keynum = 0 ;
	var nSelStart = field.selectionStart ;
	
		if(window.event) // IE
		{
			keynum = e.keyCode
		}
		else if(e.which) // Netscape/Firefox/Opera
		{
			keynum = e.which
		}	
		
		if(keynum == 9){
			field.value = field.value.substring(0,nSelStart) + "\t" + field.value.substring(nSelStart) ;
			field.selectionStart = nSelStart + 1 ;
			field.selectionEnd = nSelStart + 1 ;
			return false ;
		}		
	}
</script>
<body>
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center"><table width="600" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_border"><table width="100%"  border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td class="window_silver_center">Insert Java Script </td>
            </tr>
            <tr>
              <td class="cell_white"><textarea name="cScript" rows="20" id="cScript" style="width:100% " onKeyDown="return keydown(this,event)"></textarea></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">				    <input name="cmdOK" type="button" id="cmdOK" value="OK" onClick="saveTextbox()" />
                      <input name="cmdCancel" type="button" id="cmdCancel" value="Cancel" onClick="window.close()" />
                    &nbsp;</td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
