<?
	$nWindowHeight = 400 ;
	$nWindowWidth = 650 ;
?>