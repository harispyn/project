<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Text Box</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
  function SetComponent(){
    with(document.form1){
      optButton [0].disabled = false ;
      optButton [1].disabled = false ;
      cButtonClick.disabled = false ;
      cMax.disabled = false ;
      cSize.disabled = false ;
      if(cType.value == "DateField"){
        optButton [0].disabled = true ;
        optButton [1].disabled = true ;
        optButton [1].checked = true ;
        cButtonClick.disabled = true ;
        cButtonClick.value = "" ;
        cMax.disabled = true ;
        cSize.disabled = true ;        
      }
    }
  }
  
  function Space(nLen){
  var cRetval = "" ;
    for(n=1;n<nLen;n++){
      cRetval += " " ;
    }
    return cRetval ;
  }
  
  function saveTextbox(){
  var html = "" ;
  var cReadOnly = "" ;
  var nColPos = 0 ;
  var cMaxField = "" ;
  var cSizeField = "" ;  
    with(document.form1){
      if(chkReadonly.checked){
        cReadOnly = ',true' ;
      }
      
      html = "" ;
      if(cCaption.value !== ""){
        html += '$txt->Caption = " ' + cCaption.value + '" ;\n' + Space(nColPos) ;
      }
      if(optButton[0].checked && !optButton [0]){
        html += '$txt->Button = true ;\n' + Space(nColPos) ;
        
        if(cButtonClick.value !== ""){
          html += '$txt->ButtonClick = " ' + cButtonClick.value + '" ;\n' + Space(nColPos) ;
        }
      }
      if(cOnBlur.value !== "" ){
        html += '$txt->onBlur = "' + cOnBlur.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnChange.value !== ""){
        html += '$txt->onChange = "' + cOnChange.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnClick.value !== ""){
        html += '$txt->onClick = "' + cOnClick.value + '" ;\n' + Space(nColPos) ;
      }
      
      if(cOnDblClick.value !== ""){
        html += '$txt->onDblClick = "' + cOnDblClick.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnFocus.value !== ""){
        html += '$txt->onFocus = "' + cOnFocus.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnKeyDown.value !== ""){
        html += '$txt->onKeyDown = "' + cOnKeyDown.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnKeyPress.value !== ""){
        html += '$txt->onKeyPress = "' + cOnKeyPress.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnKeyUp.value !== ""){
        html += '$txt->onKeyUp = "' + cOnKeyUp.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnMouseDown.value !== ""){
        html += '$txt->onMouseDown = "' + cOnMouseDown.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnMouseMove.value !== ""){
        html += '$txt->onMouseMove = "' + cOnMouseMove.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnMouseOut.value !== ""){
        html += '$txt->onMouseOut = "' + cOnMouseOut.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnMouseOver.value !== ""){
        html += '$txt->onMouseOver = "' + cOnMouseOver.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnMouseUp.value !== ""){
        html += '$txt->onMouseUp = "' + cOnMouseUp.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnSelect.value !== ""){
        html += '$txt->onSelect = "' + cOnSelect.value + '" ;\n' + Space(nColPos) ;
      }
      
      if(!cMax.disabled){
        cMaxField = ',' + cMax.value ;
      }

      if(!cSize.disabled){
        cSizeField = ',' + cSize.value  ;
      }

      html += '\$txt->' + cType.value + '("' + cName.value + '","' + cValue.value + '"' + cMaxField + cSizeField + cReadOnly + ') ;' ;
    }
        
    var o = self.parent.document.getElementById("Editor") ;
    o.contentDocument.form1.cTMPInsert.value = html ;
    CloseForm() ;
  }
</script>
<body onBlur="window.focus()" onLoad="document.form1.cName.focus()" marginheight="0px" marginwidth="0px">
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td align="center" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_blue"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="1" cellspacing="0">
                <tr>
                  <td width="27%" valign="top">&nbsp;Type</td>
                  <td width="2%">:</td>
                  <td width="69%"><select name="cType" id="cType" onChange="SetComponent()">
                      <option selected value="Show">Text Box</option>
                      <option value="NumberField">Number Box</option>
                      <option value="DateField">Date</option>
                    </select>
                  </td>
                  <td width="2%">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Name</td>
                  <td>:</td>
                  <td>
                  <?php
                    $txt->Show("cName","",255,40) ;
                  ?>
                  </td>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Value</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Show("cValue","",255,40) ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Caption</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Show("cCaption","",255,40) ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onBlur</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Show("cOnBlur","",255,40) ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Button</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Caption = "Yes" ;
                    $txt->RadioButton("optButton","Y") ;
                    
                    $txt->Caption = "No" ;
                    $txt->Checked = true ;
                    $txt->RadioButton("optButton","T") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;ButtonClick</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Show("cButtonClick","",255,40) ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Size</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->NumberField("cSize","20",6,6) ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Max Length </td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->NumberField("cMax","20",6,6) ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top">
                  <?php
                    $txt->Caption = "Readonly" ;
                    $txt->CheckBox("chkReadonly","checkbox") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr height="2px">
                  <td colspan="4" valign="top" class="window_frame_midle"></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onChange</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnChange","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onClick</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnClick","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onDblClick</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnDblClick","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onFocus</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnFocus","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onKeyDown</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnKeyDown","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onKeyPress</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnKeyPress","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onKeyUp</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnKeyUp","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onMouseDown</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnMouseDown","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onMouseMove</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnMouseMove","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onMouseOut</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnMouseOut","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onMouseOver</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnMouseOver","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onMouseUp</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnMouseUp","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td valign="top"> &nbsp;onSelect</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnSelect","") ;
                  ?>
                  </td>
                  <td valign="top">&nbsp;</td>
                </tr>
              </table></td>
            </tr>
            <tr height="2px">
              <td class="window_frame_midle"></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">
                  <?php
                    $txt->onClick="saveTextbox()" ;
                    $txt->ButtonField("cmdOK","OK") ;
                    
                    $txt->onClick="CloseForm()" ;
                    $txt->ButtonField("cmdCancel","Cancel") ;
                  ?>
                  &nbsp;
                  </td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
