<?
  $cPlugAction = "Insert TextBox" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/textbox/textbox.php',false) . "','FrmInsertTextBox','Insert Textbox',500,565,'',true);return false" ;
?>