<?php
  $cPlugAction = ";;" ;
  $cOnClick = 'OpenForm(\'main.php?__par=' . getlink("./plugin/test-compile/test-compile.php",false) . '\',\'Test-Compile\',\'Compile Project\',600,100,\'\',true);return false' ;  
?>