<?php
include 'df.php' ;
  
  $cProject = GetSetting("cSession_DevProject","") ;
  $cLoad = "" ;
  if(!empty($cmdProses)){
    $cLoad = "" ;
    $cDir = GetSetting("project_dir") . '/' . $cProject ;
    $cDirBin = GetSetting("project_dir") . "/bin-" . $cProject ;
    if(is_dir($cDirBin)){
      RemoveDirectory($cDirBin) ;
    }
    mkdir($cDirBin) ;
    chmod($cDirBin,0777) ;
    
    getPHPFile($cDir,$cDirBin,$vaFile) ;
    if(!empty($vaFile)){
      foreach($vaFile as $key=>$value){
        $cSource = $value['Dir'] . '/' . $value['File'] ; 
        $cBin = $value['DirBin'] . '/' . $value['File'] ;
        
        $cData = CompileData($cSource) ;        
        $handle = fopen($cBin, "w");
        fwrite($handle,$cData) ;
        fclose($handle) ;      
        chmod($cBin,0766) ;
      }
    }
  }
  
function CompileData($file){
  $vaData = file($file);
  $_va = pathinfo($file) ;
  $cExt = $_va['extension'] ;
  $nDot = strpos($_va['basename'],".") ;
  $cExt1 = "" ;
  if(!$nDot === false){
    $cExt1 = substr($_va ['basename'],$nDot+1) ;
  }
  $_vaExt = array("php"=>1,"ajax"=>1,"db"=>1,"mod"=>1,"report"=>1,"jscript"=>1,"js"=>1) ;
  $_vaNo = array("ini.php"=>1) ;
  if(isset($_vaExt [$cExt]) && !isset($_vaNo[$cExt1])){
    $data = Compress($vaData) ;        
  }else{
    $data = implode("",$vaData);
  }
  return $data ;
}

function webProtocol($cLine,$nRemark){
  $cLine = strtolower($cLine) ;  
  if(substr($cLine,$nRemark-5,4) == "http"){
    $nRemark = -1 ;
  }else if(substr($cLine,$nRemark-4,3) == "ftp"){
    $nRemark = -1 ;
  }
  return $nRemark ;
}

function Compress($vaData){
  $data = "" ;
  foreach($vaData as $key=>$value){
    $cLine = $value ;      
    // Hapus Remak
    $nRemark = strpos($cLine,"//") ;
    $nPHPC = strpos($cLine,"?>") ;
    if($nPHPC === false) $nPHPC = 0 ;
    if($nRemark === false){
      $nRemark = -1 ;
    }else{
      $nRemark = webProtocol($cLine,$nRemark) ;
    }
    if($nRemark >= 0){
      // kalau ada tutup // tapi di kanannya ada ? > maka tidak di buang semua
      if($nPHPC > $nRemark){
        $cLine = substr($cLine,0,$nRemark) . substr($cLine,$nPHPC) ;
      }else{
        $cLine = substr($cLine,0,$nRemark) ;
      }
    }
    $data .= ReplaceAll('  ',' ',$cLine) ;
  }      
  $data = ReplaceAll('  ',' ',$data) ;
  $_vaR = array('<','>','}','{','+','-','=',';','*','/','.') ;
  foreach($_vaR as $key=>$value){
    $data = ReplaceAll(' '.$value,$value,$data) ;
    $data = ReplaceAll($value.' ',$value,$data) ;
  }

  // Hilangkan Karakter Remark /* .. */
  $lFound = true ;
  while($lFound){
    $nStart = strpos($data,'/*') ;
    $nEnd = strpos($data,'*/') ;
    $lFound = false ;
    if(!$nStart === false && !$nEnd === false){
      if($nStart < $nEnd){
        $data = substr($data,0,$nStart) . substr($data,$nEnd+2) ;
        $lFound = true ;
      }
    }
  }
  $data = ReplaceAll("<"."?php?" . ">",' ',$data) ;
  $data = ReplaceAll("<"."??" . ">",' ',$data) ;
  return $data ;
}

function ReplaceAll($search,$replace,$data){
  $_c = $data ;
  $_c = str_replace(chr(13),' ',$_c) ;
  $_c = str_replace(chr(10),' ',$_c) ;
  $data = $_c ;
  $n = 1 ;
  while($n <> 0){
    $data = str_replace($search,$replace,$data,$n) ;
  }
  if(substr($data,0,1) == ' '){
    $data = substr($data,1) ;
  }
  $c = str_replace(chr(13),' ',$data) ;
  $c = str_replace(chr(10),' ',$c) ;
  if(trim($c) == ""){
    $data = "" ;
  }
  return $data ;
}

function getPHPFile($cDir,$cDirBin,&$vaFile){
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry)){
        if($entry !== "." && $entry !== ".."){
          if(!is_dir($cDirBin . '/' . $entry)){
            mkdir($cDirBin . '/' . $entry,0777) ;
          }
          getPHPFile($cDir . '/' . $entry,$cDirBin . "/" . $entry,$vaFile) ;
        }
      }else if(is_file($cDir . '/' . $entry)){
        $vaFile [$cDir . '/' . $entry] = array("Dir"=>$cDir,"DirBin"=>$cDirBin,"File"=>$entry) ;
      }
    }
  }
}
?>