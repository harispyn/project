<?
	$nWindowHeight = 220 ;
	$nWindowWidth = 450 ;
?>