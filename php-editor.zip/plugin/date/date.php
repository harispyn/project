<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Date Field</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
	function Space(nLen){
	var cRetval = "" ;
		for(n=1;n<nLen;n++){
			cRetval += " " ;
		}
		return cRetval ;
	}
	
	function saveTextbox(){
	var html = "" ;
	var cReadOnly = "" ;
	var nColPos = window.opener.document.form1.nColPos.value ;
		
		with(document.form1){
			if(chkReadOnly.checked){
				cReadOnly = ',true' ;
			}
			
			html = "" ;
			if(cOnBlur.value !== "" ){
				html += '$txt->onBlur = "' + cOnBlur.value + '" ;\n' + Space(nColPos) ;
			}
			if(cCaption.value !== ""){
				html += '$txt->Caption = " ' + cCaption.value + '" ;\n' + Space(nColPos) ;
			}
			
			html += '$txt->DateField("' + cName.value + '","' + cValue.value + '"' + cReadOnly + ') ;'
		}
				
		var o = window.opener.document.getElementById("Editor") ;
		o.contentDocument.form1.cTMPInsert.value = html ;
		window.close() ;
	}
</script>
<body onLoad="document.form1.cName.focus()" marginheight="0px" marginwidth="0px">
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td align="center" valign="middle"><table width="400" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_border"><table width="100%"  border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td class="window_silver_center">Date Field </td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="2" cellspacing="0">
                <tr>
                  <td width="26%" valign="top">&nbsp;Name</td>
                  <td width="2%">:</td>
                  <td width="72%"><input name="cName" type="text" id="cName" value="dTgl" size="20"></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Value</td>
                  <td>:</td>
                  <td valign="top"><input name="cValue" type="text" id="cValue" style="width:100% ">
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onBlur</td>
                  <td>:</td>
                  <td valign="top"><input name="cOnBlur" type="text" id="cOnBlur" style="width:100% "></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Caption</td>
                  <td>:</td>
                  <td valign="top"><input name="cCaption" type="text" id="cCaption" style="width:100% "></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top"><input name="chkReadOnly" type="checkbox" id="chkReadOnly" value="checkbox">
      Read Only </td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">				    <input name="cmdOK" type="button" id="cmdOK" value="OK" onClick="saveTextbox()" />
                      <input name="cmdCancel" type="button" id="cmdCancel" value="Cancel" onClick="window.close()" />
                    &nbsp;</td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
