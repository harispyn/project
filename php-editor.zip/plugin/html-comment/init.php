<?
	$nWindowHeight = 250 ;
	$nWindowWidth = 500 ;
	$cPlugAction = "PHP Code Block" ;
	$cOnClick = 'javascript:var o = document.getElementById(&quot;Editor&quot;); o.contentDocument.form1.cTMPInsert.value= &quot;<!--  -->&quot;; return false ;' ;	
?>