<?php
  $cPlugAction = "Find Next" ;
  $cOnClick = 'javascript:FindNext(); return false ;' ;
?>