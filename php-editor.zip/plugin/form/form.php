<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Text Box</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
  function saveTextbox(){
  var html = "" ;
  var cEn = "" ;
  var cTar = "" ;
    with(document.form1){
      if(cEncoding.value !== ""){
        cEn = ' enctype="' + cEncoding.value + '"' ;
      }
      if(cTarget.value !== ""){
        cTar = ' target="' + cTarget.value + '"' ;
      }
      
      html = '<form action="' + cAction.value + '" method="' + cMethod.value + '" name="' + cName.value + '"' + cEn + cTar + '>\n\n</form>' ;
    }
    var o = self.parent.document.getElementById("Editor") ;
    o.contentDocument.form1.cTMPInsert.value = html ;
    CloseForm() ;
  }
</script>
<body>
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_border"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="1" cellspacing="0">
                <tr>
                  <td width="26%" valign="top">Action</td>
                  <td width="2%">:</td>
                  <td width="72%"><input name="cAction" type="text" id="cAction" style="width:100% "></td>
                </tr>
                <tr>
                  <td valign="top">Method</td>
                  <td>:</td>
                  <td><select name="cMethod" id="cMethod">
                    <option value="post" selected>post</option>
                    <option value="get">get</option>
                  </select></td>
                </tr>
                <tr>
                  <td valign="top">Encoding Type </td>
                  <td>:</td>
                  <td><select name="cEncoding" id="cEncoding">
                    <option></option>
                    <option value="application/x-www-form-urlencoded">application/x-www-form-urlencoded</option>
                    <option value="multipart/form-data">multipart/form-data</option>
                  </select></td>
                </tr>
                <tr>
                  <td valign="top">Name</td>
                  <td>:</td>
                  <td><input name="cName" type="text" id="cName" value="form1" size="20"></td>
                </tr>
                <tr>
                  <td valign="top">Target</td>
                  <td>:</td>
                  <td><select name="cTarget" id="cTarget">
                    <option selected></option>
                    <option value="_top">_top</option>
                    <option value="_parent">_parent</option>
                    <option value="_self">_self</option>
                    <option value="_blank">_blank</option>
                  </select></td>
                </tr>
              </table></td>
            </tr>
            <tr height="2px">
              <td class="window_frame_midle"></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">
                  <?php
                    $txt->onClick="saveTextbox()" ;
                    $txt->ButtonField("cmdOK","OK") ;

                    $txt->onClick = "CloseForm()" ;
                    $txt->ButtonField("cmdCancel","Cancel") ;
                  ?>
                    &nbsp;</td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
