<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/form/form.php',false) . "','FrmInsertForm','Insert Form',500,180,'',true); return false" ;
?>