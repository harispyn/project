<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/filefield/filefield.php',false) . "','FrmFileField','Insert File Field',400,150,'',true); return false" ;
?>