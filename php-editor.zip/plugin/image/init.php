<?
	$nWindowHeight = 270 ;
	$nWindowWidth = 450 ;
?>