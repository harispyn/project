<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Text Box</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
	function saveTextbox(){
	var html = "" ;
	var cReadOnly = "" ;
	var cDisabled = "" ;
	var cNextEnter = "" ;
		with(document.form1){
			if(chkReadonly.checked){
				cReadOnly = ' readOnly="true"' ;
			}
			if(chkDisable.checked){
				cDisabled = ' disabled' ;
			}
			if(ckNextEnter.checked){
				cNexEnter = ' onKeyUp="validate(this,event)"' ;
			}
			html = '<input name="' + cName.value + '" type="' + cType.value + '" value="' + cValue.value + '" size="' + cSize.value + '" maxlength="' + cMax.value + '"' + cReadOnly + cDisabled + cNexEnter + '>' ;
		}
		var o = window.opener.document.getElementById("Editor") ;
		o.contentDocument.form1.cTMPInsert.value = html ;
		window.close() ;
	}
</script>
<body>
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center"><table width="400" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_border"><table width="100%"  border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td class="window_silver_center">Insert Input Field </td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="2" cellspacing="0">
                <tr>
                  <td width="26%" valign="top">&nbsp;Type</td>
                  <td width="2%">:</td>
                  <td width="72%"><select name="cType" id="cType">
                      <option selected>text</option>
                      <option>password</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Name</td>
                  <td>:</td>
                  <td><input name="cName" type="text" id="cName" size="20"></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Value</td>
                  <td>:</td>
                  <td valign="top"><input name="cValue" type="text" id="cValue" size="30">
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Size</td>
                  <td>:</td>
                  <td valign="top"><input name="cSize" type="text" id="cSize" size="10"></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Max Length </td>
                  <td>:</td>
                  <td valign="top"><input name="cMax" type="text" id="cMax" size="10"></td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top"><input name="chkReadonly" type="checkbox" id="chkReadonly" value="checkbox">
      Readonly </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top"><input name="chkDisable" type="checkbox" id="chkDisable" value="checkbox">
      Disable </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top"><input name="ckNextEnter" type="checkbox" id="ckNextEnter" value="checkbox" checked>
                    Next With Enter </td>
                </tr>
              </table></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">				    <input name="cmdOK" type="button" id="cmdOK" value="OK" onClick="saveTextbox()" />
                      <input name="cmdCancel" type="button" id="cmdCancel" value="Cancel" onClick="window.close()" />
                    &nbsp;</td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
