<?
  $cScrollBar = 'yes' ;
  $nWindowHeight = 100 ;
  $nWindowWidth = 600 ;
?>