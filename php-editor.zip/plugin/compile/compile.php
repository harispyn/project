<?php
  include 'df.php' ;
  include 'compile.db' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Compile Project</title>
</head>
<?php include 'compile.jscript' ?>
<body marginheight="0" marginwidth="0">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="cell_blue"><table width="100%"  border="0" cellspacing="1" cellpadding="0">
      <tr>
        <td class="cell_white"><table width="100%"  border="0" cellspacing="2" cellpadding="0">
          <tr>
            <td width="22%"> Project Name</td>
            <td width="1%">:</td>
            <td width="77%"><?= $cProject ?></td>
          </tr>
          <tr>
            <td> Downloads File</td>
            <td>:</td>
            <td>
      <?php
      if(empty($cmdProses)){
        echo('<input name="cmdProses" type="submit" id="cmdProses" value="Proses">') ;
      }else{
        echo('<a href="' . $cZipFile . '">' . $cFileName . '</a>') ;
      }
      ?>
      </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</body>
</html>
