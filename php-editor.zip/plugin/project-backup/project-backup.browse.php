<?php
  include 'df.php' ;
  IsDatabase() ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<body>
<form name="form1" method="post">
<?php
  $vaArray = GetProjectList($optJenis,$dAwal,$dAkhir) ;
  if(!empty($vaArray)){
    $dbg->Array = $vaArray ;
    $dbg->Height = "100%" ;
    $dbg->Col ['Status'] = array("Type"=>"Checkbox","Width"=>20,"Align"=>"center") ;
    $dbg->Col ['Nama Project'] = array("Width"=>550) ;
    $dbg->Scrolling = "vertical" ;
    $dbg->DataBind() ;
  }
?>
</form>
</body>
</html>
<?php
function GetProjectList($optJenis,$dAwal,$dAkhir){
  $nTglAwal = Tgl2Time($dAwal) ;
  $nTglAkhir = Tgl2Time($dAkhir) + (60*60*24) - 1 ;
  $cDir = GetSetting("Project_Dir") ;
  $vaArray = array() ;
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry) && substr($entry,0,1) !== "." && substr($entry,0,3) !== "tmp" && IsProject($optJenis,$nTglAwal,$nTglAkhir,$entry)){
        $vaArray [$entry] = array("Status"=>1,"Nama Project"=>$entry) ;
      }
    }
    $d->close();
    
    if(!empty($vaArray)){
      ksort($vaArray) ;
    }
  }
  return $vaArray ;
}

function IsProject($optJenis,$nTglAwal,$nTglAkhir,$cProject){
  $lRetval = true ;
  if($optJenis == "P" && GetSetting("optMYSQL","N") == "Y"){
    $dbData = mysql_query("select DirName from php_editor_diredit where DateTime >= $nTglAwal and DateTime <= $nTglAkhir and DirName Like '$cProject/%' Limit 0,1") ;
    $lRetval = mysql_num_rows($dbData) > 0 ;
  }
  return $lRetval ;
}
?>