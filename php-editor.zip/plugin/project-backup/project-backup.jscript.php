<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
var nProject = 0 ;
var oProject = null ;
var lFound = false ;
var lLama = false ;
var nDetik = 0 ;
var nMenit = 0 ;
var nJam = 0 ;
var ocellLama = null ;

function cmdBackup_onClick(field){
  nDetik = 0 ;
  nMenit = 0 ;
  nJam = 0 ;
  lLama = true ;
  ocellLama = document.getElementById("cellLama") ;
  TimeProsess() ;
  
  lFound = false ;
  nProject = -1 ;
  oProject = document.getElementById("frmBrowse").contentWindow.DBGRID1 ;
  if(typeof oProject == "undefined"){
    alert("Tidak Project Yang Akan Di Backup .....") ;
  }else{
    ajax('','InitBackup()') ;
  }
}

function StartBackup(){
  nProject ++ ;
  nMaxProject = oProject.Rows() - 1 ;
  if(nProject <= nMaxProject){
    pr1.Value(nProject/nMaxProject*100) ;
    cMessage = "Prosess " + oProject.cellValue(nProject,1) + " - ( " + (nProject+1) + " / " + (nMaxProject+1) + " )" ;
    ShowProsess(cMessage) ;
    if(oProject.cellValue(nProject,0)){
      lFound = true ;
      oProject.cellUpdate(nProject,0,false) ;
      ajax('','BackupProject()','cProject='+oProject.cellValue(nProject,1)) ;
    }else{
      StartBackup() ;
    }
  }else{
    if(lFound){
      ShowProsess("Creating Backup File ....") ;
      ajax('','CreateZipAllProject()') ;
    }else{
      lLama = false ;
      alert("Tidak Ada Project yang akan dibackup ...!") ;
    }
  }
}

function ShowProsess(cMessage){
var o = document.getElementById("idFileDownloads") ;

  o.innerHTML = cMessage ;
}

function TimeProsess(){
  nDetik ++ ;
  if(nDetik >= 60){
    nMenit ++ ;
    nDetik = 0 ;
  }
  if(nMenit >= 60){
    nJam ++ ;
    nMenit = 0 ;
  }
  
  var cJam = "" ;
  if(nJam > 0) cJam += nJam + " Jam, " ;
  if(nMenit > 0) cJam += nMenit + " Menit, " ;
  cJam += nDetik + " Detik" ;  
  ocellLama.innerHTML = cJam ;
  if(lLama) setTimeout(TimeProsess,1000) ;
}

function Form_onLoad(){
  InitValue() ;
}

function InitValue(){
  with(document.form1){
    SetOpt(optJenis,"A") ;
  }
  SettingPeriode() ;
}

function optJenis_onClick(field){
  SettingPeriode() ;
}

function SettingPeriode(){
  with(document.form1){
    dAwal.readOnly = optJenis [0].checked ;
    dAkhir.readOnly = optJenis [0].checked ;
  }
  LoadGrid() ;
}

function LoadGrid(){
var o = document.getElementById("frmBrowse") ;
  o.src="main.php?__par=./plugin/project-backup/project-backup.browse.php&" + GetFormContent() ;
}
</script>