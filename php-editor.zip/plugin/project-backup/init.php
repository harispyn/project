<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/project-backup/project-backup.php',false) . "','FrmProjectBackup','Backup Project',600,520,'',true); return false" ;
?>