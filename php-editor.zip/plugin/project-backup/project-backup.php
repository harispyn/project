<?php
  include 'df.php' ;
  include 'project-backup.db.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include 'project-backup.jscript.php' ?>
<body>
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td height="20px"  style="border:1px solid #999999;padding:4px">
      <table width="100%"  border="0" cellspacing="0" cellpadding="1">
        <tr>
          <td width="100px" height="15px">Jenis Backup</td>
          <td width="5px">:</td>
          <td>
          <?php
            $txt->Caption = "Semua Project" ;
            $txt->RadioButton("optJenis","A") ;
            
            $txt->Caption = "Periode" ;
            $txt->RadioButton("optJenis","P") ;
          ?>
          </td>
        </tr>
        <tr>
          <td width="100px" height="15px">Tanggal</td>
          <td width="5px">:</td>
          <td>
          <?php
            $txt->Caption = "s/d" ;
            $txt->DateField("dAwal",date("d-m-Y")) ;

            $txt->DateField("dAkhir",date("d-m-Y")) ;
            
            $txt->onClick = "LoadGrid();" ;
            $txt->ButtonField("cmdRefresh","Refresh") ;
          ?>
          </td>
        </tr>
        <tr>
          <td width="100" height="10px">Time</td>
          <td width="5">:</td>
          <td id="cellLama">&nbsp;</td>
        </tr>
        <tr>
          <td>Status</td>
          <td>:</td>
          <td id="idFileDownloads">&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #999999;padding:4px">
      <iframe id="frmBrowse" width="100%" height="100%" scrolling="no" style="border:0px"></iframe>
    </td>
  </tr>
  <tr>
    <td height="20px">
    <?php
      include '../component/progressbar/progressbar.php' ;
      $pr->Show("100%") ;
    ?>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999">
      <table width="100%" style="padding:2px">
        <tr>
          <td align="right">
          <?php
            $txt->ButtonField("cmdBackup","Backup") ;

            $txt->onClick="CloseForm()" ;
            $txt->ButtonField("cmdCancel","Cancel") ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
