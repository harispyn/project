<?php
  include 'df.php' ;

function InitBackup($va){
  $cDirdownloads = CreateTmpDir() ;
  SaveSetting("cDirDownloadsAll",$cDirdownloads) ;
  echo('StartBackup() ;') ;
}
  
function BackupProject($va){  
  include 'project-backup.zip.php' ;

  $cProject = $va ['cProject'] ;
  $cFileName = $cProject . ".zip" ;
  
  $cDir = GetSetting("project_dir") . '/' . $cProject ;
  $cDirDownloads = GetSetting("cDirDownloadsAll") ;
  $cZipFile = $cDirDownloads . "/" . $cFileName ;
    
  getPHPFile($cDir,$vaFile) ;
  $ziper = new zipfile();
  $ziper->zipName=$cZipFile ;
  $ziper->addFiles($vaFile,$cDir);
  $ziper->output();
  
  echo('StartBackup();') ;
}

function CreateZipAllProject($va){
  include 'project-backup.zip.php' ;
  $cDir = GetSetting("cDirDownloadsAll") ;
  getPHPFile($cDir,$vaFile) ;
  $cFileName = 'Backup_Project_' . date("Ymd_His") . ".zip" ;
  $cZipFile = $cDir . "/" . $cFileName ;
  
  $ziper = new zipfile();
  $ziper->zipName=$cZipFile ;
  $ziper->addFiles($vaFile,$cDir);
  $ziper->output();
  foreach($vaFile as $key=>$value){
    if(is_file($key)){
      unlink($key) ;
    }
  }
  $nSize = GetFileSize($cZipFile) ;
  echo('
    lLama = false ;
    o = document.getElementById("idFileDownloads") ;
    if(o !== null){
      o.innerHTML = "<a href=\"' . $cZipFile . '\">' . $cFileName . ' - ' . $nSize . '</a>" ;
    }
  ') ;
}

function getPHPFile($cDir,&$vaFile){
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry)){
        if(substr($entry,0,1) !== "."){
          getPHPFile($cDir . '/' . $entry,$vaFile) ;
        }
      }else if(is_file($cDir . '/' . $entry)){
        $vaFile [$cDir . '/' . $entry] = $cDir . '/' . $entry ;
      }
    }
  }
}
?>