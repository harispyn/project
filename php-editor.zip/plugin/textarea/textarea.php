<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<script language="javascript" type="text/javascript">
  function save(){
  var html = "" ;
  var cReadOnly = "" ;
  var cDisabled = "" ;
  var cNextEnter = "" ;
    with(document.form1){
      if(chkReadonly.checked){
        cReadOnly = ' readOnly="true"' ;
      }
      if(chkDisable.checked){
        cDisabled = ' disabled' ;
      }
      if(ckNextEnter.checked){
        cNexEnter = ' onKeyUp="validate(this,event)"' ;
      }
      html = '<textarea name="' + cName.value + '" cols="' + cCol.value + '" rows="' + cRow.value + '" wrap="' + cWrap.value + '"' + cReadOnly + cDisabled + cNexEnter + '></textarea>' ;
    }
    var o = self.parent.document.getElementById("Editor") ;
    o.contentDocument.form1.cTMPInsert.value = html ;
    CloseForm() ;
  }
</script>
<body>
<form  name="form1" method="post">
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%" height="100%" align="center"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td class="cell_border"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="1" cellspacing="0">
                  <tr>
                    <td width="26%" valign="top">&nbsp;Name</td>
                    <td width="2%">:</td>
                    <td width="72%">
                    <?php
                      $txt->Style = "width:100%" ;
                      $txt->Show("cName","") ;
                    ?>
                    </td>
                  </tr>
                  <tr>
                    <td valign="top">&nbsp;Columns</td>
                    <td>:</td>
                    <td valign="top">
                    <?php
                      $txt->NumberField("cCol","",6,6) ;
                    ?>
                    </td>
                  </tr>
                  <tr>
                    <td valign="top">&nbsp;Rows</td>
                    <td>:</td>
                    <td valign="top">
                    <?php
                      $txt->NumberField("cRow","",6,6) ;
                    ?>
                    </td>
                  </tr>
                  <tr>
                    <td valign="top">&nbsp;Wrap</td>
                    <td>:</td>
                    <td valign="top"><select name="cWrap" id="cWrap">
                        <option selected>default</option>
                        <option>off</option>
                        <option>virtual</option>
                        <option>physical</option>
                    </select></td>
                  </tr>
                  <tr>
                    <td valign="top">&nbsp;</td>
                    <td>&nbsp;</td>
                    <td valign="top">
                    <?php
                      $txt->Caption = "Readonly<br>" ;
                      $txt->CheckBox("chkReadonly","1") ;
                      
                      $txt->Caption = "Disable<br>" ;
                      $txt->CheckBox("chkDisable","1") ;
                      
                      $txt->Caption = "Next With Enter" ;
                      $txt->Checked = true ;
                      $txt->CheckBox("ckNextEnter","1") ;
                    ?>
                    </td>
                  </tr>
              </table></td>
            </tr>
            <tr height="2px">
              <td class="window_frame_midle"></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td height="29">&nbsp;</td>
                    <td align="right">
                    <?php
                      $txt->onClick="save()" ;
                      $txt->ButtonField("cmdOK","OK") ;
                      
                      $txt->onClick = "CloseForm()" ;
                      $txt->ButtonField("cmdCancel","Cancel") ;
                    ?>
                    &nbsp;</td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</body>
</html>
