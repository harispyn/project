<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/textarea/textarea.php',false) . "','FrmTextBox','Insert Text Area',400,210,'',true); return false" ;
?>