<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Insert Table</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
  function Update(){
  var html = "" ;
    with(document.form1){
      html = '<table width="' + nTableWidth.value + cTablePercent.value + '"  border="' + nBorder.value + '" cellspacing="' + nCellSpacing.value + '" cellpadding="' + nCellPadding.value + '">\n' ;
      for(r=1;r<=nRows.value;r++){
        html += '\t<tr>\n' ;
        for(c=1;c<=nCols.value;c++){
          html += '\t\t<td>&nbsp;</td>\n' ;
        }
        html += '\t</tr>\n' ;
      }      
      html += '</table>' ;
    }
    var o = self.parent.document.getElementById("Editor") ;
    o.contentDocument.form1.cTMPInsert.value = html ;
    CloseForm() ;
  }
</script>
<body onLoad="fieldfocus(document.form1.nRows);">
<form name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="cell_border"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="1">
            <tr><td colspan="3" height="5"></td></tr>
            <tr>
              <td width="103">&nbsp;Rows</td>
              <td width="1%">:</td>
              <td>
              <?php
                $txt->NumberField("nRows","1",6,6) ;
              ?>
              </td>
            </tr>
            <tr>
              <td>&nbsp;Columns</td>
              <td>:</td>
              <td>
              <?php
                $txt->NumberField("nCols","1",6,6) ;
              ?>
              </td>
            </tr>
            <tr>
              <td>&nbsp;Table Width </td>
              <td>:</td>
              <td>
              <?php
                $txt->NumberField("nTableWidth","100",6,6) ;
              ?>
              <select name="cTablePercent" id="cTablePercent">
                <option value="%" selected>Percents</option>
                <option value="px">Pixels</option>
              </select></td>
            </tr>
            <tr>
              <td>&nbsp;Border</td>
              <td>:</td>
              <td>
              <?php
                $txt->NumberField("nBorder","0",6,6) ;
              ?>
              </td>
            </tr>
            <tr>
              <td>&nbsp;Call Padding </td>
              <td>:</td>
              <td>
              <?php
                $txt->NumberField("nCellPadding","0",6,6) ;
              ?>
              </td>
            </tr>
            <tr>
              <td>&nbsp;Cell Spacing </td>
              <td>:</td>
              <td>
              <?php
                $txt->NumberField("nCellSpacing","0",6,6) ;
              ?>
              </td>
            </tr>
            <tr><td colspan="3" height="5"></td></tr>
            <tr><td colspan="3" class="window_frame_midle"></td></tr>
          </table></td>
        </tr>
        <tr>
          <td height="29" align="right" class="cell_white">
          <?php
            $txt->onClick = "Update()" ;
            $txt->ButtonField("cmdUpdate","Save") ;
            
            $txt->onClick = "CloseForm(window.name);" ;
            $txt->ButtonField("cmdCancel","Cancel") ;
          ?>
            &nbsp;</td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
