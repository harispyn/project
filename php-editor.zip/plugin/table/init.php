<?php
  $cPlugAction = ";;" ;
  $cOnClick = 'OpenForm(\'main.php?__par=' . getlink("./plugin/table/table.php",false) . '\',\'frmTable\',\'Insert Table\',600,205,\'\',true);return false' ;
?>