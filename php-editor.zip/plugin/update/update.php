<?php
  $cError = "" ;
  if(!empty($cAction)){
    if(empty($_FILES['cFileName']['tmp_name'])){
      $cError .= "Uploads File Gagal ....!<br>" ;
    }
    
    $cProjectTarget = '' ;
    $cProject = 'php-editor_' ;
    $cComponent = 'component_' ;
    if(substr($_FILES['cFileName']['name'],0,strlen($cProject)) == $cProject){
      $cProjectTarget = './' ;
    }else if(substr($_FILES['cFileName']['name'],0,strlen($cComponent)) == $cComponent){
      $cProjectTarget = '../component/' ;
    }else{
      $cError .= "Project Salah, Update Gagal .....!<br>" ;
    }

    if(empty($cError)){
      ExtractFile($_FILES['cFileName'],$cProjectTarget) ;
    }
  }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Open File</title>
</head>
<body marginheight="0" marginwidth="0">
<form action="main.php?__par=<?= getlink($__par,false) ?>" method="post" enctype="multipart/form-data" name="form1">
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="cell_blue"><table width="100%"  border="0" cellspacing="1" cellpadding="0">
      <tr>
        <td class="cell_white"><table width="100%"  border="0" cellspacing="2" cellpadding="0">
          <tr>
            <td width="22%"> Project Name </td>
            <td width="1%">:</td>
            <td width="77%">
            <?php
              $txt->Type = "File" ;
              $txt->Show("cFileName","",0,40) ;
            ?>
            </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td class="cell_white"><table width="100%"  border="0" cellspacing="2" cellpadding="0">
          <tr>
            <td align="center">
            <?php
              $txt->HiddenField("cAction","1") ;
              $txt->onClick = "document.form1.submit()" ;
              $txt->ButtonField("cmdProses","Proses") ;
            ?>
            </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr><td><br><br><strong>
  Project yang bisa di pilih :<br></strong>
  1. PHP-Editor  ( Untuk Melakukan Update Program Editor ).<br>
  2. Component ( Untuk Melakukan Update Component ).
  </td></tr>
</table><br>
<?= $cError ?>
</form>
</body>
</html>
<?php
function ExtractFile($vaFile,$cProjectTarget){
  if(!is_dir($cProjectTarget)) mkdir($cProjectTarget,0777) ;
  include 'dunzip2.inc.php' ;
  $zip = new dUnzip2($vaFile ['tmp_name']) ;
  $zip->unzipAll($cProjectTarget) ;
}
?>