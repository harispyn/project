<?
  $cPlugAction = "Update";
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/update/update.php',false) . "','FrmUpdate','Update Project / Component',500,200,'',true);return false" ;
?>