<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/help/help.php',false) . "','FrmOpenHelp','Help',800,500,'',true); return false" ;
?>