<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>About</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<body>
<form  name="form1" method="post">
<table width="100%" height="100%" border="0" cellspacing="4" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:10px" valign="top">
    <font size="14px"><strong>PHP-Editor Keyboard Shortcut</strong></font><br><br>
    <table width="100%"  border="0" cellspacing="0" cellpadding="2" style="border:1px solid #d9d9d9;border-bottom:0px">
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9;background-color:#eeeeee"><strong>Shortcut</strong></td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9;background-color:#eeeeee"><strong>Command</strong></td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+S</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Saves the current document.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+E</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Delete Space from the cursor position to the end of the word.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+C</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Copies the selected items.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+X</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Cuts out the selected elements.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+V</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Pastes from the clipboard.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+A</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Selects all.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+Z</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Undoes last action.</td>
      </tr>
      <tr>
        <td width="100px" style="padding:4px;border-bottom:1px solid #d9d9d9;border-right:1px solid #d9d9d9">Ctrl+Shift+Z</td>
        <td style="padding:4px;border-bottom:1px solid #d9d9d9">Redoes last action.</td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999">
      <table width="100%" style="padding:2px">
        <tr>
          <td align="right">
          <?php
            $txt->onClick = "CloseForm();" ;
            $txt->ButtonField("cmdClose","Close") ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>

</form>
</body>
</html>
