<?php
  include 'df.php' ;
  include 'menu-setup.db.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include 'menu-setup.jscript.php' ?>
<body>
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:4px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td height="20" width="100px">&nbsp;Level</td>
        <td height="20" width="5px">:</td>
        <td height="20">
        <?php
          $txt->NumberField("nLevel","1",6,6) ;
          $txt->ButtonField("cmdRefresh","Refresh") ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #999999;padding:4px">
    <iframe id="__content" height="100%" width="100%" style="border:0px" src="main.php?__par=<?php getlink("./plugin/menu-setup/menu-setup.show.php") ?>"></iframe>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:5px" align="right">
    <?php      
      $txt->ButtonField("cmdSave","Save") ;
      
      $txt->onClick = "CloseForm()" ;
      $txt->ButtonField("cmdClose","Close") ;
    ?>    
    </td>
  </tr>
</table>
</form>
</body>
</html>
