<?php
  include 'df.php' ;
  include './plugin/plugin.php' ;
?>
<html>
<body style="overflow-x:hidden">
<form method="post" name="form1">
<table width="100%"  border="0" cellspacing="0" cellpadding="1">
  <?php
  foreach($vaPlug as $key=>$value){
    if(!empty($value) && is_array($value)){
      $cImage = '<img src="./plugin/' . $value['Name'] . '/images/' . $value['Name'] . '.gif">' ;
      echo('<tr>
        <td width="22px" height="22px">') ;
      $ck = trim(str_replace("-","x",$value['Name'])) ;
      $txt->CheckBox("_ck".$ck,trim($value['Name'])) ;
      echo('</td>
        <td width="22px">' . $cImage . '</td>
        <td>&nbsp;' . $value['Name'] . '</td>
      </tr>') ;
    }
  }
  ?>
</table>
</form>
</body>
</html>