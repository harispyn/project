<?php
  $cPlugAction = "Menu Setup" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/menu-setup/menu-setup.php',false) . "','FrmMenuSetup','Setup Menu',500,500,'',true);return false" ;
?>