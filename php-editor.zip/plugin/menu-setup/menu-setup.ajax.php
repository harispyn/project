<?php
  include 'df.php' ;
  
function SaveMenu($va){
  include './plugin/plugin.php' ;
  foreach($vaPlug as $key=>$value){
    if(is_array($value)){
      $ck = str_replace("-","x",$value['Name']) ;
      if(isset($va['_ck'.$ck])){
        $cKey = md5($value['Name']) ;
        $vaArray[$cKey] = "" ;
      }
    }
  }
  
  if(!empty($vaArray)){
    $cFileName = GetFileName(trim($va['nLevel'])) ; ;
    SaveArray($vaArray,$cFileName,"vaIconsShow") ;
  }
  echo('alert("Update Selesai .....");') ;
}

function RefreshIcons($va){
  include './plugin/plugin.php' ;
  $vaShow = IncludeFile($va['nLevel']) ;
  echo('var __o = document.getElementById("__content").contentDocument.form1 ;') ;
  foreach($vaPlug as $key=>$value){
    if(is_array($value)){
      $c = md5($value ['Name']) ;
      if(isset($vaShow[$c])){
        $ck = str_replace("-","x",$value['Name']) ;
        echo('__o._ck'.$ck.'.checked = true;') ;
      }
    }
  }
}
?>