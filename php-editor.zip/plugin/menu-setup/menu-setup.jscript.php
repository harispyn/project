<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function cmdSave_onClick(field){
var o = document.getElementById("__content").contentDocument.form1 ;
var c = GetFormContent() + "&" + GetFormContent(o) ;
  ajax('',"SaveMenu()",c) ;
}

function cmdRefresh_onClick(field){
var o = document.getElementById("__content").contentDocument.form1 ;
  for(n=0;n<o.elements.length;n++){
    if(o.elements[n].type = "checkbox"){
      o.elements[n].checked = false ;
    }
  }
  ajax('',"RefreshIcons()",GetFormContent()) ;
}
</script>