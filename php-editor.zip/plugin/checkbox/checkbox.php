<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Check Box / Radio Button</title>
</head>
<script language="javascript" type="text/javascript">
  function Space(nLen){
  var cRetval = "" ;
    for(n=1;n<nLen;n++){
      cRetval += " " ;
    }
    return cRetval ;
  }
  
  function saveTextbox(){
  var html = "" ;
  var cChecked = "" ;
  var cReadOnly = "" ;
  var cNextEnter = "" ;
  var nColPos = 0 ;

    with(document.form1){
      if(chkReadOnly.checked){
        cReadOnly = ',true' ;
      }
      
      html = "" ;
      if(chkChecked.checked){
        html += '$txt->Checked = true ;\n' + Space(nColPos) ;
      }
      if(cCaption.value !== ""){
        html += '$txt->Caption = " ' + cCaption.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnClick.value !== ""){
        html += '$txt->onClick = "' + cOnClick.value + '" ;\n' + Space(nColPos) ;
      }
      if(cOnBlur.value !== ""){
        html += '$txt->onBlur = "' + cOnBlur.value + '" ;\n' + Space(nColPos) ;
      }
      var cType = "RadioButton" ;
      if(optType [0].checked){
        cType = "CheckBox" ;
      }
      html += '$txt->' + cType + '("' + cName.value + '","' + cValue.value + '"' + cReadOnly + ') ;'
    }
        
    var o = self.parent.document.getElementById("Editor") ;
    o.contentDocument.form1.cTMPInsert.value = html ;
    CloseForm() ;
  }
</script>
<body onLoad="document.form1.cName.focus()" marginheight="0px" marginwidth="0px">
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0" height="100%">
    <tr>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_border"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="2" cellspacing="0">
                <tr>
                  <td width="100px">&nbsp;Type</td>
                  <td width="5px">:</td>
                  <td>
                  <?php
                    $txt->Checked = true ;
                    $txt->Caption = "Checkbox" ;
                    $txt->RadioButton("optType","C") ;
                    
                    $txt->Caption = "Radio Button" ;
                    $txt->RadioButton("optType","R") ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Name</td>
                  <td>:</td>
                  <td>
                  <?php
                    $txt->Show("cName","") ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Value</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cValue","") ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Caption</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cCaption","") ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onClick</td>
                  <td>&nbsp;</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnClick","") ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;onBlur</td>
                  <td>&nbsp;</td>
                  <td valign="top">
                  <?php
                    $txt->Style = "width:100%" ;
                    $txt->Show("cOnBlur","") ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top">
                  <?php
                    $txt->Caption = "Checked" ;
                    $txt->CheckBox("chkChecked","checkbox") ;
                  ?>
                </tr>
                <tr>
                  <td valign="top">&nbsp;</td>
                  <td>&nbsp;</td>
                  <td valign="top">
                  <?php
                    $txt->Caption = "Read Only" ;
                    $txt->CheckBox("chkReadOnly","checkbox") ;
                  ?>
                </td>
                </tr>
              </table></td>
            </tr>
            <tr height="2px">
              <td class="window_frame_midle"></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">
                  <?php
                    $txt->onClick="saveTextbox()" ;
                    $txt->ButtonField("cmdOK","OK") ;
                    
                    $txt->onClick="CloseForm()" ;
                    $txt->ButtonField("cmdCancel","Cancel") ;
                  ?>
                  &nbsp;</td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
