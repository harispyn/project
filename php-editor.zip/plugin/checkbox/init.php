<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/checkbox/checkbox.php',false) . "','FrmInsertCheckBox','Insert Check Box / Radio Button',500,250,'',true); return false" ;
?>