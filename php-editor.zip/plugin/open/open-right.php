<?php
  include 'df.php' ;
  if(empty($cDirname)){
    $cDirname = GetSetting("Dirname_Open") ;
  }
  SaveSetting("Dirname_OPen",$cDirname) ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<?php include 'open-right.jscript' ?>
<body marginHeight="0px" marginWidth="0px" onLoad="SetStatusBar();">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<span id="ShowFileRight">
<?php
  include 'open-right.show.php' ;
?>
</span>
</form>
</body>
</html>