<?php
  include 'df.php' ;
  if(!empty($cFileDelete) and is_file($cDir . '/' . $cFileDelete)){
    unlink($cDir . '/' . $cFileDelete) ;
    $va = split("\.",$cFileDelete) ;
    $cFileName = $va [0] ;
  }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<body>
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<?php
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    $cFileName .= "." ;
    while (false !== ($entry = $d->read())) {
      if(is_file($cDir . '/' . $entry) && (substr($entry,0,strlen($cFileName)) == $cFileName || ($entry . ".") == $cFileName)){
        $vaFile [$entry] = $entry ;
      }
    }
    $d->close();
  }

  if(!empty($vaFile)){
    foreach($vaFile as $key=>$value){
      $cSpace = '<img src="./images/empty.gif" width="30px" height="16px">' ;
      $cDelete = '<img src="./plugin/open/images/delete.png" border="0" onMouseOver="lPlush=true;" onMouseOut="lPlush=false" onClick="javascript:return DeleteFile(\'' . $cDir . '\',\'' . $cID . '\',\'' . $value . '\');">' ;
      echo($cSpace . GetIcon($value) . '&nbsp;<span style="height:20px; vertical-align:top ">' . $value . '</span>&nbsp;&nbsp;&nbsp;&nbsp;' . $cDelete . '<br>') ;
    }
  }
?>
</form>
</body>
</html>