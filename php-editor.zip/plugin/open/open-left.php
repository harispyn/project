<?php
  include 'df.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<?php include 'open-left.jscript' ?>
<body onUnload="savePos()" onLoad="getPos()" marginHeight="0px" marginWidth="0px">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
    <table width="100%"  border="0" cellspacing="1" cellpadding="3">
      <tr>
        <td nowrap id="ShowProject">
        <?php
          include 'open-left.show.php' ;
        ?>
        </td>
      </tr>
    </table>
<?php
$txt->HiddenField("cDirOpen",GetSetting("Dirname_Open")) ;
?>
</form>
</body>
</html>