<?php
  include 'df.php' ;

  if(!empty($cDirOpen)){
    if(!empty($cDirStatus)){
      $cOpen = $cDirStatus ;
    }else{
      $cOpen = GetSetting($cDirOpen) ;
      if($cOpen == "1"){
        $cOpen = "0" ;
      }else{
        $cOpen = "1" ;
      }
    }

    SaveSetting($cDirOpen,$cOpen) ;
    SaveSetting("Dirname_Open",$cDirOpen) ;
  }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<style type="text/css">
  .DirOpen {padding:2px 0px 2px 0px; cursor:default}
  
  .DirOpen-Select {background-color:#0033CC; color:#FFFFFF; padding:2px 0px 2px 0px; cursor:default}
</style>
<body marginHeight="0px" marginLeft="0px">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<?php
  $cDir = GetSetting("Project_Dir") ;
  GetSubDir($cDir,0) ;
?>
</form>
</body>
</html>
<?php
function GetSubDir($cDir,$nLevel){
  $cDirOpen = GetSetting("Dirname_Open") ;
  $cProjectShowAll = GetSetting("ShowProjectAll","T") ;
  $nWeek = time() - (60*60*24*30) ;
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    $cFile = "L" . GetSetting("cUserName") ;
    $vaDirShow = IncludeFile($cFile) ;
    while (false !== ($entry = $d->read())) {
      if(is_dir($cDir . '/' . $entry)){
        if(substr($entry,0,1) !== "."){
          if((isset($vaDirShow[$entry]) || GetSetting("nLevel") == 0) && (DirMTime($cDir . '/' . $entry) > $nWeek || $cProjectShowAll == "Y" || $nLevel > 0)){
            $vaDir[$entry] = $entry ;
          }
        }
      }
    }
    $d->close();
    
    if(!empty($vaDir)){              
      ksort($vaDir) ;
      foreach($vaDir as $key=>$value){
        if($nLevel == 0){
          $cImage = "./plugin/open/images/base-close.gif" ;
          if(GetSetting($cDir . '/' . $value,"0") == "1"){
            $cImage = "./plugin/open/images/base-open.gif" ;
          }
        }else{
          $cImage = "./plugin/open/images/folder-close.gif" ;
          if(GetSetting($cDir . '/' . $value,"0") == "1"){
            $cImage = "./plugin/open/images/folder-open.gif" ;
          }
        }
        $cSpace = str_repeat('<img src="./images/empty.gif" width="20px">',($nLevel)) ;
        $cSelected = "" ;
        $cLink = '<a href="main.php?__par=' . getlink('./plugin/open/open-right.php?cDirname=' . $cDir . '/' . $value,false) . '" onClick="javascript:window.open(\'main.php?__par=' . getlink('./plugin/open/open-left.php?cDirStatus=1&cDirOpen=' . $cDir . '/' . $value,false) . '\',\'leftFrame\');return true" target="mainFrame" style="cursor:default">' ;
        $cLink1 = '</a>' ;
        if($cDirOpen == $cDir . '/' . $value){
          $cSelected = "-Select" ;
        }
        $cImageFolder = '<a href="main.php?__par=' . getlink('./plugin/open/open-right.php?cDirname=' . $cDir . '/' . $value,false) . '" onClick="javascript:window.open(\'main.php?__par=' . getlink('./plugin/open/open-left.php?cDirOpen=' . $cDir . '/' . $value,false) . '\',\'leftFrame\');return true" target="mainFrame" style="cursor:default"><img src="' . $cImage . '" border="0px"></a>' ;
        echo('<div onMouseOut="this.className=\'\'" onMouseOver="this.className=\'cell_oddrow\'" style="height:20px; vertical-align:top ">' . $cSpace . '&nbsp;' . $cImageFolder . '<span style="height:20px; vertical-align:top ">' . $cLink . '<span  class="DirOpen' . $cSelected . '">&nbsp;' . $value . '&nbsp;</span>' . $cLink1 . '</span></div>') ;
        if(GetSetting($cDir . '/' . $value,"0") == "1"){
          GetSubDir($cDir . '/' . $value,$nLevel+1) ;
        }
      }  
    }
  }
}
?>