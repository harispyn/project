<?php
  include 'df.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include 'open.jscript.php' ?>
<body style="padding:1px" marginHeight="0px" marginWidth="0px" onLoad="loadLeftFrame();loadFile();">
<form name="form1" method="post">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="3" height="30px" valign="middle">
    <table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #d9d9d9">
      <tr>
        <td width="70px">&nbsp;&nbsp;Address</td>
        <td width="8px">:</td>
        <td style="padding-right:4px">
        <?php
          $txt->Style = "width:100%" ;
          $txt->Show("cAddress","",0,0,true) ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td colspan="4" height="2px" style="background-color:#ede9e3"></td>
  </tr>
  <tr>
    <td height="10px" bgcolor="#f4f4f4" style="border:1px solid #d9d9d9;border-bottom:0px;padding:2px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="50%"><a href="main.php?__par=<?= getlink('./plugin/open/open-right.php?cDirname=' . GetSetting("project_dir"),false) ?>" onClick="javascript:return GetRoot()" target="mainFrame"><strong>&nbsp;:: Project</strong></a></td>
        <td width="50%" align="right">
        <?php
          $txt->Caption = "Show all&nbsp;" ;
          $txt->Checked = GetSetting("ShowProjectAll","T") == "Y" ;
          $txt->onClick = "ajax('','SaveShowProject()',GetFormContent());" ;
          $txt->CheckBox("ckAll","Y") ;
        ?>
        </td>
      </tr>
    </table>      
    </td>
    <td width="2px" style="background-color:#ede9e3"></td>
    <td style="border:1px solid #d9d9d9;border-bottom:0px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="280px" style="cursor:default;border-right:1px solid #d9d9d9" bgcolor="#f4f4f4">&nbsp;<strong>Name</strong></td>
        <td width="80px" align="right" style="cursor:default;border-right:1px solid #d9d9d9" bgcolor="#f4f4f4">&nbsp;<strong>Size&nbsp;</strong></td>
        <td width="150px" align="center" style="cursor:default;border-right:1px solid #d9d9d9" bgcolor="#f4f4f4">&nbsp;<strong>Date Modified</strong></td>
        <td align="center" style="cursor:default" bgcolor="#f4f4f4">&nbsp;<strong>Status</strong></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #d9d9d9" width="200px">
      <iframe style="border:0px" width="200px" height="100%" name="leftFrame" id="leftFrame" scrolling="auto"></iframe>
    </td>
    <td width="2px" style="background-color:#ede9e3"></td>
    <td style="border:1px solid #d9d9d9"><iframe id="mainFrame" name="mainFrame" scrolling="auto" height="100%" width="100%" style="border:0px"></iframe></td>
  </tr>
  <tr>
    <td height="20px" colspan="3" style="background-color:#ede9e3" id="frmStatusBar">&nbsp;</td>
  </tr>
</table>
</form>
</body>
</html>