<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function GetRoot(){
  UpdAddress("") ;
  return true ;
}

function UpdAddress(cPar){
var cProjectDir = "<?php echo(GetSetting("project_dir")) ?>" ;

  with(document.form1){
    cAddress.value = replaceAll(cPar,cProjectDir + "/","") ;
  }
}

function loadFile(){
var o = document.getElementById("mainFrame") ;
  o.src = "main.php?__par=./plugin/open/open-right.php" ;
}

function loadLeftFrame(){
var o = document.getElementById("leftFrame") ;
  o.src = "main.php?__par=./plugin/open/open-left.php" ;
}
</script>