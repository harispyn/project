<?php
  if(!empty($cDirDelete)){
    RemoveDirectory($cDirDelete) ;
  }

  if(!empty($cDirRename)){
    rename($cDirRename,$cDirname . '/' . $cNewDirname) ;
  }
  
  if(!empty($cDirname) && !empty($nRight)){
    SaveSetting("Dirname_Open",$cDirname) ;
    $nRight -= 1 ;
    $va = split("/",$cDirname) ;
    $__cDir = ".." ;
    foreach($va as $key=>$value){      
      if($value !== ".."){
        $__cDir .= '/' . $value ;
        SaveSetting($__cDir,$nRight) ;
      }
    }
  }
  $nDirCount = 0 ;
  $nFileCount = 0 ;
  $nFileSize = 0 ;
?>
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <?php
    $cDir = $cDirname ;
    if(is_dir($cDir)){
      $cFile = "L" . GetSetting("cUserName") ;
      $vaDirShow = IncludeFile($cFile) ;
      $cProjectShowAll = GetSetting("ShowProjectAll","T") ;
      $nWeek = time() - (60*60*24*30) ;

      $d = dir($cDir) ;
      while (false !== ($entry = $d->read())) {
        if(is_dir($cDir . '/' . $entry)){
          if(substr($entry,0,1) !== "."){
            if(isset($vaDirShow[$entry]) || GetSetting("nLevel") == 0 || $cDir <> GetSetting("Project_Dir")){
              if((DirMTime($cDir . '/' . $entry) > $nWeek || $cProjectShowAll == "Y" || $cDir <> GetSetting("Project_Dir"))){
                $vaDir[$entry] = $entry ;
              }
            }
          }
        }else{
          $nPos = strpos($entry,".") ;
          if($nPos === false){
            $cExt = "0" ;
            $cFile = $entry ;            
          }else{
            $cExt = substr($entry,$nPos) ;
            $cFile = substr($entry,0,$nPos) ;
          }
          $vaFile [$cFile][$cExt] = array("File"=>$cFile,"Ext"=>$cExt,"FullName"=>$entry) ;          
          if(empty($vaFile [$cFile]['Ext'])){
            $vaFile [$cFile]['Ext'] = $cExt ;
          }else{
            $vaFile [$cFile]['Ext'] = ".php" ;
          }
          if(empty($vaFile [$cFile]["Time"])){
            $vaFile [$cFile]['Time'] = 0 ;
          }
          $vaFile [$cFile]['Time'] = max(filemtime($cDir . '/' . $entry),$vaFile [$cFile]['Time']) ;

          if(empty($vaFile [$cFile]["Size"])){
            $vaFile [$cFile]['Size'] = 0 ;
          }
          $vaFile [$cFile]['Size'] += filesize($cDir . '/' . $entry) ;
          
          if(empty($vaFile [$cFile]['Link'])){
            $vaFile [$cFile]['Link'] = '' ;
          }
          $vaFile [$cFile]['Link'] .= $entry . '`' ;
        }
      }
      $d->close();
      
      if(!empty($vaDir)){
        ksort($vaDir) ;
        $nDirCount = count($vaDir) ;
        foreach($vaDir as $key=>$value){
          $nTime = DirMTime($cDir . "/" . $value) ;
          $cTime = "" ;
          if(!empty($nTime)){
            $cTime = date("d-m-Y h:i:s",$nTime) ;
          }
          $cDelete = '<a href="Rename" onClick="javascript:return RenameDirectory(\'' . $cDir . '/' . $value . '\',\'' . $cDir . '\')" Title="Rename File / Directory"><img src="./plugin/open/images/rename.gif" border="0"></a>' ;
          $cDelete .= ' <a href="Delete Directory" onClick="javascript:return DeleteDirectory(\'' . $cDir . '/' . $value . '\',\'' . $cDir . '\')" Title="Delete File / Directory"><img src="./plugin/open/images/delete.png" border="0"></a>' ;          
          $cImage = "./images/folder.gif" ;
          if($cDir == GetSetting("project_dir")){
            $cImage = "./images/base.gif" ;
          }
          echo('
          <tr onMouseOver="this.className=\'cell_oddrow\'" onMouseOut="this.className=\'\'">
            <td style="cursor:default;padding-right:1px;padding-left:1px" nowrap width="280px" height="20px" valign="top"><div style="width:280px;overflow:hidden"><div style="width:10000px">&nbsp;&nbsp;<img src="' . $cImage . '"><a style="cursor:default" href="#" onClick="OpenDirectory(\'' . $cDir . '\',\'' . $value . '\')">' . str_replace(" ","&nbsp;",$value) . '</a></div></div></td>
            <td style="cursor:default;padding-right:1px;padding-left:1px" align="right" nowrap width="80px">&nbsp;</td>
            <td style="cursor:default;padding-right:1px;padding-left:1px" align="center" nowrap width="150px">' . $cTime . '</td>
            <td style="cursor:default;padding-right:1px;padding-left:1px" align="center" nowrap>' . $cDelete . '</td>
          </tr>') ;
        }
      }
      if(!empty($vaFile)){
        ksort($vaFile) ;
        $nFileCount = count($vaFile) ;
        foreach($vaFile as $key=>$value){
          $nFileSize += $value ['Size'] ;
          $cID = 'd_' . md5($cDir . $key . time() . rand(0,1000000)) ;
          $cPlush = '<a href="Show Detail" onClick="loadpageornot(\'' . getlink('./plugin/open/open-right.detail.php?cDir=' . $cDir . '&cFileName=' . $key . '&cID=' . $cID,false) . '\',\'' . $cID . '\');return false"><img src="./plugin/open/images/plush.gif" border="0" onMouseOver="lPlush=true;" onMouseOut="lPlush=false"></a>' ;          
          echo('
          <tr onMouseOver="this.className=\'cell_oddrow\'" onMouseOut="this.className=\'\'">
            <td style="cursor:default;padding-right:1px;padding-left:1px" nowrap width="280px"><div style="width:280px;overflow:hidden"><div style="width:10000px">&nbsp;&nbsp;' . $cPlush . GetIcon($value ['Ext']) . '&nbsp;<span style="height:20px; vertical-align:top "><a href="#" onClick="javascript:if(!lPlush) pickFile(\'' . $value ['Link'] . '\',\'' . $cDir. '\')" style="cursor:default">' . $key . '</a></span></div></div></td>
            <td style="cursor:default;padding-right:1px;padding-left:1px" align="right" nowrap valign="top" width="80px">' . GetSize($value ['Size']) . '&nbsp;</td>
            <td style="cursor:default;padding-right:1px;padding-left:1px" align="center" nowrap valign="top" width="150px">' . date("d-m-Y h:i:s",$value ['Time']) . '</td>
            <td style="cursor:default;padding-right:1px;padding-left:1px" align="center" nowrap valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="4" height="1px" id="' . $cID . '"></td>
          </tr>
          ') ;
        }
      }
    }
    $txt->HiddenField("nDirCount",$nDirCount) ;
    $txt->HiddenField("nFileCount",$nFileCount) ;
    $txt->HiddenField("cFileSize",GetSize($nFileSize)) ;
    $txt->HiddenField("nTime",time()) ;
  ?>
</table>