<?php
  include 'df.php' ;
  
function SaveShowProject($va){
  $cSave = "T" ;
  if(isset($va ['ckAll'])){
    $cSave = "Y" ;
  }
  SaveSetting("ShowProjectAll",$cSave) ;
  echo('loadLeftFrame();loadFile();') ;
}
?>