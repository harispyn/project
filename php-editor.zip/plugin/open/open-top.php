<?php
  include 'df.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<body class="cell_eventrow">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%"  border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td valign="middle">
      <table width="100%"  border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td width="70px">&nbsp;&nbsp;Address</td>
          <td width="5px">:</td>
          <td>
          <?php
            $txt->Style = "width:100%" ;
            $txt->Show("cAddress","",0,0,true) ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
