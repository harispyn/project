<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/open/open.php',false) . "','FrmOpenForm','Open',800,500,'',true); return false" ;
?>