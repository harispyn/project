<?php
  $cPlugAction = "Change Password" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/change-password/change-password.php',false) . "','frmChangePassword','Change Password',500,180,'',true);return false" ;
?>