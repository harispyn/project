<?php
  include 'df.php' ;
  
function ChangePassword($va){
  if(md5($va ['cOldPassword']) !== GetSetting("cPassword")){
    echo('alert("Password Lama Tidak Sesuai ....!");') ;
  }else{
    if(empty($va ['cNewPassword'])){
      echo('alert("Password Tidak Boleh Kosong ....!");') ;
    }else if($va ['cNewPassword'] !== $va ['cKonfirmasi']){
      echo('alert("Password Tidak Cocok ...!");') ;
    }else{
      $vaArray = IncludeFile() ;
      $cKey = strtolower(trim($va ['cUserName'])) ;
      if(isset($vaArray [$cKey])){
        $vaArray [$cKey]['Password'] = md5($va ['cNewPassword']) ;
        $cFileName = GetFileName() ;
        SaveArray($vaArray,$cFileName) ;
        echo('alert("Password Anda Telah Diganti ....");') ;
      }else{
        echo('alert("Password Tidak bisa Diganti ....!");') ;
      }
      
    }
  }
}
?>