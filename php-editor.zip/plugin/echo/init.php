<?
	$nWindowHeight = 250 ;
	$nWindowWidth = 500 ;
	$cPlugAction = "Echo" ;
	$cOnClick = "javascript:var o = document.getElementById(&quot;Editor&quot;); o.contentDocument.form1.cTMPInsert.value= &quot;echo('') ;&quot;; return false ;" ;
?>
