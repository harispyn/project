<?
  $cPlugAction = "Setup";
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/setup/setup.php',false) . "','FrmSetup','Configuration',500,240,'',true);return false" ;
?>