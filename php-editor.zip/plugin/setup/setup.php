<?php
  include 'df.php' ;
  include 'setup.db' ;  
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Setup System</title>
</head>
<?php include 'setup.jscript' ?>
<body marginWidth="0" marginHeight="0" onLoad="InitValue()">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:4px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="150px">&nbsp;Project Dir</td>
        <td width="5px">:</td>
        <td>
        <?php 
          $txt->Style = "width:100%" ;
          $txt->Show("project_dir",$project_dir) ; 
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;User List</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Caption = "Yes" ;
          $txt->RadioButton("optUserList","Y") ;
          $txt->Caption = "No" ;
          $txt->Checked = true ;
          $txt->RadioButton("optUserList","N") ;
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;User Login Readonly</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Caption = "Yes" ;
          $txt->RadioButton("optUserLock","Y") ;
          $txt->Caption = "No" ;
          $txt->Checked = true ;
          $txt->RadioButton("optUserLock","N") ;
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;Save MySQL</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Caption = "Yes" ;
          $txt->RadioButton("optMYSQL","Y") ;
          $txt->Caption = "No" ;
          $txt->Checked = true ;
          $txt->RadioButton("optMYSQL","N") ;
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;Hostname / IP</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Show("cMYSQL_IP",$cMYSQL_IP) ;
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;Username</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Show("cMYSQL_User",$cMYSQL_User) ;
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;Password</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Type = "Password" ;
          $txt->Show("cMYSQL_Password",$cMYSQL_Password) ;
        ?>
        </td>
      </tr>
      <tr>
        <td width="100px">&nbsp;Databasename</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Style = "width:100%" ;
          $txt->Show("cMYSQL_Database",$cMYSQL_Database) ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999">
    <table width="100%">
      <tr>
        <td align="right">
        <?php
          $txt->HiddenField("cAction","") ;

          $txt->onClick="javascript:document.form1.cAction.value=&quot;Save&quot;;saving(document.form1)" ;
          $txt->ButtonField("cmdSave","Save") ;

          $txt->onClick="CloseForm()" ;
          $txt->ButtonField("cmdCancel","Cancel") ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
