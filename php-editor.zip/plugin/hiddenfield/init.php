<?php
  $cPlugAction = "Hidden Field" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/hiddenfield/hiddenfield.php',false) . "','FrmHiddenField','Insert Hidden Field',500,110,'',true);return false" ;
?>