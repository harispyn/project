<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Text Box</title>
<link href="../style.css" rel="stylesheet" type="text/css">
</head>
<script language="javascript" type="text/javascript">
  function saveTextbox(){
  var html = "" ;
    with(document.form1){
      html = '$txt->HiddenField("' + cName.value + '","' + cValue.value + '") ;' ;
    }
    var o = self.parent.document.getElementById("Editor") ;
    o.contentDocument.form1.cTMPInsert.value = html ;
    CloseForm() ;
  }
</script>
<body onLoad="document.form1.cName.focus()">
<form  name="form1" method="post">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td class="cell_border"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellpadding="2" cellspacing="0">
                <tr>
                  <td width="26%" valign="top">&nbsp;Name</td>
                  <td width="2%">:</td>
                  <td width="72%">
                  <?php
                    $txt->Show("cName","",40,40) ;
                  ?>
                  </td>
                </tr>
                <tr>
                  <td valign="top">&nbsp;Value</td>
                  <td>:</td>
                  <td valign="top">
                  <?php
                    $txt->Show("cValue","",40,40) ;
                  ?>
                  </td>
                </tr>
              </table></td>
            </tr>
            <tr height="2px">
              <td class="window_frame_midle"></td>
            </tr>
            <tr>
              <td class="cell_white"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="29">&nbsp;                    </td>
                  <td align="right">
                  <?php
                    $txt->onClick="saveTextbox()" ;
                    $txt->ButtonField("cmdOK","OK") ;
                    $txt->onClick = "CloseForm();" ;
                    $txt->ButtonField("cmdCancel","Cancel") ;
                  ?>
                  &nbsp;</td></tr>
              </table></td>
            </tr>
          </table></td>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
