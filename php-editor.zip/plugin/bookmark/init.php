<?php
  $nWindowHeight = 250 ;
  $nWindowWidth = 500 ;
  $cPlugAction = "Bookmark" ;
  $cOnClick = 'javascript:ToggleBookmark();return false;' ;
?>