<?php
  include 'df.php' ;
?>
<html>
<body>
<form name="form1">
<table width="100%"  border="0" cellspacing="0" cellpadding="1">
  <?php
  for($n = 1;$n <= $nField;$n++){
  ?>
  <tr>
    <td width="200px">
    <?php
      $txt->Style = "width:100%" ;
      $txt->Show("cCaption".$n,"caption-".$n) ;
    ?>
    </td>
    <td width="150px">
    <?php
      $txt->Style = "width:100%" ;
      $txt->Show("cNama".$n,"field".$n) ;
    ?>
    </td>
    <td width="100px">
    <?php
      $txt->Style = "width:100%" ;
      $txt->NumberField("nMaxLength".$n,"") ;
    ?>
    </td>
    <td width="100px">
    <?php
      $txt->Style = "width:100%" ;
      $txt->NumberField("nMaxWidth".$n,"") ;
    ?>
    </td>
    <td>
    <select style="width:100%;border:1px solid #7f9db9" name="cJenis<?php echo($n) ?>">
      <option value="text">Text Box</option>
      <option value="date">Date</option>
      <option value="number">Number Box</option>
    </select>
    </td>
  </tr>
  <?php
  }
  ?>
</table>
</form>
</body>
</html>