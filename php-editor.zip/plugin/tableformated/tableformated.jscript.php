<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function optJenis_onClick(field){
  with(document.form1){
    cJudulGrid.disabled = field.value == "2" ;
    cGridQuery.disabled = field.value == "2" ;
  }
}

function cmdSave_onClick(field){
  if(confirm("Data Disimpan ?")){    
    html = "" ;
    with(document.form1){      
      html = GetForm1() ;
    }
    
    if(html !== ""){
      var o = self.parent.document.getElementById("Editor") ;
      o.contentDocument.form1.cTMPInsert.value = html ;
      CloseForm() ;
    }
  }
}

var oFrmGrid = null ;
function GetForm1(){
  oFrmGrid = document.getElementById("field-edit").contentDocument.form1 ;
  var o = document.form1 ;
  var cRowHeight = "" ;
  if(o.optJenis[0].checked) cRowHeight = ' height="20px" ' ;
  
  html = '' ;
  html += '<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">\n' ;
  html += '  <tr>\n' ;
  html += '    <td' + cRowHeight + ' style="border:1px solid #999999;padding:4px">\n' ;
  html += '      <table width="100%"  border="0" cellspacing="0" cellpadding="1">\n' ;
  for(n=1;n<=o.nField.value;n++){
    html += '        <tr>\n' ;
    html += '          <td width="100px">&nbsp;' + oFrmGrid.elements['cCaption'+n].value + '</td>\n' ;
    html += '          <td width="5px">:</td>\n' ;
    html += '          <td>\n' ;
    html += '          \<\?php\n' ;
    html += GetFieldValue(n) ;
    html += '          \?\>\n' ;
    html += '          </td>\n' ;
    html += '        </tr>\n' ;
  }
  html += '      </table>\n' ;
  html += '    </td>\n' ;
  html += '  </tr>\n' ;
  // Bikin Table Browse ;
  if(o.optJenis[0].checked){
    html += '  <tr>\n' ;
    html += '    <td style="border:1px solid #999999;padding:4px">\n' ;
    html += '    <!-- your grid here -->\n' ;
    html += '    \<\?php\n' ;
    html += '      $dbg->SQL("'+o.cGridQuery.value+'") ;\n\n' ;
    if(o.cJudulGrid.value !== ""){
      html += '      $dbg->Caption = "'+o.cJudulGrid.value+'" ;\n' ;  
    }
    html += '      $dbg->Height = "100%";\n' ;
    html += '      $dbg->dataBind() ;\n' ;
    html += '    \?\>\n' ;
    html += '    </td>\n' ;
    html += '  </tr>\n' ;
  }
  html += '  <tr>\n' ;
  html += '    <td height="20px" style="border:1px solid #999999">\n' ;
  html += '      <table width="100%" style="padding:2px">\n' ;
  html += '        <tr>\n' ;
  html += '          <td>\n' ;
  html += '          \<\?php\n' ;
  if(o.ckAdd.checked){
    html += '            $txt->onClick="javascript:getEdit(true,1)" ;\n' ;
    html += '            $txt->ButtonField("cmdAdd","Add") ;\n\n' ;
  }
  if(o.ckEdit.checked){
    html += '            $txt->onClick="javascript:getEdit(true,2)" ;\n' ;
    html += '            $txt->ButtonField("cmdEdit","Edit") ;\n\n' ;
  }
  if(o.ckDelete.checked){
    html += '            $txt->onClick="javascript:getEdit(true,3)" ;\n' ;
    html += '            $txt->ButtonField("cmdDelete","Delete") ;\n' ;
  }
  html += '          \?\>\n' ;
  html += '          </td>\n' ;
  html += '          <td align="right">\n' ;
  html += '          \<\?php\n' ;
  html += '            $txt->HiddenField("cAction","") ;\n' ;
  html += '            $txt->HiddenField("nPos","0") ;\n\n' ;          
  html += '            $txt->onClick="javascript:document.form1.cAction.value=&quot;Save&quot;;saving(document.form1)" ;\n' ;
  html += '            $txt->ButtonField("cmdSave","Save") ;\n\n' ;                          
  html += '            $txt->ButtonField("cmdCancel","Cancel") ;\n' ;
  html += '          \?\>\n' ;
  html += '          </td>\n' ;
  html += '        </tr>\n' ;
  html += '      </table>\n' ;
  html += '    </td>\n' ;
  html += '  </tr>\n' ;
  html += '</table>\n' ;
  return html ;
}

function GetFieldValue(n){
  var html = "" ;
  var c = oFrmGrid.elements['cJenis'+n].value ;
  if(c == "text"){
    html += '            $txt->Show("' + oFrmGrid.elements['cNama'+n].value + '","","' + oFrmGrid.elements['nMaxLength'+n].value + '","' + oFrmGrid.elements['nMaxWidth'+n].value + '") ;\n' ;
  }else if(c == "number"){
    html += '            $txt->NumberField("' + oFrmGrid.elements['cNama'+n].value + '","","' + oFrmGrid.elements['nMaxLength'+n].value + '","' + oFrmGrid.elements['nMaxWidth'+n].value + '") ;\n' ;
  }else if(c == "date"){
    html += '            $txt->DateField("' + oFrmGrid.elements['cNama'+n].value + '",date("d-m-Y")) ;\n' ;
  }
  return html ;
}

function RefreshField(){
var o = document.getElementById("field-edit") ;
  if(o !== null){
    o.src = "main.php?__par=plugin/tableformated/tableformated.field.php&nField="+document.form1.nField.value ;
  }
}

function cFileName_onButtonClick(field){
  OpenForm("main.php?__par=plugin/tableformated/frmsave.php","frmFileName","Save",550,450,'',true) ;
}
</script>
<style type="text/css">
  .sisbody {border:1px solid #999999}
</style>