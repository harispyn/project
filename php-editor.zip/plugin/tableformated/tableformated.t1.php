<?php
  include 'df.php' ;
?>
<table width="100%"  border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td width="100px">Model Form</td>
    <td width="5px">:</td>
    <td valign="center">
    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="25px">
        <?php
          $txt->Checked = true ;
          $txt->RadioButton("optJenis","1") ;
        ?>
        </td>
        <td><img src="./plugin/tableformated/images/form1.gif"></td>
        <td width="25px">
        <?php
          $txt->RadioButton("optJenis","2") ;
        ?>
        </td>
        <td><img src="./plugin/tableformated/images/form2.gif"></td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td width="100px">Jumlah Field</td>
    <td width="5px">:</td>
    <td>
    <?php
      $txt->onBlur = "RefreshField()" ;
      $txt->NumberField("nField","2",5,5) ;
    ?>
    </td>
  </tr>
  <tr>
    <td>Judul Grid</td>
    <td width="5px">:</td>
    <td>
    <?php
      $txt->Style="width:100%" ;
      $txt->Show("cJudulGrid","") ;
    ?>
    </td>
  </tr>
  <tr>
    <td>Grid SQL</td>
    <td width="5px">:</td>
    <td>
    <?php
      $txt->Style="width:100%" ;
      $txt->Show("cGridQuery","SELECT * from table") ;
    ?>
    </td>
  </tr>
    <tr>
    <td>Edit Button</td>
    <td width="5px">:</td>
    <td>
    <?php
      $txt->Checked = true ;
      $txt->Caption = "Add " ;
      $txt->CheckBox("ckAdd","1") ;
      
      $txt->Checked = true ;
      $txt->Caption = "Edit " ;
      $txt->CheckBox("ckEdit","1") ;
      
      $txt->Checked = true ;
      $txt->Caption = "Delete" ;
      $txt->CheckBox("ckDelete","1") ;
    ?>
    </td>
  </tr>
  <tr><td colspan="3" height="5px"></td></tr>
  <tr>
    <td colspan="3" style="background-color:d9d9d9">
      <table width="100%"  border="0" cellspacing="0" cellpadding="1">
        <tr>
          <td width="200px" align="center">Caption</td>
          <td width="150px" align="center">Field Name</td>
          <td width="100px" align="center">Max Length</td>
          <td width="100px" align="center">Max Width</td>
          <td align="center">Field Type</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td colspan="3" style="border:1px solid #d9d9d9"><iframe id="field-edit" height="170px" width="100%" style="border:0px"></iframe></td>
  </tr>
</table>
