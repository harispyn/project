<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/tableformated/tableformated.php',false) . "','FrmTableFormated','Insert Table',700,550,'',true); return false" ;
?>