<?php
  include 'df.php' ;
  
  $cError = "" ;
  if(!empty($cAction)){
    if(empty($cProject)){
      $cError .= "- Nama Project Tidak Boleh Kosong ....!\\n" ;
    }
    
    $cProjectTarget = GetSetting("project_dir") . "/" . $cProject ;
    if(is_dir($cProjectTarget)){
      $cError .= "- Project Sudah Ada, Tidak bisa di Replace .....!\\n" ;
    }
    
    if(empty($_FILES['cFileName']['tmp_name'])){
      $cError .= "- Uploads File Gagal ....!\\n" ;
    }
    
    if(empty($cError)){
      ExtractFile($_FILES['cFileName'],$cProjectTarget) ;
    }
  }
  $cLoad = "" ;
  if(!empty($cError)){
    $cLoad = "alert('" . $cError . "');" ;
  }
?>