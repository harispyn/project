<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/unzip/unzip.php',false) . "','FrmUploadProject','Uploads Project',500,150,'',true);return false" ;
?>