<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function cmdProsess_onClick(field){
  with(document.form1){
    cAction.value = "Prosess" ;
    submit() ;
  }
}
</script>