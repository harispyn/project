<?php
  include 'df.php' ;
  include 'unzip.db.php' ;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Open File</title>
</head>
<?php include 'unzip.jscript.php' ?>
<body marginheight="0" marginwidth="0" onLoad="<?php echo($cLoad) ?>">
<form action="main.php?__par=<?= getlink($__par,false) ?>" method="post" enctype="multipart/form-data" name="form1">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:4px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="100px">File Name</td>
        <td width="5px">:</td>
        <td><input name="cFileName" type="file" id="cFileName" size="40"></td>
      </tr>
      <tr>
        <td> Project Name</td>
        <td>:</td>
        <td>
        <?php
          $txt->Style = "width:90%" ;
          $txt->Show("cProject","",50,50) ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:5px" align="right">
    <?php
      $txt->HiddenField("cAction","") ;
      $txt->ButtonField("cmdProsess","Prosess") ;
      
      $txt->onClick = "CloseForm()" ;
      $txt->ButtonField("cmdClose","Close") ;
    ?>
    </td>
  </tr>
</table>
</form>
</body>
</html>
<?php
  function ExtractFile($vaFile,$cProjectTarget){
    if(!is_dir($cProjectTarget)){
      mkdir($cProjectTarget,0777) ;
    }
    include 'dunzip2.inc.php' ;
    $zip = new dUnzip2($vaFile ['tmp_name']) ;
    $zip->unzipAll($cProjectTarget) ;
  }
?>
