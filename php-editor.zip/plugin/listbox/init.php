<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/listbox/listbox.php',false) . "','FrmListBox','List/Menu Box',400,165,'',true); return false" ;
?>