<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
var od = null ;
function cmdFind_onClick(field){
  InitGrid() ;
  ajax('','FindContent()',GetFormContent()) ;
}

function InitGrid(){
var nRow = DBGRID1.Rows() ;
  for(n=0;n<nRow;n++){
    DBGRID1.DeleteRow(0) ;
  }
}

function Form_onLoad(){
  o = self.parent.document.getElementById("Editor") ;
  od = o.contentWindow.document ;
  InitGrid() ;
  fieldfocus(document.form1.cFind) ;
}

function Form_onClose(){
  od.form1.cSource.focus() ;
  return true ;
}

function DBGRID1_onDblClick(vaRow,nCol){
  if(confirm("Open File ?")){
    with(self.parent.document.form1){
      action = "main.php?__par=<?php getlink('./project_edit.php') ?>&cOpenDir=" + vaRow [1] + "&cOpenFile=" + vaRow [2] ;
      submit() ;
    }
  }
}

function Finish(){
  if(DBGRID1.Rows() > 0){
    alert(DBGRID1.Rows() + " Files Found ") ;
  }else{
    alert("Parse Not Found..... ") ;
  }
}
</script>