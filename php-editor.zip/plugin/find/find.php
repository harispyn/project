<?php
  include 'df.php' ;
  include 'find.db.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Find & Replace</title>
</head>
<?php include 'find.jscript.php' ?>
<body>
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:4px" height="10px">
      <table width="100%"  border="0" cellspacing="0" cellpadding="1">
        <tr>
          <td width="100px">&nbsp;Project Name</td>
          <td width="5px">:</td>
          <td>
          <?php 
            $txt->Style="Width:100%" ;
            $txt->Show("cProjectName",GetSetting("cSession_DevProject"),0,0,true) ; 
          ?>
          </td>
        </tr>
        <tr>
          <td width="100px">&nbsp;Find what</td>
          <td width="5px">:</td>
          <td>
          <?php 
            $txt->Style="Width:100%" ;
            $txt->Show("cFind",GetSetting("cFind_Find","")) ; 
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #999999;padding:4px">
    <?php
      $vaArray[0] = array("Form Name"=>" ","Dir"=>" ","File"=>" ") ;

      $dbg->Array = $vaArray ;
      $dbg->Col ['Form Name'] = array("Width"=>680) ;
      $dbg->Col ['Dir'] = array("Width"=>0) ;
      $dbg->Col ['File'] = array("Width"=>0) ;
      $dbg->Scrolling = "vertical" ;
      $dbg->Height = "100%" ;
      $dbg->DataBind() ;
    ?>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999">
      <table width="100%" style="padding:2px">
        <tr>
          <td align="right">
          <?php
            $txt->ButtonField("cmdFind","Find") ;

            $txt->onClick = "CloseForm();" ;
            $txt->ButtonField("cmdClose","Close") ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</form>
</body>
</html>
