<?php
  include 'df.php' ;
  
function FindContent($va){
  SaveSetting("cFind_Find",$va ['cFind']) ;
  $cFind = strtolower($va ['cFind']) ;
  $cDir = GetSetting("project_dir") . "/" . GetSetting("cSession_DevProject") ;
  FindAndFound($cDir,$cFind) ;
  echo('Finish() ;') ;
}

function FindAndFound($cDir,$cFind){
  if(is_dir($cDir)){
    $d = dir($cDir) ;
    while (false !== ($entry = $d->read())) {
      if(substr($entry,0,1) !== "."){
        if(is_dir($cDir . '/' . $entry)){
          $vaDir [$entry] = $entry ;
        }else{
          $vaKey = split("\.",$entry) ;
          $cKey = $vaKey [0] ;
          if(!isset($vaFile [$cKey])){
            $vaFile [$cKey]["File"] = "" ;
          }
          $vaFile [$cKey]["File"] .= $entry . "`" ;
          $vaFile [$cKey][$entry] = $entry ;
        }
      }
    }
    $d->close();  
    if(!empty($vaFile)){
      ksort($vaFile) ;
      foreach($vaFile as $key1=>$value1){
        $lFound = false ;
        foreach($value1 as $key=>$value){
          if($key !== "File" && !$lFound){
            $cFileName = $cDir . "/" . $value ;
            if(is_file($cFileName)){
              $vaF = pathinfo($cFileName) ;
              $cExt = "" ;
              if(isset($vaF ['extension'])) $cExt = strtolower($vaF ['extension']) ;
              if($cExt == "php" || $cExt == "ajax" || $cExt == "db" || $cExt == "jscript" || $cExt == "menu"){
                $cContent = "" ;
                $file = fopen($cFileName,"r");
                $size_of_file = filesize($cFileName);
                if($size_of_file > 0){
                  $cContent = fread($file, $size_of_file);
                }
                fclose($file);
          
                if(!empty($cContent)){                  
                  $nPos = strpos(strtolower($cContent),$cFind) ;
                  if ($nPos === false) {
                  }else{
                    $lFound = true ;
                    echo('
                      va = ["' . $cDir . "/" . $key1 . '","' . $cDir . '","' . $value1 ['File'] . '"] ;
                      DBGRID1.AppendRow(va) ;
                    ') ;
                  }
                }
              }
            }
          }
        }      
      }
    }
  
    if(!empty($vaDir)){
      ksort($vaDir) ;
      foreach($vaDir as $key=>$value){
        FindAndFound($cDir . "/" . $value,$cFind) ;
      }
    }
  }
}
?>