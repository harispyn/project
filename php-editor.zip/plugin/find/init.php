<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript:OpenForm('main.php?__par=./plugin/find/find.php','FrmSearch','Find',700,400,'',true);return false" ;
?>