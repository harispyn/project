<?php
  $nWindowHeight = 250 ;
  $nWindowWidth = 500 ;
  $cPlugAction = "Next Bookmark" ;
  $cOnClick = 'javascript:NextBookmark(\'Prev\');return false;' ;
?>
