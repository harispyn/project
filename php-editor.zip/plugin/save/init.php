<?
	$nWindowHeight = 250 ;
	$nWindowWidth = 500 ;
	$cPlugAction = "Save File" ;
	$cOnClick = 'javascript:savePHP(); return false;' ;
?>