<?php
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/charmap/charmap.php',false) . "','FrmInsertSpacialmap','Select Customer Character',570,275,'',true); return false" ;
?>