<?php
  $cPlugAction = "Project List" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/project-list/project-list.php',false) . "','frmProjectList','Project List Setup',500,500,'',true);return false;" ;
?>