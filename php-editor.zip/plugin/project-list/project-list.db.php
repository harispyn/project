<?php
  include 'df.php' ;
  
function GetDir(){
  $cDir = GetSetting("project_dir") ;
  $d = dir($cDir) ;
  while (false !== ($entry = $d->read())) {
    if(is_dir($cDir . '/' . $entry)){
      if(substr($entry,0,1) !== "."){
        $vaDir[$entry] = $entry ;
      }
    }
  }
  $d->close();
  ksort($vaDir) ;
  return $vaDir ;
}
?>