<?php
  include 'df.php' ;
  
function SaveProjectList($va){
  $vaArray = array() ;  
  foreach($va as $key=>$value){
    if(substr($key,0,3) == "_ck"){
      $vaArray [$value] = $value ;
    }
  }
  
  $cFile = "L".$va ['cUserName'] ;
  $cFileName = GetFileName($cFile) ;
  SaveArray($vaArray,$cFileName) ;
  echo('alert("File Telah Disimpan .....!");') ;
}

function RefreshProject($va){
  $cFile = "L".$va ['cUserName'] ;
  $vaShow = IncludeFile($cFile) ;
  echo('var __o = document.getElementById("__content").contentDocument.form1 ;') ;
  if(!empty($vaShow)){
    foreach($vaShow as $key=>$value){
      $ck = str_replace(".","_",str_replace("-","x",$key)) ;
      echo('if(typeof __o._ck'.$ck.' == "object"){
        __o._ck'.$ck.'.checked = true;
      }') ;
    }
  }
}
?>