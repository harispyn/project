<?php
  include 'df.php' ;
  include 'project-list.db.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include 'project-list.jscript.php' ?>
<body>
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:4px">
    <table width="100%"  border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="100px">User Name</td>
        <td width="5px">:</td>
        <td>
        <select name="cUserName" size="1" onKeyUp="validate(this,event)" onClick="RefreshProject()">
        <?php
          $vaUser = IncludeFile() ;
          if(!empty($vaUser)){
            foreach($vaUser as $key=>$value){
              echo('<option value="' . $value['UserName'] . '">' . $value['UserName'] . '</option>') ;
            }
          }
        ?>
        </select>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr>
    <td style="border:1px solid #999999;padding:4px">
    <iframe id="__content" scrolling="auto" height="100%" width="100%" style="border:0px" src="main.php?__par=<?php getlink("./plugin/project-list/project-list.show.php") ?>"></iframe>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999;padding:5px" align="right">
    <?php
      $txt->ButtonField("cmdSave","Save") ;
      
      $txt->onClick = "CloseForm()" ;
      $txt->ButtonField("cmdClose","Close") ;
    ?>
    </td>
  </tr>
</table>
</form>
</body>
</html>
