<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function cmdSave_onClick(field){
var o = document.getElementById("__content").contentDocument.form1 ;
var c = GetFormContent() + "&" + GetFormContent(o) ;
var nUserLevel = '<?php echo(GetSetting("nLevel")) ?>' ; 
var nTotProject = 0 ;
  for(n=0;n<o.length;n++){  
    if(o.elements[n].name.substring(0,3) == "_ck"){
      if(o.elements[n].checked){
        nTotProject ++ ;
      }
    }
  }

  if(nTotProject > 5 && nUserLevel !== '0'){
    alert("Project yang diaktifkan Tidak boleh lebih dari 5 Project ...!") ;
  }else{
    ajax('',"SaveProjectList()",c) ;
  }
}

function RefreshProject(){
var o = document.getElementById("__content").contentDocument.form1 ;
  for(n=0;n<o.elements.length;n++){
    if(o.elements[n].type = "checkbox"){
      o.elements[n].checked = false ;
    }
  }
  ajax('',"RefreshProject()",GetFormContent()) ;
}
</script>