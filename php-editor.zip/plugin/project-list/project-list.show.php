<?php
  include 'df.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<body>
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<?php
  $vaDir = GetDir() ;
  foreach($vaDir as $key=>$value){
    $txt->Caption = $value . "<br>" ;
    $c = str_replace(".","_",str_replace("-","x",$value)) ;
    $txt->CheckBox("_ck" . $c,$value) ;
  }
?>
</form>
</body>
</html>
<?php
function GetDir(){
  $cDir = GetSetting("project_dir") ;
  $d = dir($cDir) ;
  while (false !== ($entry = $d->read())) {
    if(is_dir($cDir . '/' . $entry)){
      if(substr($entry,0,1) !== "."){
        $vaDir[$entry] = $entry ;
      }
    }
  }
  $d->close();
  ksort($vaDir) ;
  return $vaDir ;
}
?>