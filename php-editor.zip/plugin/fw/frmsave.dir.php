<?php
  include 'df.php' ; 
  
  if(!empty($cDirOpen)){
    SaveSetting("Save_Dir_Open",$cDirOpen) ;
    $cOpen = GetSetting("SS" . $cDirOpen) ;
    if($cOpen == "1"){
      $cOpen = "0" ;
    }else{
      $cOpen = "1" ;
    }
    SaveSetting("SS" . $cDirOpen,$cOpen) ;
  }else{
    $cDirOpen = GetSetting("Save_Dir_Open") ;
  }
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>
<script language="javascript" type="text/javascript">
function savePos(){
  cValue = window.document.body.scrollLeft + "::" + window.document.body.scrollTop ;
  writeCookie("save_scroll_pos",cValue)
}

function getPos(){
var va = readCookie("save_scroll_pos").split("::") ;
  window.scrollTo(va [0],va [1]) ;

  with(self.parent.document.form1){
    cDirectory.value = document.form1.cDirOpen.value ;
    fieldfocus(cFileName) ;
  }
}
</script>
<style type="text/css">
  .DirOpen {padding:2px 0px 2px 0px; cursor:default}
  
  .DirOpen-Select {background-color:#0033CC; color:#FFFFFF; padding:2px 0px 2px 0px; cursor:default}
</style>
<body onUnload="savePos()" onLoad="getPos()">
<form name="form1" method="post" action="<?= $_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false) ?>">
<table width="100%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td class="cell_eventrow">
    <?php
      getPHPFile(GetSetting("project_dir"),0) ;
    ?>
    </td>
  </tr>
</table>
<?php
  $txt->HiddenField("cDirOpen",$cDirOpen) ;
?>
</form>
</body>
</html>
<?php
function getPHPFile($cDir,$nLevel){
    $cDirOpen = GetSetting("Save_Dir_Open") ;
    $vaDir = array() ;
    $cImages = str_repeat('<img src="./images/empty.gif">&nbsp;',$nLevel) ;
    if(is_dir($cDir)){
      $d = dir($cDir) ;        
      while (false !== ($entry = $d->read())) {
        if(is_dir($cDir . '/' . $entry)){
          if(substr($entry,0,1) !== "."){
            $vaDir [$entry] = $entry ;
          }
        }
      }
      $d->close();
    }
    
    asort($vaDir) ;
    $cImgEmpty = str_repeat('<img src="./images/empty.gif" border="0" width="20px">',$nLevel) ;        
    foreach($vaDir as $key=>$entry){
      $cFolderOpened = GetSetting("SS" . $cDir . '/' . $entry) == "1" ;
      if($nLevel == 0){
        $cImages = '<img src="./plugin/fw/images/base-close.gif" border="0">' ;
        if($cFolderOpened == "1"){
          $cImages = '<img src="./plugin/fw/images/base-open.gif" border="0">' ;
        }
      }else{
        $cImages = '<img src="./plugin/fw/images/folder-close.gif" border="0">' ;
        if($cFolderOpened == "1"){
          $cImages = '<img src="./plugin/fw/images/folder-open.gif" border="0">' ;
        }
      }
      
      $cClass = "DirOpen" ;
      if($cDir . '/' . $entry == $cDirOpen){
        $cClass = "DirOpen-Select" ;
      }
      $cLink = '<a href="main.php?__par=' . getlink('./plugin/fw/frmsave.dir.php?cDirOpen=' . $cDir . '/' . $entry,false) . '">' ;
      echo('&nbsp;' . $cImgEmpty . $cImages . $cLink . '<span style="height:20px; vertical-align:top " class="' . $cClass . '">&nbsp;' . $entry . '&nbsp;</span></a><br> ') ;
      if($cFolderOpened == "1"){
        getPHPFile($cDir . '/' . $entry,$nLevel + 1) ;
      }
    }
  }
?>