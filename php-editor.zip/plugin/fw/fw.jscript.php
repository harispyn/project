<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function optJenis_onClick(field){
  with(document.form1){
    cJudulGrid.disabled = field.value == "2" ;
    cGridQuery.disabled = field.value == "2" ;
  }
}

function cmdSave_onClick(field){  
  var of = document.getElementById("field-edit").contentWindow ;
  of.setQuery() ;
  ajax('','CreateFormWizart()',GetFormContent()+'&'+GetFormContent(of.document.form1)) ;
}

function CreateFormWizart(){
var f = document.form1 ;
var _cFile = "" ;
  if(confirm("Data Disimpan ?")){
    _cFile = f.cFile.value + ".php`" + f.cFile.value + ".jscript.php`" + f.cFile.value + ".ajax.php`" + f.cFile.value + ".db.php" ;
    with(self.parent.document.form1){
      action = "main.php?__par=<?php getlink('./project_edit.php') ?>&cOpenDir=" + document.form1.cDir.value + "&cOpenFile=" + _cFile ;
      submit() ; 
    }
  }
}

function cFileName_onButtonClick(field){
  OpenForm("main.php?__par=plugin/fw/frmsave.php","frmFileName","Save",550,450,'',true) ;
}

function cNamaTable_onBlur(field){
  document.form1.cGridQuery.value = "SELECT * FROM " + field.value ;
}

var oField = null ;
function Form_onLoad(){
  oField = document.getElementById("field-edit") ;
  oField.src = "main.php?__par=./plugin/fw/fw.init.php" ;
}

function cDatabase_onButtonClick(field){
var cSQL = "Show Databases like '" + field.value + "%'" ;
  Browse(cSQL,field.name) ;
}

function cDatabase_onBlur(field){
  ajax('',"SeekDatabase()",GetFormContent()) ;
}

function cNamaTable_onButtonClick(field){
  if(document.form1.cDatabase.value == ""){
    alert("Database Masih Kosong ....!") ;
  }else{
    var cSQL = "Show tables from " + document.form1.cDatabase.value + " like '" + field.value + "%'" ;
    Browse(cSQL,field.name) ;
  }
}

function cmdLoadField_onClick(field){
var f = document.form1 ;
  OpenForm("./main.php?__par=./plugin/fw/frmpickfield.php&cDatabase="+f.cDatabase.value+"&cTable="+f.cNamaTable.value,"FrmPickField","Table Field",700,500,'',true) ;
}

function cmdPreview_onClick(field){
  var of = document.getElementById("field-edit").contentWindow ;
  of.setQuery() ;
  ajax('','FormPreview()',GetFormContent()+'&'+GetFormContent(of.document.form1)) ;
}
</script>
<style type="text/css">
  .sisbody {border:1px solid #999999}

  .icons {padding:3px;border:0} 
  .icons:hover {padding:2px;border:1px solid #000080;background-color:#ffd397}
  .icons-disable{padding:3px;border:0;opacity: 0.3; cursor:default}  
</style>