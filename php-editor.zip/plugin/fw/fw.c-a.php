<?php
  include 'df.php' ;

  // Buat Daftar Field
  $cFieldList = "" ;
  $nLen = 0 ;
  foreach($vaFields as $key=>$n){
    if(!empty($va ['cFieldName'.$n])){
      if($cFieldList !== "") $cFieldList .= "," ;
      if(strlen($cFieldList) - $nLen >= 80){
        $cFieldList .= "\n                               " ;
        $nLen = strlen($cFieldList) ;
      }
      $cFieldList .= $va['cFieldName'.$n] ;
    }
  }
  $cNamaTable = $va ['cNamaTable'] ;

  $cSource = "<?php\n" ;
  $cSource .= "  include 'df.php' ;\n\n" ;
  
  $cSource .= "function SeekKode(\$va){\n" ;
  $cSource .= "  Global \$objData ;\n" ;
  $cSource .= "  \$$cVariableKey = \$va['$cVariableKey'] ;\n" ;
  $cSource .= "  if(trim(\$$cVariableKey)<>\"\"){\n" ;
  $cSource .= "    \$dbData = \$objData->Browse(\"$cNamaTable\",\"$cFieldList\",\"$cFieldKey = '\$$cVariableKey'\") ;\n" ;
  $cSource .= "    if(\$dbRow = \$objData->GetRow(\$dbData)){\n" ;
  $cSource .= "      echo('\n" ;
  $cSource .= "        with(document.form1){\n" ;
  foreach($vaFields as $key=>$n){
    if(trim($va ['cFieldName'.$n]) <> ""){
      $c = $va['cJenis'.$n] ;
      $f = "" ;
      $f1 = "" ;
      if($c == "number"){
        $f = "Number2String(" ;
        $f1 = ",{$va['nDecimal'.$n]})" ;
      }else if($c == "date"){
        $f = "String2Date(" ;
        $f1 = ")" ;
      }  
    
      $cSource .= "          " . $va['cNama'.$n] . ".value = \"' . $f\$dbRow['" . $va['cFieldName'.$n] . "']$f1 . '\" ;\n" ;
    }
  }
  $cSource .= "        }\n" ;
  $cSource .= "      ') ;\n" ;
  $cSource .= "      if(\$va['nPos'] == 3){\n" ;
  $cSource .= "        echo('ConfirmDelete();') ;\n" ;
  $cSource .= "      }\n" ;
  $cSource .= "      if(\$va['nPos'] == 1){\n" ;
  $cSource .= "        echo('alert(\"Data Sudah Ada, Transaksi Tidak bisa Dilanjutkan ...!\");getEdit(false);') ;\n" ;
  $cSource .= "      }\n" ;
  $cSource .= "    }else{\n" ;
  $cSource .= "      if(\$va['nPos'] <> 1){\n" ;
  $cSource .= "        echo('alert(\"Data Tidak Ditemukan ...!\");getEdit(false);') ;\n" ;
  $cSource .= "      }\n" ;
  $cSource .= "    }\n" ;
  $cSource .= "  }\n" ;
  $cSource .= "}\n\n" ;
  
  $cSource .= "function DeleteData(\$va){\n" ;
  $cSource .= "  Global \$objData ;\n" ;
  $cSource .= "  \$$cVariableKey = \$va['$cVariableKey'] ;\n" ;
  $cSource .= "  \$objData->Delete(\"$cNamaTable\",\"$cFieldKey = '\$$cVariableKey'\") ;\n" ;
  if($va ['optJenis'] == 1){
    $cSource .= "  echo('\n" ;
    $cSource .= "    with(document.form1){\n" ;
    $cSource .= "      cAction.value = \"\";\n" ;
    $cSource .= "      submit();\n" ;
    $cSource .= "    }\n" ;
    $cSource .= "  ') ;\n" ;
  }else{
    $cSource .= "  echo('getEdit(false);') ;\n" ;
  }
  $cSource .= "}\n\n" ;

  $cSource .= "function ValidSaving(\$va){\n" ;
  $cSource .= "  \$lValid = true ;\n" ;
  $cSource .= "  if(\$lValid){\n" ;
  if($va ['optJenis'] == 1){
    $cSource .= "    echo('SaveAll();');\n" ;
  }else{
    $cSource .= "    SaveTransaksi(\$va);\n" ;
  }
  $cSource .= "  }\n" ;
  $cSource .= "}\n" ;
  
  if($va ['optJenis'] == 2){
    $cSave = "" ;
    $nLen = 0 ;
    foreach($vaFields as $key=>$n){
      if(trim($va ['cFieldName'.$n]) <> ""){
        if($cSave <> "") $cSave .= "," ;
        if(strlen($cSave) - $nLen >= 80){
          $cSave .= "\n               " ;
          $nLen = strlen($cSave) ;
        }
        $cSave .= "\"" . $va['cFieldName'.$n] . "\"=>" ;

        $c = $va['cJenis'.$n] ;
        if($c == "text"){
          $cSave .= "\$va['" . $va['cNama'.$n] . "']" ;
        }else if($c == "number"){
          $cSave .= "String2Number(\$va['" . $va['cNama'.$n] . "'])" ;
        }else if($c == "date"){
          $cSave .= "Date2String(\$va['" . $va['cNama'.$n] . "'])" ;
        }
      }
    }
  
    $cSource .= "\n" ;
    $cSource .= "function SaveTransaksi(\$va){\n" ;
    $cSource .= "  Global \$objData ;\n" ;
    $cSource .= "  \$va1 = array(" . $cSave . ") ;\n" ;
    $cSource .= "  \$objData->Update(\"" . $va['cNamaTable'] . "\",\$va1,\"" . $cFieldKey . " = '{\$va['" . $cVariableKey . "']}'\") ;\n" ;
    $cSource .= "  echo('getEdit(false);') ;\n" ;
    $cSource .= "}\n" ;
  }
  
  $cSource .= "?>" ;
?>