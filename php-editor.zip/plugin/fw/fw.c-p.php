<?php
  include 'df.php' ;

  $cSource = "" ;
  if(!$lPreview){
    $cSource .= "<?php\n" ;
    $cSource .= "  include 'df.php' ;\n" ;
    $cSource .= "  include GetFileModul(__FILE__,'.db.php') ;\n" ;
    $cSource .= "?>\n" ;
  }
  $cSource .= "<html>\n" ;
  $cSource .= "<head>\n" ;
  $cSource .= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n" ;
  $cSource .= "<title>Assistindo.Net</title>\n" ;
  $cSource .= "</head>\n" ;
  if(!$lPreview) $cSource .= "<?php include GetFileModul(__FILE__,'.jscript.php') ?>\n" ;
  $cSource .= "<body>\n" ;
  $cSource .= "<form name=\"form1\" method=\"post\" action=\"<?php echo(\$_SERVER['PHP_SELF'] . '?__par=' . getlink(\$__par,false)) ?>\">\n" ;
  
  // Form Body
  $cRowHeight = "" ;
  if($va ['optJenis'] == 1) $cRowHeight = 'height="20px"' ;
  $cSource .= "<table width=\"100%\" height=\"100%\" border=\"0\" cellspacing=\"3\" cellpadding=\"0\" class=\"cell_eventrow\">\n" ;
  $cSource .= "  <tr>\n" ;
  $cSource .= "    <td $cRowHeight style=\"border:1px solid #999999;padding:4px\">\n" ;
  $cSource .= "      <table width=\"100%\"  border=\"0\" cellspacing=\"0\" cellpadding=\"1\">\n" ;
  
  // Field Transaksi
  for($n=0;$n<count($vaFields);$n++){
    $cSpace = " " ;
    if($lPreview) $cSpace = "&nbsp;" ;
    $cSource .= "        <tr>\n" ;
    $cSource .= "          <td width=\"100px\">" . str_replace(" ",$cSpace,$va['cCaption'.$vaFields[$n]]) . "</td>\n" ;
    $cSource .= "          <td width=\"5px\">:</td>\n" ;
    $cSource .= "          <td>\n" ;
    $cSource .= "          <?php\n" ;
    $cSource .= GetFieldValue($va,&$n,$vaFields,$lPreview) ;
    $cSource .= "          ?>\n" ;
    $cSource .= "          </td>\n" ;
    $cSource .= "        </tr>\n" ;
  }
  
  $cSource .= "      </table>\n" ;
  $cSource .= "    </td>\n" ;
  $cSource .= "  </tr>\n" ;
  
  // Jika Jenis Form Model 1 Maka Grid Ada
  if($va ['optJenis'] == 1){
    $cSource .= "  <tr>\n" ;
    $cSource .= "    <td style=\"border:1px solid #999999;padding:4px\">\n" ;
    if(!$lPreview){
      $cSource .= "    <!-- your grid here -->\n" ;
      $cSource .= "    <?php\n" ;
      $cSource .= "      \$dbg->SQL(\"" . $va['cGridQuery'] . "\") ;\n\n" ;
  
      $cSource .= "      \$dbg->Caption = \"" . $va['cJudulGrid'] . "\" ;\n" ;
      $cSource .= "      \$dbg->Height = \"100%\";\n" ;
      $cSource .= "      \$dbg->dataBind() ;\n" ;
      $cSource .= "    ?>\n" ;
    }else{
      $cSource .= "&nbsp;" ;
    }
    $cSource .= "    </td>\n" ;
    $cSource .= "  </tr>\n" ;
  }
  $cSource .= "  <tr>\n" ;
  $cSource .= "    <td height=\"20px\" style=\"border:1px solid #999999\">\n" ;
  $cSource .= "      <table width=\"100%\" style=\"padding:2px\">\n" ;
  $cSource .= "        <tr>\n" ;
  $cSource .= "          <td>\n" ;
  $cSource .= "          <?php\n" ;
  $cSource .= "            \$txt->onClick=\"javascript:getEdit(true,1)\" ;\n" ;
  if($lPreview) $cSource .= "\$txt->Disabled = true ;\n" ;
  $cSource .= "            \$txt->ButtonField(\"cmdAdd\",\"Add\") ;\n\n" ;

  $cSource .= "            \$txt->onClick=\"javascript:getEdit(true,2)\" ;\n" ;
  if($lPreview) $cSource .= "\$txt->Disabled = true ;\n" ;
  $cSource .= "            \$txt->ButtonField(\"cmdEdit\",\"Edit\") ;\n\n" ;

  $cSource .= "            \$txt->onClick=\"javascript:getEdit(true,3)\" ;\n" ;
  if($lPreview) $cSource .= "\$txt->Disabled = true ;\n" ;
  $cSource .= "            \$txt->ButtonField(\"cmdDelete\",\"Delete\") ;\n" ;
  $cSource .= "          ?>\n" ;
  $cSource .= "          </td>\n" ;
  $cSource .= "          <td align=\"right\">\n" ;
  $cSource .= "          <?php\n" ;
  $cSource .= "            \$txt->HiddenField(\"cAction\",\"\") ;\n" ;
  $cSource .= "            \$txt->HiddenField(\"nPos\",\"0\") ;\n\n" ;

  if($lPreview) $cSource .= "\$txt->Disabled = true ;\n" ;
  $cSource .= "            \$txt->ButtonField(\"cmdSave\",\"Save\") ;\n" ;
  if($lPreview) $cSource .= "\$txt->Disabled = true ;\n" ;
  $cSource .= "            \$txt->ButtonField(\"cmdCancel\",\"Cancel\") ;\n" ;
  $cSource .= "          ?>\n" ;
  $cSource .= "          </td>\n" ;
  $cSource .= "        </tr>\n" ;
  $cSource .= "      </table>\n" ;
  $cSource .= "    </td>\n" ;
  $cSource .= "  </tr>\n" ;
  $cSource .= "</table>\n" ;
  
  $cSource .= "</form>\n" ;
  $cSource .= "</body>\n" ;
  $cSource .= "</html>" ;
  
function GetFieldValue($va,$i,$vaFields,$lPreview){
  $n = $vaFields [$i] ;
  $c = $va['cJenis'.$n] ;
  $cReadOnly = "" ;
  if(isset($va ['ckReadOnly'.$n])) $cReadOnly = ",true" ;
  $html = "" ;
  if($lPreview) $html .= "\$txt->Disabled = true ;\n" ;
  if($c == "text"){
    if(isset($va ['ckButton'.$n])){
      $html .= "            \$txt->Button = true ;\n" ;
    }
    $html .= "            \$txt->Show(\"" . $va['cNama'.$n] . "\",\"\",\"" . $va['nMaxLength'.$n] . "\",\"" . $va['nMaxWidth'.$n] . "\"$cReadOnly) ;\n" ;
  }else if($c == "number"){
    $html .= "            \$txt->NumberField(\"" . $va['cNama'.$n] . "\",\"\",\"" . $va['nMaxLength'.$n] . "\",\"" . $va['nMaxWidth'.$n] . "\"$cReadOnly) ;\n" ;
  }else if($c == "date"){
    $html .= "            \$txt->DateField(\"" . $va['cNama'.$n] . "\",date(\"d-m-Y\")$cReadOnly) ;\n" ;
  }

  $a = $i + 1 ; 
  if(isset($vaFields [$a])){
    $a = $vaFields [$a] ;
    if(!isset($va ['ckNewLine'.$a]) && isset($va ['cNama'.$a])){
      if(!empty($va ['cCaption'.$a])){
        $html = "            \$txt->Caption = \"{$va ['cCaption'.$a]}\" ;\n" . $html ;
      }
      $i ++ ;
      $html .= "\n" ;
      $html .= GetFieldValue($va,$i,$vaFields,$lPreview) ;
    }
  }
  return $html ;
}
?>