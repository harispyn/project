<?php
  include 'df.php' ;

  $cSave = "" ;
  $nLen = 0 ;
  foreach($vaFields as $key=>$n){
    if(trim($va ['cFieldName'.$n]) <> ""){
      if($cSave <> "") $cSave .= "," ;
      if(strlen($cSave) - $nLen >= 80){
        $cSave .= "\n                  " ;
        $nLen = strlen($cSave) ;
      }
      $cSave .= "\"" . $va['cFieldName'.$n] . "\"=>" ;
      $c = $va['cJenis'.$n] ;
      if($c == "text"){
        $cSave .= "\$" . $va['cNama'.$n] ;
      }else if($c == "number"){
        $cSave .= "String2Number(\$" . $va['cNama'.$n] . ")" ;
      }else if($c == "date"){
        $cSave .= "Date2String(\$" . $va['cNama'.$n] . ")" ;
      }  
    }
  }
   
  $cSource = "<?php\n" ;
  $cSource .= "  include 'df.php' ;\n" ;

  if($va ['optJenis'] == 1){
    $cSource .= "\n" ;
    $cSource .= "  if(!empty(\$cAction)){\n" ;
    $cSource .= "    if(\$cAction == \"Save\"){\n" ;
    $cSource .= "      \$va = array(" . $cSave . ") ;\n" ;
    $cSource .= "      \$objData->Update(\"" . $va['cNamaTable'] . "\",\$va,\"" . $cFieldKey  . " = '\$" . $cVariableKey . "'\") ;\n" ;
    $cSource .= "    }\n" ;
    $cSource .= "  }\n" ;
  }
  $cSource .= "?>" ;
?>