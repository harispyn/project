<?php
  include 'df.php' ;
  $n = $cName ;
  
  if(empty($cVar)) $cVar = "field_".$n ;
  if(empty($cField)) $cField = "field_".$n ;
  if(empty($cCaption)) $cCaption = "caption-".$n ;
  if(empty($nLength)) $nLength = 0 ;
  if(empty($nDecimal)) $nDecimal = 0 ;
  if(empty($cJenis)) $cJenis = "text" ;
?>
<table width="100%"  border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td width="40px" align="center" class="cell_row">
    <img src="./plugin/fw/images/fieldadd.gif" class="icons" title="Insert Below" onClick="InsertBelow('<?php echo($n) ?>')"><img src="./plugin/fw/images/fieldremove.gif" class="icons" title="Delete Row" onClick="DeleteRow('<?php echo($n) ?>')"><br>
    <img src="./plugin/fw/images/fIeld-next.gif" class="icons" title="Move Down" onClick="MoveRow('next','<?php echo($n) ?>')"><img src="./plugin/fw/images/field-prev.gif" class="icons" title="Move Up" onClick="MoveRow('prev','<?php echo($n) ?>')"><br>
    </td>
    <td width="150px" class="cell_row">
    <?php
      $txt->Style = "width:100%" ;
      $txt->Show("cCaption".$n,$cCaption) ;
    ?>
    </td>
    <td width="150px" class="cell_row">
    <?php
      $txt->Style = "width:100%" ;
      $txt->onBlur = "setMySQLField(document.form1.cNama" . $n . ",document.form1.cFieldName" . $n . ")" ;
      $txt->Show("cNama".$n,$cVar) ;
    ?>
    </td>
    <td width="70px" class="cell_row">
    <?php
      $txt->Style = "width:100%" ;
      $txt->onBlur = "SetMaxWidth('$n')" ;
      $txt->NumberField("nMaxLength".$n,$nLength) ;
    ?>
    </td>
    <td width="70px" class="cell_row">
    <?php
      $txt->Style = "width:100%" ;
      $txt->NumberField("nMaxWidth".$n,$nLength) ;
    ?>
    </td>
    <td width="130px" class="cell_row">
    <?php
      $txt->Style = "width:100%" ;
      $txt->onBlur = "SeekField(this);" ;
      $txt->Show("cFieldName".$n,$cField) ;
    ?>
    </td>
    <td class="cell_row" width="70px">
    <select style="width:100%;border:1px solid #7f9db9" name="cJenis<?php echo($n) ?>" onKeyUp="validate(this,event)">
      <?php
        $vaJ = array("text"=>"Text Box","date"=>"Date","number"=>"Number Box") ;
        foreach($vaJ as $key=>$value){
          $cSelected = "" ;
          if($cJenis == $key) $cSelected = " selected" ;
          echo("<option value='$key' $cSelected>$value</option>") ;
        }
      ?>
    </select>
    </td>
    <td width="40px" class="cell_row">
    <?php
      $txt->Style = "width:100%" ;
      $txt->NumberField("nDecimal".$n,$nDecimal) ;
    ?>
    </td>
    <td class="cell_row">
    <?php
      $txt->Caption = "New Line<br>" ;
      $txt->Checked = true ;
      $txt->CheckBox("ckNewLine".$n,"Y") ;
      
      $txt->Caption = "Button<br>" ;
      $txt->CheckBox("ckButton".$n,"Y") ;
      
      $txt->Caption = "Read Only<br>" ;
      $txt->CheckBox("ckReadOnly".$n,"Y") ;
    ?>
    </td>
  </tr>
</table>