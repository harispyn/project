<?php
  include 'df.php' ;
?>
<html>
<head>
</head>
<script language="javascript" type="text/javascript">
var nFieldRow = 0 ;
var ot = null ;
function NewField(nRow,cPar,lNoLoadRow){
  ot = document.getElementById("tb") ;
  if(!cPar) cPar = "" ;

  nFieldRow ++ ;
  cName = "r" + nFieldRow ;
  ot.insertRow(nRow) ;  
  ot.rows[nRow].name = cName ;
  ot.rows[nRow].insertCell(0) ;
  with(ot.rows[nRow].cells [0]){
    id = cName ;
    innerHTML = "" ;
  }
  if(!lNoLoadRow) loadpage("./plugin/fw/fw.fields.php"+cPar,cName,"cName="+cName) ;
  return ot.rows[nRow] ;
}

function InsertBelow(cName){
var nRow = ot.rows.length ;
  for(n=0;n<ot.rows.length;n++){
    if(ot.rows[n].name == cName) nRow = n+1 ;
  }

  NewField(nRow) ;
}

function GetRowByName(cName){
  nRow = null ;
  for(n=0;n<ot.rows.length;n++){
    if(ot.rows[n].name == cName) nRow = n ;
  }
  return nRow ;
}

function DeleteRow(cName){  
var nRow = null ;
  if(ot.rows.length > 1){
    nRow = GetRowByName(cName) ;
  }
  
  if(nRow == null){
    alert("Field Tidak Bisa di Hapus ....") ;
  }else{
    ot.deleteRow(nRow) ;
    setQuery() ;
  }
}

function setMySQLField(oF,oMySQL){
  oMySQL.value = oF.value.substring(1) ;
  setQuery() ;
}

function setQuery(){
  var of = self.parent.document.form1 ;
  var c = "" ;
  var cKey = "" ;
  with(document.form1){
    cFields.value = "" ;
    for(i=0;i<ot.rows.length;i++){
      n = ot.rows[i].name ;

      // Simpan Nama Field Ke Dalam Variable cFields
      if(cFields.value !== "") cFields.value += "~" ;
      cFields.value += n ;
      
      if(elements['cFieldName'+n].value !== ""){
        if(cKey == "") cKey = n ;
        if(c !== "") c += "," ;
        c += elements['cFieldName'+n].value ;
      }
    }
    if(c == "") c = "*" ;
    of.cGridQuery.value = "SELECT " + c + " FROM " + of.cNamaTable.value + " ORDER BY " + elements['cFieldName'+cKey].value ;
  }
}

function SetMaxWidth(n){
  with(document.form1){
    if(elements['nMaxWidth'+n].value == "0"){
      elements['nMaxWidth'+n].value = elements['nMaxLength'+n].value ;
    }
  }
}

function SeekField(field){
var f = self.parent.document.form1 ;
  ajax('./plugin/fw/fw.ajax.php','SeekField()','cFieldName='+field.name+'&cFieldValue='+field.value+'&cDatabase='+f.cDatabase.value+'&cTable='+f.cNamaTable.value) ;
}

function MoveRow(par,cName){
var nRow = GetRowByName(cName) ;
var cOld = document.getElementById(cName).innerHTML ;
var vaData = []
var f = document.form1 ;
  
  vaData [0] = f.elements['cCaption'+cName].value ;
  vaData [1] = f.elements['cNama'+cName].value ;
  vaData [2] = f.elements['nMaxLength'+cName].value ;
  vaData [3] = f.elements['nMaxWidth'+cName].value ;
  vaData [4] = f.elements['cFieldName'+cName].value ;
  vaData [5] = f.elements['cJenis'+cName].value ;
  vaData [6] = f.elements['nDecimal'+cName].value ;
  vaData [7] = f.elements['ckNewLine'+cName].checked ;
  vaData [8] = f.elements['ckButton'+cName].checked ;
  vaData [9] = f.elements['ckReadOnly'+cName].checked ;
  
  if((par == "prev" && nRow == 0) || (par == "next" && nRow == ot.rows.length-1)){
    alert("Field Tidak Bisa Dipinah ....!") ;
    return false ;
  }
  DeleteRow(cName) ;
  if(par == "next"){
    nNew = nRow + 1 ;
  }else{
    nNew = nRow - 1 ;
  }
  oNewRow = NewField(nNew,'',true) ;
  cNewName = oNewRow.name ;
  var oNew = document.getElementById(cNewName) ;
  oNew.innerHTML = cOld ;
  oNewRow.name = cName ;
  oNew.id = cName ;
  
  f.elements['cCaption'+cName].value = vaData [0] ;
  f.elements['cNama'+cName].value = vaData [1] ;
  f.elements['nMaxLength'+cName].value = vaData [2] ;
  f.elements['nMaxWidth'+cName].value = vaData [3] ;
  f.elements['cFieldName'+cName].value = vaData [4] ;
  f.elements['cJenis'+cName].value = vaData [5] ;
  f.elements['nDecimal'+cName].value = vaData [6] ;
  f.elements['ckNewLine'+cName].checked = vaData [7] ;
  f.elements['ckButton'+cName].checked = vaData [8] ;
  f.elements['ckReadOnly'+cName].checked = vaData [9] ;
  setQuery() ;
}
</script>
<style type="text/css">
  .cell_row {background-color:#d9d9d9;vertical-align:top}

  .icons {padding:2px;border:0} 
  .icons:hover {padding:1px;border:1px solid #000080;background-color:#ffd397}
</style>
<body onLoad="NewField(0)">
<form name="form1">
<table width="100%"  border="0" cellspacing="0" cellpadding="0" id="tb">
</table>
<?php
  $txt->HiddenField("cFields","") ;
?>
</form>
</body>
</html>