<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/fw/fw.php',false) . "','FrmFormWizart','Form Wizart',window.innerWidth-40,window.innerHeight-40,'',true); return false" ;
?>