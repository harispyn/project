<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function cmdSave_onClick(field){
var o1 = self.parent.document.getElementById("field-edit").contentWindow ;
  if(confirm("Data Disimpan ?")){
    var lFirst = true ;
    var nAdd = 0 ;
    for(n=0;n<DBGRID1.Rows();n++){
      if(DBGRID1.cellValue(n,0)){
        if(lFirst){
          InitGrid() ;
          lFirst = false ;
        }
        cPar = "&cCaption="+DBGRID1.cellValue(n,1)+"&cVar="+DBGRID1.cellValue(n,2)+"&cField="+DBGRID1.cellValue(n,3)+"&nLength="+DBGRID1.cellValue(n,5)+"&nDecimal="+DBGRID1.cellValue(n,6)+"&cJenis="+DBGRID1.cellValue(n,7) ;
        o1.NewField(nAdd,cPar) ; 
        nAdd ++ ;
      }
    }
    CloseForm() ;
  }
}

function InitGrid(){
var o = self.parent.document.getElementById("field-edit") ;
  ot = o.contentWindow.document.getElementById("tb") ;
  while(ot.rows.length > 0){
    ot.deleteRow(0) ;
  }
}
</script>