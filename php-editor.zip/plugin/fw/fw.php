<?php
  include 'df.php' ;
  include 'fw.db.php' ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include 'fw.jscript.php' ?>
<body>
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<table width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" style="padding:4px" class="cell_eventrow">
  <tr>
    <td colspan="4" class="sisbody" id="sistab-body" style="padding:5px" valign="top">
    <table width="100%" height="100%" border="0" cellspacing="0" cellpadding="1">
      <tr>
        <td width="150px" height="100px">Model Form</td>
        <td width="5px">:</td>
        <td valign="center">
        <table width="100%"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="25px">
            <?php
              $txt->Checked = true ;
              $txt->RadioButton("optJenis","1") ;
            ?>
            </td>
            <td width="20px"><img src="./plugin/fw/images/form1.gif" height="100px"></td>
            <td width="25px">
            <?php
              $txt->RadioButton("optJenis","2") ;
            ?>
            </td>
            <td><img src="./plugin/fw/images/form2.gif" height="100px"></td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td height="15px">Database</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Button = true ;
          $txt->Caption = "Table : " ;
          $txt->Show("cDatabase","",0,30) ;

          $txt->Button = true ;
          $txt->Show("cNamaTable","",0,30) ;
          
          $txt->ButtonField("cmdLoadField","Load Fields") ;
        ?>
        </td>
      </tr>
      <tr>
        <td height="15px">Judul Grid</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Style="width:100%" ;
          $txt->Show("cJudulGrid","") ;
        ?>
        </td>
      </tr>
      <tr>
        <td height="15px">Grid SQL</td>
        <td width="5px">:</td>
        <td>
        <?php
          $txt->Style="width:100%" ;
          $txt->Show("cGridQuery","SELECT * FROM table") ;
        ?>
        </td>
      </tr>
      <tr><td colspan="3" height="5px"></td></tr>
      <tr>
        <td colspan="3" style="background-color:666666" height="20px">
          <table width="100%"  border="0" cellspacing="1" cellpadding="1">
            <tr>
              <td width="40px" align="center" style="color:#ffffff" height="18px">Act</td>
              <td width="150px" align="center" style="color:#ffffff" height="18px">Caption</td>
              <td width="150px" align="center" style="color:#ffffff">Field Name</td>
              <td width="70px" align="center" style="color:#ffffff">M.Length</td>
              <td width="70px" align="center" style="color:#ffffff">M.Width</td>
              <td width="130px" align="center" style="color:#ffffff">Field MySQL</td>
              <td width="70px" align="center" style="color:#ffffff">Type</td>
              <td width="40px" align="center" style="color:#ffffff">Dec.</td>
              <td align="center" style="color:#ffffff">Option</td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td colspan="3" style="border:1px solid #d9d9d9"><iframe id="field-edit" height="100%" width="100%" style="border:0px"></iframe></td>
      </tr>
      <tr><td colspan="3" height="5px"></td></tr>
      <tr>
        <td height="15px">File Name</td>
        <td>:</td>
        <td>
        <?php
          $txt->Button = true ;
          $txt->Style = "width:90%" ;
          $txt->onKeyDown = "return false;" ;
          $txt->onKeyPress = "return false;" ;
          $txt->Show("cFileName","") ;
        ?>
        </td>
      </tr>
    </table>
    </td>
  </tr>
  <tr><td height="4px"></td></tr>
  <tr>
    <td colspan="4" height="20px" align="right" style="padding:5px;border:1px solid #999999">
    <?php
      $txt->HiddenField("cDir") ;
      $txt->HiddenField("cFile") ;
      
      $txt->ButtonField("cmdPreview","Preview") ;
      
      $txt->ButtonField("cmdSave","Save") ;
      
      $txt->onClick = "CloseForm()" ;
      $txt->ButtonField("cmdClose","Close") ;
    ?>
    </td>
  </tr>
</table>
</form>
</body>
</html>