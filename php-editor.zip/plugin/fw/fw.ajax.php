<?php
  include 'df.php' ;
  
function CreateFormWizart($va){
  if(ValidSaving($va)){
    $cTmpDir = CreateTmpDir() ;
    $vaFields = split("~",$va ['cFields']) ;
    $cVariableKey = $va ['cNama'.$vaFields[0]] ;
    $cFieldKey = $va ['cFieldName'.$vaFields[0]] ;
    $lPreview = false ;

    // Buat File PHP
    include 'fw.c-p.php' ;
    $cFileTmp = $cTmpDir . '/' . $va ['cFile'] . '.php' ;
    SaveTmp($cFileTmp,$cSource) ;  
    SaveSetting("tmp-" . $va['cDir'] . '/' . $va['cFile'] . '.php',$cFileTmp) ;
  
    // Buat File jscript
    include 'fw.c-j.php' ;
    $cFileTmp = $cTmpDir . '/' . $va ['cFile'] . '.jscript.php' ;
    SaveTmp($cFileTmp,$cSource) ;  
    SaveSetting("tmp-" . $va['cDir'] . '/' . $va['cFile'] . '.jscript.php',$cFileTmp) ;
  
    // Buat File Ajax
    include 'fw.c-a.php' ;
    $cFileTmp = $cTmpDir . '/' . $va ['cFile'] . '.ajax.php' ;
    SaveTmp($cFileTmp,$cSource) ;  
    SaveSetting("tmp-" . $va['cDir'] . '/' . $va['cFile'] . '.ajax.php',$cFileTmp) ;
  
    // Buat File db
    include 'fw.c-d.php' ;
    $cFileTmp = $cTmpDir . '/' . $va ['cFile'] . '.db.php' ;
    SaveTmp($cFileTmp,$cSource) ;  
    SaveSetting("tmp-" . $va['cDir'] . '/' . $va['cFile'] . '.db.php',$cFileTmp) ;
  
    echo('CreateFormWizart();') ;
  }
}

function ValidSaving($va){
  $cError = "" ;
  if(empty($va['cFileName'])){
    $cError = "Nama File Tidak Boleh Kosong .....!" ;
  }
  if($cError !== ""){
    echo('alert("' . $cError . '") ;') ;
    return false ;
  }else{
    return true ;
  }
}

function SaveTmp($cFileTmp,$cSource){
  $handle = fopen($cFileTmp, "w");
  fwrite($handle,$cSource) ;
  fclose($handle) ;      
  chmod($cFileTmp,0766) ;
}

function SeekDatabase($va){
  $dbData = mysql_query("Show Databases like '{$va['cDatabase']}'") ;
  if(mysql_num_rows($dbData) == 0){
    echo('
      alert("Database Tidak Ditemukan ......") ;
      document.form1.cDatabase.value = "" ;
    ') ;
  }
}

function SeekField($va){
  if(!empty($va ['cFieldValue'])){
    $dbData = mysql_query("SHOW FIELDS from {$va ['cDatabase']}.{$va ['cTable']} Like '{$va['cFieldValue']}'") ;
    $cError = mysql_error() ;
    if(!empty($cError) || mysql_num_rows($dbData) == 0){
      echo("
        alert('Field Tidak Ditemukan ....') ;
        document.form1.{$va['cFieldName']}.value = '' ;
      ") ;
    }
  }
}

function FormPreview($va){
  $va['cFileName'] = "test-preview" ;
  if(ValidSaving($va)){
    $cTmpDir = CreateTmpDir() ;
    $vaFields = split("~",$va ['cFields']) ;
    $cVariableKey = $va ['cNama'.$vaFields[0]] ;
    $cFieldKey = $va ['cFieldName'.$vaFields[0]] ;
    $lPreview = true ;

    // Buat File PHP
    include 'fw.c-p.php' ;
    $cFileTmp = $cTmpDir . '/' . $va ['cFile'] . '.php' ;
    SaveTmp($cFileTmp,$cSource) ;  
    SaveSetting("tmp-" . $va['cDir'] . '/' . $va['cFile'] . '.php',$cFileTmp) ;

    echo('
      OpenForm("main.php?__par=' . $cFileTmp . '","FrmTestPreview","Preview",window.innerWidth-40,window.innerHeight-20,"",true,"yes") ;
    ') ;
  }
}
?>