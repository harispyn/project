<?php include 'df.php' ; ?>
<script language="javascript" type="text/javascript">
function GetDirNew(){
  var o = document.getElementById("frmDir") ;
  o.src = "main.php?__par=plugin/fw/frmsave.dir.php" ;
}

function cmdSave_onClick(field){
  var lValid = true ;
  with(document.form1){
    if(cFileName.value == ""){
      lValid = false ;
      alert("Nama File Tidak Boleh Kosong ....") ;
    }
    
    if(cDirectory.value == ""){
      lValid = false ;
      alert("Directory Tidak Boleh Kosong ....") ;
    }
  }
  
  if(lValid){
    with(self.parent.document.form1){
      cDir.value = document.form1.cDirectory.value ;
      cFile.value = document.form1.cFileName.value ;
      cFileName.value = cDir.value + '/' + cFile.value ;
      fieldfocus(cFileName) ;
    }
    CloseForm() ;
  }
}
</script>