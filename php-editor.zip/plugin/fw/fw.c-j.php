<?php
  include 'df.php' ;
  
  $cSource = "<script language=\"javascript\" type=\"text/javascript\">\n" ;
  
  $cSource .= "function Form_onLoad(){\n" ;
  $cSource .= "  getEdit(false) ;\n" ;
  $cSource .= "}\n\n" ;

  // Function Init Value
  $cSource .= "function initValue(){\n" ;
  $cSource .= "  with(document.form1){\n" ;
  foreach($vaFields as $key=>$n){
    $cVal = "" ;
    $c = $va['cJenis'.$n] ;
    if($c == "number"){
      $cVal = "0" ;
      if($va ['nDecimal' . $n] > 0){
        $cVal .= str_pad(".",$va ['nDecimal'.$n]+1,"0",STR_PAD_RIGHT) ;
      }
    }else if($c == "date"){
      $cVal = "<?php echo(date(\"d-m-Y\")) ?>" ;
    }
    $cSource .= "    " . $va['cNama'.$n] . ".value = \"$cVal\" ;\n" ;
  }
  $cSource .= "  }\n" ;
  $cSource .= "}\n\n" ;

  $cSource .= "var lEdit = false ;\n" ;
  $cSource .= "function getEdit(lPar,nAction){\n" ;
  $cSource .= "  lEdit = lPar ;\n" ;
  $cSource .= "  setupComponent(document.form1,lPar) ;\n" ;
  $cSource .= "  document.form1.nPos.value = nAction ; \n" ;
  $cSource .= "  if(lPar){\n" ;
  $cSource .= "    fieldfocus(document.form1.$cVariableKey) ;\n" ;
  $cSource .= "  }\n" ;
  $cSource .= "  initValue() ;\n" ;
  $cSource .= "  fieldfocus(document.form1.$cVariableKey) ;\n" ;
  $cSource .= "}\n\n" ;
  
  $cSource .= "function cmdSave_onClick(field){\n" ;
  $cSource .= "  if(confirm(\"Data Disimpan ?\")){\n" ;
  $cSource .= "    ajax('','ValidSaving()',GetFormContent()) ;\n" ;
  $cSource .= "  }\n" ;
  $cSource .= "}\n\n" ;

  if($va ['optJenis'] == 1){
    $cSource .= "function SaveAll(){\n" ;
    $cSource .= "  with(document.form1){\n" ;
    $cSource .= "    cAction.value = \"Save\" ;\n" ;
    $cSource .= "    submit() ;\n" ;
    $cSource .= "  }\n" ;
    $cSource .= "}\n\n" ;
  }

  $cSource .= "function ConfirmDelete(){\n" ;
  $cSource .= "  if(confirm(\"Data Benar-benar Dihapus ?\")){\n" ;
  $cSource .= "    ajax('','DeleteData()',GetFormContent()) ;\n" ;
  $cSource .= "  }\n" ;
  $cSource .= "}\n\n" ;

  $cSource .= "function " . $cVariableKey . "_onBlur(field){\n" ;
  $cSource .= "  ajax('','SeekKode()',GetFormContent()) ;\n" ;
  $cSource .= "}\n\n" ;

  $cSource .= "function cmdCancel_onClick(field){\n" ;
  $cSource .= "  if(lEdit){\n" ;
  $cSource .= "    getEdit(false) ;\n" ;
  $cSource .= "  }else{\n" ;
  $cSource .= "    CloseForm() ;\n" ;
  $cSource .= "  }\n" ;
  $cSource .= "}\n" ;
  $cSource .= "</script>" ;
?>