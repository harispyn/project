<?php
  include 'df.php' ;
  include GetFileModul(__FILE__,'.db.php') ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Assistindo.Net</title>
</head>
<?php include GetFileModul(__FILE__,'.jscript.php') ?>
<body>
<form name="form1" method="post" action="<?php echo($_SERVER['PHP_SELF'] . '?__par=' . getlink($__par,false)) ?>">
<table width="100%" height="100%" border="0" cellspacing="3" cellpadding="0" class="cell_eventrow">
  <tr>
    <td style="border:1px solid #999999;padding:4px">
      <table width="100%" height="100%" border="0" cellspacing="0" cellpadding="1">
        <tr>
          <td>
          <?php
            $dbData = mysql_query("show fields from $cDatabase.$cTable") ;
            while($dbRow = mysql_fetch_array($dbData)){
              $cKey = $dbRow ['Field'] ;
              $vaType = split("\(",$dbRow ['Type']) ;
              $c = strtolower($vaType [0]) ;
              $vaDec = array(0,0) ;
              if(isset($vaType [1])){
                $vaType [1] = str_replace(")","",$vaType [1]) ;
                $vaDec = split(",",$vaType [1]) ;
                if(!isset($vaDec [1])) $vaDec [1] = 0 ;
              }

              $cVariable = "c" ;
              $cJenis = "text" ;
              if($c == "date" || $c == "datetime"){
                $cVariable = "d" ;
                $cJenis = "date" ;
              }else if($c == "double" || $c == "int" || $c == "bigint" || $c == "decimal" || $c == "float"){
                $cVariable = "n" ;
                $cJenis = "number" ;
              }
              $cVariable .= $dbRow ['Field'] ;
              $vaArray [$cKey] = array("Y"=>0,"Caption"=>$dbRow ['Field'],"Variable"=>$cVariable,"Field"=>$dbRow ['Field'],"Type"=>$dbRow ['Type'],"Length"=>$vaDec [0],"Dec"=>$vaDec [1],"Jenis"=>$cJenis) ;
            }
            
            if(!empty($vaArray)){
              $dbg->Array = $vaArray ;
              $dbg->Col ['Y'] = array("Type"=>"checkbox","Width"=>20,"Align"=>"center") ;
              $dbg->Col ['Caption'] = array("Width"=>200,"Edit"=>true) ;
              $dbg->Col ['Variable'] = array("Width"=>200,"Edit"=>true) ;
              $dbg->Col ['Field'] = array("Width"=>130) ;
              $dbg->Col ['Length'] = array("Width"=>50,"Align"=>"right") ;
              $dbg->Col ['Dec'] = array("Width"=>50,"Align"=>"right") ;
              $dbg->Col ['Jenis'] = array("Width"=>50,"Align"=>"center") ;
              $dbg->Scrolling = "vertical" ;
              $dbg->Height = "100%" ;
              $dbg->dataBind() ;
            }
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height="20px" style="border:1px solid #999999">
      <table width="100%" style="padding:2px">
        <tr>
          <td align="right">
          <?php
            $txt->ButtonField("cmdSave","Save") ;

            $txt->onClick = "CloseForm() ;" ;
            $txt->ButtonField("cmdCancel","Cancel") ;
          ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>

</form>
</body>
</html>
