<?php
  $cPlugAction = ";;" ;
  $cOnClick = "javascript: OpenForm('main.php?__par=" . getlink('./plugin/button/button.php',false) . "','FrmInsertCheckBox','Insert Check Box / Radio Button',400,140,'',true); return false" ;
?>