<?php
  include 'df.php' ;
?>

// File = /prg.web/master/mstregisternasabah.php
GetSetting("CurrFile_Name") = mstregisternasabah
GetSetting("CurrFile_Directory") = /prg.web/master
GetSetting("CurrFile_FullName") = /prg.web/master/mstregisternasabah
GetSetting("CurrFile_Ext") = .php
GetSetting($cFullName . "ext") // Extention yang aktif untuk masing-masing File
GetSetting("TabExtIndex") // Posisi Tab Untuk Extention
GetSetting("TabFileIndex") // Posisi Tab File
GetSetting("cSession_DevProject") // Nama Project
GetSetting("cFileAktive")  // File Yang Aktif ini di gunakan untuk cek kalau sama dengan CurrFile_FullName berarti Tab tidak usah di Update