<?php
  if(GetSetting("cLogin") == "0"){
    direc("./logout.php") ;
  }

  include 'df.php' ;
  include 'project_edit.db.php' ;
  $cEditor = $_SERVER['PHP_SELF'] ;
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title><?php echo($cEditor) ?></title>
</head>
<?php include 'project_edit.jscript.php' ?>
<body onLoad="<?php echo($cLoad) ?>" onbeforeunload="return validclose(event);" marginheight="1" marginwidth="1" onScroll="SetScroll()" style="overflow-x: hidden;overflow-y: hidden;">
<form name="form1" method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
  <tr>
    <td class="cell_blue">
      <table width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="16" valign="middle" class="cell_blue">
          <table width="100%"  border="0" cellspacing="1" cellpadding="0">
            <tr>
              <td class="cell_oddrow">
              <table width="100%"  border="0" cellspacing="1" cellpadding="0">
              <?
                ShowIcons($vaIcon) ;              
                echo('
                  <tr>
                    <td height="24" background="./images/menu-back.gif">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td><div id="ExtShow"></div></td>
                        <td align="right"></td>
                      </tr>
                    </table>
                    </td>
                  </tr>
                ') ;
              ?>
              </table>
              </td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td height="24px" valign="middle" class="cell_white">
          <table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td id="Tab-Show"></td>
              <td></td>
              <td width="14px" id="Tab-Close">&nbsp;</td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td height="1px"></td>
        </tr>    
        <tr>
          <td class="cell_white" valign="top">
          <table width="100%"  border="0" cellspacing="0" cellpadding="0" height="100%">
            <tr>
              <td width="1px" class="cell_blue"></td>
              <td>
              <table width="100%"  border="0" cellspacing="0" cellpadding="2" height="100%">
                <tr>
                  <td width="25px" bgcolor="#3168D5"><iframe width="25px" height="100%" scrolling="no" style="border:0px;padding-right:1px" src="main.php?__par=<?php getlink('project_edit_line.php') ?>" id="ifmRows"></iframe></td>
                  <td align="center" valign="center">
                  <?php
                    if(trim(GetSetting("cSession_FileOpen")) !== ""){
                      echo('<iframe height="100%" scrolling="yes" width="100%" src="main.php?__par=' . getlink('./project_edit_area.php',false) . '" style="border-width:0px" id="Editor"></iframe>') ;
                    }else{
                      echo('<div style="background-color:#d6e7fc;height:100%; vertical-align:middle "><br><br><br><br><br><br><br><br><br><br><strong>PHP Editor</strong><br>Version : ' . GetVersion() . '<br>Copyright&copy; 2006 - ' . date("Y") . ' M.A.R.S Technology, All rights Reserved</div>') ;
                    }
                  ?>
                  </td>
                </tr>
              </table>
              </td>
              <td width="1px" class="cell_blue"></td>
            </tr>
          </table>
          </td>
        </tr>
        <tr>
          <td height="1px" class="cell_blue"></td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td height="16px" bgcolor="#000000">
      <table width="100%"  border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td style="font-size:10px; color:#FFFFFF ">&nbsp;&nbsp;Project : <span id="Project_Name"></span></td>
          <td style="font-size:10px; color:#FFFFFF " align="right" width="150px">Version : <?php echo(GetVersion()) ?>&nbsp;&nbsp;</td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
  <?php
    $txt->HiddenField("cSource","") ;
  ?>
<div id="ShowProsess" style="width: auto;display: none;position: absolute; background-color:#990033;left: 0px; top: 0px; border-width:1px; padding:3px 5px 3px 5px; color:#FFFFFF;font-size:11px;vertical-align:middle"></div>
<div id="frmReadOnly" style="width: auto;display: none;position: absolute; background-color:#990033;left: 0px; top: 0px; border-width:1px; padding:3px 5px 3px 5px; color:#FFFFFF;font-size:11px;vertical-align:middle"></div>
<div id="objTextWidth" style="width: auto;display: none;position: absolute;left: 0px; top: 0px"></div>
</form>
</body>
</html>