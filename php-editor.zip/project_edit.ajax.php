<?php
include 'df.php' ;

function GetPos($va){
  $cValue = GetSetting(GetPosKey(),'') ;
  $va = split("::",$cValue) ;
  if(count($va) < 4){
    $va = array(0,0,0,0) ;
  }
  echo('
       var oe = document.getElementById("Editor") ;
       if(oe !== null){
        oe.contentDocument.form1.cSource.selectionStart = ' . $va [0] . ' ;
        oe.contentDocument.form1.cSource.selectionEnd = ' . $va [1] . ' ;
        oe.contentWindow.scrollTo(' . $va [2] . ',' . $va [3] . ') ;
       }
       ') ;
  SaveHistory("O") ;
}

function SavePos($va){
  SaveSetting(GetPosKey(),$va['cPosValue']) ;
  SaveHistory("C") ;
  SaveSetting("cFindText",$va ['cFindText']) ;
  if(!empty($va ['cFuncNext'])){
    echo($va ['cFuncNext'] . ";") ;
  }
}

function GetPosKey(){
  return GetSetting("CurrFile_FullName") . GetSetting("CurrFile_Ext") ;
}

function Preview($va){
  $vaDir = split("/",str_replace(GetSetting("Project_Dir") . "/","",GetSetting("CurrFile_Directory"))) ;
  $cProject = $vaDir [0] ;
  $cURL = GetSetting("Project_Dir") . '/' . $cProject ;
  $cName = md5($cURL . rand(0,1000)) ;
  echo('window.open("' . $cURL . '","'. $cName . '");') ;
}

function SavePHP($va){
  $cDan = strtolower("{DAN}") ;
  $cPlus = strtolower("{PLUS}") ;

  $cSource = $va ['cSource'] ;
  $cFileName = GetSetting("CurrFile_Name") . GetSetting("CurrFile_Ext") ;
  $cDirectory = GetSetting("CurrFile_Directory") ;

  $cSource = str_replace($cDan,"&",$cSource) ;
  $cSource = str_replace($cPlus,"+",$cSource) ;
  $cSource = str_replace("\'","'",$cSource) ;
  $cSource = str_replace('\"','"',$cSource) ;
  $cSource = str_replace("\\\\",trim("\ "),$cSource) ;
  $cFile = $cDirectory . '/' . $cFileName ;
  SaveHistory() ;
  if(is_file($cFile)){
    unlink($cFile) ;        
  }
  $handle = fopen($cFile, "w");
  fwrite($handle,$cSource) ;
  fclose($handle) ;      
  chmod($cFile,0766) ;
  
  echo('
        UpdEditStatus(false) ;
        HideProgress() ;
        ') ;
}

function ShowTabExtention($va){
  // Kalau Pindah Tab File
  if(isset($va ['cFile'])){
    $_va = pathinfo($va ['cFile']) ;
    SaveSetting("CurrFile_Name",$_va['basename']) ;
    SaveSetting("CurrFile_Directory",$_va['dirname']) ;
    SaveSetting("CurrFile_FullName",$va ['cFile']) ;
    SaveSetting("CurrFile_Ext",GetSetting($va ['cFile'] . "ext")) ;
  }

  // Kalau Pindah Tab Extention
  if(isset($va ['cExt'])){
    SaveSetting("CurrFile_Ext",$va['cExt']) ;
  }

  $vaFile = GetFile() ;
  ShowTab($vaFile) ;
  $cCurFile = GetSetting("CurrFile_Name") ;
  $cCurDir = GetSetting("CurrFile_Directory") ;
  $vaProject = split("/",str_replace(GetSetting("Project_Dir") . '/',"",$cCurDir)) ;
  $cProject = $vaProject [0] ;
  SaveSetting("cSession_DevProject",$cProject) ;
  $vaExt = $vaFile [$cCurDir . '/' . $cCurFile]['ext'] ;
  $cFullName = GetSetting("CurrFile_FullName") ;
  $cExt = GetSetting("CurrFile_Ext") ;  
  if(count($vaExt) >= 1){
    $__cExtShow = "" ;
    asort($vaExt) ;
    $nCount = 0 ;
    $lFound = false ;
    foreach($vaExt as $key=>$value){
      $nCount ++ ;
      $cSelected = "" ;
      $cLink = '<a href=";;" onClick=\"javascript:return LoadFile(&quot;' . $value . '&quot;)\" Title="' . str_replace(GetSetting("Project_Dir").'/',"",$cFullName . $value) . '"  class="styleTabLink">' ;
      $cLink1 = '</a>' ;
      $cCloseTab = '<a href=";;" onClick="javascript:return CloseExt(&quot;' . $cFullName . $value . '&quot;)" style="cursor:default" title="Close Tab" class="styleCloseExt">[x]</a>' ;
      if((!$lFound && $nCount == count($vaExt)) || empty($cExt)){
        SaveSetting("CurrFile_Ext",$value) ;
        $cExt = $value ;
      }
      if($value == $cExt){
        SaveSetting("TabExtIndex",$nCount-1) ;
        $lFound = true ;
        $cSelected = "-Selected" ;
        $cLink = "" ;
        $cLink1 = "" ;                        
      }
      $nLen = strlen($value) - 4 ;
      $__c = $value ;
      if($value !== ".php" && substr($value,$nLen) == ".php"){
        $__c = substr($value,0,$nLen) ;
      }
      $__cExtShow .= '<td><span class="styleTabExt' . $cSelected . '">' . $cLink . $__c . $cLink1 . '&nbsp;' . $cCloseTab . '&nbsp;</span></td>' ;
    }
    if(!empty($__cExtShow)){
      $__cExtShow = '<table border="0" cellspacing="0" cellpadding="0" style="padding-left:1px;padding-bottom:1px"><tr>' . $__cExtShow . '</tr></table>' ;
    }
    echo("
          var _o = document.getElementById('ExtShow') ;
          if(_o !== null){
            _o.innerHTML = '" . $__cExtShow . "' ;
          }
          HideProgress() ;
         ") ;
    $va['Edit'] = $cCurFile . $cExt ;
    LoadFile($va) ;    
  }
  echo('HideProgress() ;') ;
  SaveSetting($cFullName . "active",$cFullName . $cExt) ;
  SaveSetting($cFullName . "ext",$cExt) ;
}

function ShowTab($vaFileOpen){
  $cTabShow = '' ;
  $cFullName = GetSetting("CurrFile_FullName") ;
  if(GetSetting("cFileAktive") == $cFullName){
    return true ;
  }
  SaveSetting("cFileAktive",$cFullName) ;
  
  if(!empty($vaFileOpen)){
    $nTab = 0 ;
    foreach($vaFileOpen as $key=>$value){
      if(!empty($value)){
        $cFilePos = $value ['filename'] ;
        $cDirPos = $value ['dirname'] ;
        $cLink = '<a href=";;" onClick=\"javascript:return LoadFile(&quot;&quot;,&quot;' . $cDirPos . '/' . $cFilePos . '&quot;)\" Title="' . str_replace(GetSetting("Project_Dir").'/',"",$value['dirname'].'/'.$value['filename']) . '"  class="styleTabLink">' ;
        $cLink1 = '</a>' ;
        $cSelected = "styleTabFile" ;
        $cID = "" ;        
        if(GetSetting("CurrFile_FullName") == $cDirPos . '/' . $cFilePos ){
          $cID = 'id="TabEdit"' ;
          $cSelected = "styleTabExt-Selected" ;
          $cLink = "" ;
          $cLink1 = "" ;
          SaveSetting("TabFileIndex",$nTab) ;            
        }
        $nTab ++ ;
        $cTabShow .= '<span class="' . $cSelected . '"' . $cID . '>' . $cLink . $value['filename'] . $cLink1 . '</span>' ;
      }
    }
    $cCloseFile = '<a href=";;" onClick="javascript:return CloseExt(&quot;' . GetSetting("CurrFile_FullName") . '&quot;)" style="cursor:default" title="Close Tab" class="styleCloseExt"><img src="./images/close-file.gif" width="12" height="12" border="1" class="styleIconsClose"></a>' ;
  }
  echo("
      var ot = document.getElementById('Tab-Show') ;
      if(ot !== null){
        ot.innerHTML = '" . $cTabShow . "' ;
      }
      var oc = document.getElementById('Tab-Close') ;
      if(oc !== null){
        oc.innerHTML = '" . $cCloseFile . "' ;
      }
       ") ;
}

function LoadFile($va){
  echo('HideProgress("frmReadOnly");') ;
  $cOldBookmarkFile = GetSetting("cOldBookmarkFile","") ;
  if(!empty($cOldBookmarkFile)){
    UpdateBookmarkAll(false,$cOldBookmarkFile) ;
  }   
  $c = "Bookmark-" . GetSetting("CurrFile_FullName") . GetSetting("CurrFile_Ext") ;
  SaveSetting("cOldBookmarkFile",$c) ;
  UpdateBookmarkAll(true) ;
  
  $cEdit = $va["Edit"] ;
  $cDirectory = GetSetting("CurrFile_Directory") ;
  $nMaxRows = 20 ;
  $cTmpFile = GetSetting("tmp-" . $cDirectory . '/' . $cEdit,'') ;
  if(!empty($cEdit) && (is_file($cDirectory . '/' . $cEdit) || is_file($cTmpFile))){
    $_cFile = $cDirectory . '/' . $cEdit ;
    if(!is_file($_cFile)){
      $_cFile = $cTmpFile ;
    }
    
    $vaLines = file($_cFile) ;
    $nMaxRows = count($vaLines) ;
    $cSource = join($vaLines,'') ;
    $nOldMaxRow = max(GetSetting("MaxRow",1000),$nMaxRows) ;
    SaveSetting("MaxRow",$nOldMaxRow) ;
  }else{
    $cExtention = GetSetting("CurrFile_Ext") ;
    $cSource = "" ;
    if($cExtention == ".php"){
      $cSource = "<?php\n" ;
      $cSource .= "  include 'df.php' ;\n" ;
      $cSource .= "  include GetFileModul(__FILE__,'.db.php') ;\n" ;
      $cSource .= "?>\n" ;
      $cSource .= "<html>\n" ;
      $cSource .= "<head>\n" ;
      $cSource .= "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">\n" ;
      $cSource .= "<title>Assistindo.Net</title>\n" ;
      $cSource .= "</head>\n" ;
      $cSource .= "<?php include GetFileModul(__FILE__,'.jscript.php') ?>\n" ;
      $cSource .= "<body>\n" ;
      $cSource .= "<form name=\"form1\" method=\"post\" action=\"<?php echo(\$_SERVER['PHP_SELF'] . '?__par=' . getlink(\$__par,false)) ?>\">\n\n" ;
      $cSource .= "</form>\n" ;
      $cSource .= "</body>\n" ;
      $cSource .= "</html>\n" ;
    }else if($cExtention == ".jscript" || $cExtention == ".jscript.php"){
      $cSource .= "<?php include 'df.php' ; ?>\n" ;
      $cSource .= "<script language=\"javascript\" type=\"text/javascript\">\n\n" ;
      $cSource .= "</script>" ;
    }else{
      $cSource = "<?php\n" ;
      $cSource .= "  include 'df.php' ;\n" ;
      $cSource .= "?>" ;
    }
  }  

  $cSource = str_replace("&",strtolower("{DAN}"),$cSource) ;
  $cSource = str_replace("\\","\\\\",$cSource) ;
  $cSource = str_replace('"','\"',$cSource) ;
  $cSource = str_replace("\n","\\n",$cSource) ;
  $cSource = str_replace(chr(13),"",$cSource) ;
  $cSource = str_replace("'","\'",$cSource) ;
  $cSource = str_replace("$","\$",$cSource) ;
  $cReadOnly = "" ;
  $clReadOnly = "false" ;
  if(IsReadOnly()){
    $cReadOnly = str_replace(" ","&nbsp;","Read Only - Opened By : " . GetSetting("cUser_Locking")) ;
    $clReadOnly = "true" ;
  }
  echo("
       with(document.form1){
        cSource.value = '" . $cSource . "' ;
       }

       // Setting Title Editor
       var o2 = document.getElementById('Project_Name') ;
       if(o2 !== null) o2.innerHTML = '" . str_replace(GetSetting("Project_Dir") . '/','',GetSetting("CurrFile_FullName")) . GetSetting("CurrFile_Ext") . "' ;
       loadSource(" . $nMaxRows . ") ;
       
       var oe = document.getElementById('Editor') ;
       with(oe.contentDocument.form1){
         cSource.disabled = " . $clReadOnly . " ;
       }
       ") ;
  if(!empty($cReadOnly)) echo("ShowProgress('$cReadOnly','frmReadOnly') ;") ;
  GetPos($va) ;       
}

function CloseExt($va){
  SaveHistory("C") ;
  $cCloseFile = $va ['cCloseFile'] ;
  $_va = pathinfo($cCloseFile) ;
  $nPos = strpos($_va['basename'],".") ;
  $cDir = $_va['dirname'] ;
  if($nPos === false){
    $cFile = $_va['basename'] ;
  }else{
    $cFile = substr($_va ['basename'],0,$nPos) ;
  }  
  $va = split("~~",GetSetting("cSession_FileOpen")) ;  
  $nLen = strlen($cCloseFile) ;
  foreach($va as $key=>$value){
    if(substr($value,0,$nLen) == $cCloseFile || empty($value) && empty($value)){
      unset($va [$key]) ;
    }
  }
  $cc = join("~~",$va) ;
  if(empty($cc) || $cc == "~~"){
    $cc = "" ;
  }
  SaveSetting("cSession_FileOpen",$cc) ;

  if(empty($cc)){
    echo('
      with(document.form1){
        action = "./" ;
        submit() ;
      }
         ') ;
  }else{
    $vaFile = GetFile() ;

    // Jika Setelah Close File Tidak di temukan
    // Setting Untuk Tab Sebelumnya
    if(!isset($vaFile [$cDir . '/' . $cFile])){
      $nTab = min(count($vaFile)-1,GetSetting("TabFileIndex",1)) ;
      $nRow = 0 ;
      foreach($vaFile as $key=>$value){
        if($nRow == $nTab){
          SaveSetting("CurrFile_Name",$value ['filename']) ;
          SaveSetting("CurrFile_Directory",$value ['dirname']) ;
          SaveSetting("CurrFile_FullName",$value ['dirname'] . '/' . $value ['filename']) ;
          SaveSetting("CurrFile_Ext",GetSetting(GetSetting("CurrFile_FullName")."ext")) ;
        }
        $nRow ++ ;
      }
    }
    ShowTabExtention(array()) ;

    echo('
         HideProgress() ;
         ') ;
  }
}

function GetFile(){
  $va = split("~~",GetSetting("cSession_FileOpen")) ;
  $vaFile = array() ;
  if(!empty($va)){
    foreach($va as $key=>$value){
      if(!empty($value)){
        $_va = pathinfo($value) ;
        $nDot = strpos($_va['basename'],".") ;
        $cExt = substr($_va['basename'],$nDot) ;
        $cFile = substr($_va['basename'],0,$nDot) ;
        $cKey = $_va['dirname'] . '/' . $cFile ;
        $vaFile [$cKey]["dirname"] = $_va['dirname'] ;
        $vaFile [$cKey]["filename"] = $cFile ;
        $vaFile [$cKey]['ext'][$cExt] = $cExt ;
      }
    }
  }
  return $vaFile ;
}

function KeyBookmark(){
  return "Bookmark-" . GetSetting("CurrFile_FullName") . GetSetting("CurrFile_Ext") ;
}

function TogleBookmark($va){
  $nRow = $va ['nRow'] ;
  $cFileName = KeyBookmark() ;
  $cSearch = ";" . $nRow . ";" ;

  $cBookmark = GetSetting($cFileName,"") ;
  if(empty($cBookmark)) $cBookmark = ";" ;
  
  if( strpos($cBookmark,$cSearch) === false){
    $cBookmark .= $nRow . ";" ;
    $cUpdate = "true" ;
  }else{
    $cBookmark = str_replace($cSearch,";",$cBookmark) ;
    $cUpdate = "false" ;
  }
  SaveSetting($cFileName,$cBookmark) ;
  $cCheckBookmark = str_replace(";","",$cBookmark) ;
  $cDisableBookmark = "false" ;
  if($cCheckBookmark == "") $cDisableBookmark = "true" ;
  
  echo("UpdateBookmark($nRow,$cUpdate);EditFocus();") ;
  echo("DisableIcons('bookmark-next',$cDisableBookmark);DisableIcons('bookmark-prev',$cDisableBookmark);") ;
}

function NextBookmark($va){
  $nRow = $va['nRow'] ;
  $cBookmark = GetSetting(KeyBookmark()) ;
  if(!empty($cBookmark)){
    $vaBookmark = split(";",$cBookmark) ;
    $nNext = 0 ;
    foreach($vaBookmark as $key=>$value){
      $value = intval($value) ;
      if(!empty($value)){
        if($va ['cStatus'] == 'Next'){
          if($nRow < $value){
            if($nNext > 0){
              $nNext = min($value,$nNext) ;
            }else{
              $nNext = $value ;
            }
          }
        }else{
          if($nRow > $value){
            $nNext = max($value,$nNext) ;
          }
        }
      }
    }
    
    if($nNext > 0){
      echo('GotoRow(' . $nNext . ');') ;
    }else{
      echo('EditFocus();') ;
    }
  }
}
?>