<?php
  if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']),"gecko") === false){
    die("Program hanya bisa dijalankan menggunakan Browser Mozila Firefox") ;
  }
  if(!defined("main")){
    define("main",1) ;
  }
  include './include/database.php' ;
  SaveSetting("cSession_FileOpen","") ;
  if(isset($_GET['cUserName'])){
    $cUserName = $_GET['cUserName'] ;
    SaveSetting("cLogin",0) ;
  }
  if(isset($_GET['cBorder'])) SaveSetting("cWindowBorder",$_GET['cBorder']) ;
  if(GetSetting("cLogin") == 1){
    include './project_edit.php' ;
  }else{
    include 'login.php' ;
  }
?>