<?php
  include 'df.php' ;
  include './plugin/plugin.php' ;

  // Open File / New File
  if(!empty($cOpenDir) && !empty($cOpenFile)){
    SaveHistory("C") ;
    $cc = GetSetting("cSession_FileOpen") ;
    $vaOpenFile = split("`",$cOpenFile) ;
    $lFirst = true ;
    foreach($vaOpenFile as $key=>$value){
      if($lFirst){
        $nPos = strpos($value,".") ;
        $cFile = substr($value,0,$nPos) ;
        $cExt = substr($value,$nPos) ;
        SaveSetting("CurrFile_Directory",$cOpenDir) ;
        SaveSetting("CurrFile_Name",$cFile) ;
        SaveSetting("CurrFile_FullName",$cOpenDir . '/' . $cFile) ;
        SaveSetting("CurrFile_Ext",$cExt) ;
      }
      $lFirst = false ;
      $nPos = strpos($cc,$cOpenDir . '/' . $value) ;
      if($nPos === false){
        $cc .= "~~" . $cOpenDir . '/' . $value ;
      }
    }
    SaveSetting("cSession_FileOpen",$cc) ;    
  }
  $cLoad = "checkParent('" . GetSetting("optUserLock","N") . "');" ;
  if(trim(GetSetting("cSession_FileOpen")) !== ""){
    $cLoad .= "LoadFile('','');" ;
  }
  SaveSetting("cFileAktive","~~") ;

/**************************************************************************************************************************************************************************************************/
function ShowIcons($vaIcon){
  $lFirst = true ;
  $lAllIcons = true ;
  if(trim(GetSetting("cSession_FileOpen")) == ""){
    $lAllIcons = false ;
  }
  $vaIconShow = IncludeFile(GetSetting("nLevel","1")) ;
  foreach($vaIcon as $key=>$value){
    if($lFirst || $value == "break"){        
      echo('<tr><td valign="middle" background="./images/menu-back.gif" height="24px">') ;
    }
    $lFirst = false ;
              
    if(empty($value)){      
      echo('<img src="./plugin/sparator.gif" width="6px" height="22px" border="0">') ;
    }elseif($value !== "break"){
      $cLink = '<a href="' . $value ['Action'] . '" Title="' . $value ['Title'] . '" target="' . $value ['Target'] .  '" name="' . $value ['Name'] . '" onClick="javascript:return CheckIcons(\'' . $value ['Name'] . '\');">' ;
      $cLink1 = '</a>' ;
      $cClass = "styleIcons-Disable" ;
      $cOnClick = "" ;
      if($lAllIcons || $value['Name'] == 'project-list' || $value['Name'] == 'change-password' || $value ['Name'] == "open" || $value['Name'] == "menu-setup" || $value ['Name'] == "new" || $value ['Name'] == "setup" || $value ['Name'] == "unzip" || $value ['Name'] == "update" || $value ['Name'] == "close" || $value['Name'] == "user" || $value ['Name'] == "project-backup" || $value ['Name'] == "fw"){
        if(!empty($value ['OnClick'])){
          $cOnClick = ' onClick="if(CheckIcons(\'' . $value['Name'] . '\')){' . $value ['OnClick'] . '} return false" ' ;
        }
        
        if(is_file('./plugin/' . $value ['Name'] . '/' . $value ['Name'] . '.php') || !empty($value ['OnClick']) || $value ['Name'] == 'preview'){
          $cClass = "styleIcons" ;
        }       
      }
      if(($value['Name'] == "setup" || $value['Name'] == "menu-setup" || $value['Name'] == "user" || $value['Name'] == "update") && GetSetting("nLevel") <> 0){
        $cClass = "styleIcons-Disable" ;
      }
      $k = md5($value['Name']) ;
      if(!isset($vaIconShow[$k]) && GetSetting("nLevel") <> 0 && $value ['Name'] <> 'close'){
        $cClass = "styleIcons-Disable" ;
      }
      echo($cLink . '<img class="' . $cClass .'" src="' . $value ['src'] . '" ' . $cOnClick . ' width="20" height="20" border="0" id="icons_' . strtolower($value ['Name']) . '">' . $cLink1) ;
      if($value ['Name'] == "find"){
        echo('<input name="cFindText" value="' . GetSetting("cFindText","") . '" style="height:20px;margin:1px 2px 0px 2px;width:150px;border:1px solid #7f9db9" onKeyDown="return cFindText_onKeyDown(this,event);">') ;
      }
    }
  }
}
?>