<?php
  include 'df.php' ;
  
function UpdFileOpen($va){
  SaveHistory("O") ;
}
?>