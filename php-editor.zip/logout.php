<?php
  include 'df.php' ;
  SaveSetting("cLogin",0) ;  
?>
<html><meta http-equiv="refresh" content="0;URL=./"></html>