<?php
include 'df.php' ;

$cCom = trim($cCom) ;
$nDefaultLen = strlen($cCom) ;
if(empty($cCom)){
  $cCom = "a" ;
}
$cFile = "./command/phpcomand" . strtolower(substr($cCom,0,1)) . ".txt" ;
if(is_file($cFile)){
  echo('
    var o = document.getElementById("commandList") ;
    o.options.length = 0 ;') ;

  $lines = file($cFile) ;  
  asort($lines) ;
  $cFirst = "true" ;
  $nUrut = 0 ;
  $nLen = strlen($cCom) ;    
  foreach ($lines as $key=>$value) {
    $x = trim($value) ;
    $w = strtoupper(substr($x,0,$nLen)) ;
    if($w == trim(strtoupper($cCom))){
      $v = substr($x,$nDefaultLen) ;
      $nKurung = strpos($v,"(") ;
      $nNoParameter = strpos($x,"()") ;
      if($nKurung > 0 && $nNoParameter === false){
        $v = substr($v,0,$nKurung) ;
      }
  
      echo('
        o.options[' . $nUrut . '] = new Option("' . $x . '","' . $v . '",' . $cFirst . ',' . $cFirst . ');
        o.options[' . $nUrut . '].style.fontSize="9px" ;
        ') ;      
      $cFirst = "false" ;
      $nUrut ++ ;
    }        
  }
  echo('  nCheckRow = 100 ;
        checkCookies() ;
        showWMTT("showCommand",200) ;') ;
}
?>